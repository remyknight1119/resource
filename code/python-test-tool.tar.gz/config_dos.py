#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.7"
user = "admin"
passwd = " "


def set_dos_profile(tn, vs, dos_profile):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("set dos-profile " + dos_profile + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def unset_dos_profile(tn, vs):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("unset dos-profile\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def set_conn_limit1(tn):
    tn.write("config security dos dos-protection-profile\n")
    tn.read_until("# ")
    tn.write("edit profile2\n")
    tn.read_until("# ")
    tn.write("set http-connection-flood-protection conn3\n")
    tn.read_until("# ")
    tn.write("unset http-request-flood-protection\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def set_req_limit1(tn):
    tn.write("config security dos dos-protection-profile\n")
    tn.read_until("# ")
    tn.write("edit profile2\n")
    tn.read_until("# ")
    tn.write("unset http-connection-flood-protection\n")
    tn.read_until("# ")
    tn.write("set http-request-flood-protection request3\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")

tn.write("config vdom\n")
tn.read_until("# ")
tn.write("edit vd1\n")
tn.read_until("# ")


#vs_list = ['vs2', 'vs3','vs4', 'vs5', 'vs6', 'vs7']
vs_list = ['vs5']
#dos_profile_list = ['profile1', 'profile2', 'profile3', 'profile_request1', 'profile_access']
dos_profile_list = ['profile1']
#######################################################

i = 1
while True:
#while i < 1001:

    #for vs in vs_list:
        #for p in dos_profile_list:
            #set_dos_profile(tn, vs, p)

    for p in dos_profile_list:
        for vs in vs_list:
            set_dos_profile(tn, vs, p)
        time.sleep(3)

    for vs in vs_list:
        unset_dos_profile(tn, vs)
    time.sleep(3)
    
    print "Loop: ", i
    i += 1



#######################################################
"""
i = 1

while i<10001:
    set_conn_limit1(tn)

    time.sleep(3)

    set_req_limit1(tn)

    print "Loop: ", i
    i += 1  
""" 
