#!/usr/bin/python

import sys 
import os
import re
import time

vs1_ip = "10.201.0.10"
vs2_ip = "10.201.0.20"

ip_list = [vs1_ip, vs2_ip]

cookie_num = 2
conn_num = 10
req_num = 6

def get_cookies(rp):
    cookie_list = []
        

    conn = rp.find(r'it takes ')
    end = rp.find(r' , coming from', conn)
    cookie = rp[conn+9 : end]
    
    cookie_list.append(cookie)

    i = 0
    while i < cookie_num-1:
        i += 1
        conn = rp.find(r'it takes ', end)
        end = rp.find(r' , coming from', conn)
        cookie = rp[conn+9 : end]
        cookie_list.append(cookie)

    return cookie_list

vs = sys.argv[1]

vs_ip = ip_list[int(sys.argv[1])]
print vs_ip




i=0
#while i<10000:
while True:
    i += 1
   
    for port in range(80,120):

        command1 = "http_test " + vs_ip + " '" + str(port) + "' " + str(cookie_num) + " 1 1.0 -c"

        rp = os.popen(command1).read()
        

        cookie_list = get_cookies(rp)    
        

        for cookie in cookie_list:
            time.sleep(1)
            print '#' * 100
            print cookie 

            command2 = "http_test " + vs_ip + " '" + str(port) + "' " + str(conn_num) + ' ' + str(req_num) + ' 0.001 --method "GET" -c -H "' + cookie + '"' 

            os.system(command2)
  



     
