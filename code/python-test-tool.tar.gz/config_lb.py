#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.7"
user = "admin"
passwd = " "


def set_lb_meth(tn, vs, lb_meth):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("set load-balance-method " + lb_meth + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")

tn.write("config vdom\n")
tn.read_until("# ")
tn.write("edit vd1\n")
tn.read_until("# ")


#vs_list = ['vs2', 'VS3','vs4', 'vs5', 'vs6', 'vs7']
vs_list = ['vs5']
#lb_meth_list = ['profile1', 'profile2', 'profile3', 'profile_request1', 'profile_access']
#######################################################

i = 1
while True:
    for vs in vs_list:
        set_lb_meth(tn, vs, "LB_METHOD_ROUND_ROBIN")
    time.sleep(3)

    for vs in vs_list:
        set_lb_meth(tn, vs, "LB_METHOD_LEAST_CONNECTION")
    time.sleep(3)
    
    print "Loop: ", i
    i += 1



#######################################################
