#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.6"
user = "admin"
passwd = " "


def del_dos_profile(tn, grp):
    tn.write("config system certificate local_cert_group\n")
    tn.read_until("# ")
    tn.write("delete " + grp + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")
del_dos_profile(tn, "axb")


#######################################################
