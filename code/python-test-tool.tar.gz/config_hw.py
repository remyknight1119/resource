#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.6"
user = "admin"
passwd = " "

def set_hw_ssl_cert_group(tn, grp):
    tn.write("config system certificate local_cert_group\n")
    tn.read_until("# ")
    tn.write("edit " + grp + "\n")
    tn.read_until("# ")
    tn.write("config group_member\n")
    tn.read_until("# ")
    tn.write("edit 1\n")
    tn.read_until("# ")
    tn.write("set local-cert 1cert\n")
    tn.read_until("# ")
    tn.write("set OCSP-stapling aaa\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def detach_hw_ssl_cert_group(tn, grp):
    tn.write("config system certificate local_cert_group\n")
    tn.read_until("# ")
    tn.write("edit " + grp + "\n")
    tn.read_until("# ")
    tn.write("config group_member\n")
    tn.read_until("# ")
    tn.write("edit 1\n")
    tn.read_until("# ")
    tn.write("unset OCSP-stapling\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def change_hw_ssl_stapling(tn, hw_ssl, t):
    tn.write("config system certificate OCSP_stapling\n")
    tn.read_until("# ")
    tn.write("edit " + hw_ssl + "\n")
    tn.read_until("# ")
    tn.write("set response-update-ahead-time " + t + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")


def del_hw_ssl_cert_group(tn, grp):
    tn.write("config system certificate local_cert_group\n")
    tn.read_until("# ")
    tn.write("delete " + grp + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

def hw_ssl_case1(tn): 
    set_hw_ssl_cert_group(tn, "axb")
    time.sleep(8)
    del_hw_ssl_cert_group(tn, "axb")

def hw_ssl_case2(tn): 
    set_hw_ssl_cert_group(tn, "axb")
    time.sleep(2)
    detach_hw_ssl_cert_group(tn, "axb")

def hw_ssl_case3(tn): 
    change_hw_ssl_stapling(tn, "aaa", "1h")
    time.sleep(2)
    change_hw_ssl_stapling(tn, "aaa", "3h")


tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")
tn.write("config vdom\n")
tn.read_until("# ")
tn.write("edit root\n")
tn.read_until("# ")

hw_ssl_case1(tn)
#hw_ssl_case2(tn)
#hw_ssl_case3(tn)

#######################################################
