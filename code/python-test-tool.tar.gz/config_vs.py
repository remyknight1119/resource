#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.7"
user = "admin"
passwd = " "


def set_waf_profile(tn, vs, waf_profile):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("set waf-profile " + waf_profile + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")
    print "set waf profile"

def unset_waf_profile(tn, vs):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("unset waf-profile\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")

tn.write("config vdom\n")
tn.read_until("# ")
tn.write("edit vd1\n")
tn.read_until("# ")


#vs_list = ['vs2', 'vs3','vs4', 'vs5', 'vs6', 'vs7']
vs_list = ['vs5']
#waf_profile_list = ['profile1', 'profile2', 'profile3', 'profile_request1', 'profile_access']
waf_profile_list = ['Alert-Only']
#######################################################

i = 1
while True:
#while i < 1001:

    #for vs in vs_list:
        #for p in waf_profile_list:
            #set_waf_profile(tn, vs, p)

    for p in waf_profile_list:
        for vs in vs_list:
            set_waf_profile(tn, vs, p)
        time.sleep(3)

    for vs in vs_list:
        unset_waf_profile(tn, vs)
    time.sleep(3)
    
    print "Loop: ", i
    i += 1



#######################################################
