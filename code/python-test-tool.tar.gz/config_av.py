#!/usr/bin/python

import telnetlib
import os
import time


adc = "10.106.153.7"
user = "admin"
passwd = " "


def set_av_profile(tn, vs, av_profile):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("set av-profile " + av_profile + "\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")
    print "set av profile"

def unset_av_profile(tn, vs):
    tn.write("config load-balance virtual-server\n")
    tn.read_until("# ")
    tn.write("edit " + vs + "\n")
    tn.read_until("# ")
    tn.write("unset av-profile\n")
    tn.read_until("# ")
    tn.write("end\n")
    tn.read_until("# ")

tn = telnetlib.Telnet(adc)
tn.read_until("login: ")
tn.write(user + "\n")
tn.read_until("Password: ")
tn.write(passwd + "\n")

tn.read_until("# ")

tn.write("config vdom\n")
tn.read_until("# ")
tn.write("edit vd1\n")
tn.read_until("# ")


#vs_list = ['vs2', 'VS3','vs4', 'vs5', 'vs6', 'vs7']
vs_list = ['vs5']
#av_profile_list = ['profile1', 'profile2', 'profile3', 'profile_request1', 'profile_access']
av_profile_list = ['Antivirus-Profile']
#######################################################

i = 1
while True:
#while i < 1001:

    #for vs in vs_list:
        #for p in av_profile_list:
            #set_av_profile(tn, vs, p)

    for p in av_profile_list:
        for vs in vs_list:
            set_av_profile(tn, vs, p)
        time.sleep(3)

    for vs in vs_list:
        unset_av_profile(tn, vs)
    time.sleep(3)
    
    print "Loop: ", i
    i += 1



#######################################################
