#!/usr/bin/python

#Module documentation
"This is a common module of the ADSG cloud module; developed by liu_yt@neusoft.com"

#Module imports
from boto.ec2.regioninfo import RegionInfo
from boto.ec2.connection import EC2Connection

#Global variable

#Class

class ec2_connection(object):
    def __init__(self, id, key):
        self.id = id
        self.key = key

    def list_regions(self, region_name = None):
        conn = EC2Connection(self.id, self.key)
        return conn.get_all_regions(region_names = region_name)

    def get_instances(self, reg_name, node_ids):
        region = self.list_regions(region_name = reg_name)
        conn = EC2Connection(self.id, self.key, region = region[0])
        return conn.get_all_instances(instance_ids = node_ids)
         
    def list_nodes(self, reg_name, node_ids = None):
        nodes = []
        instances = self.get_instances(reg_name, node_ids)
        for instance in instances:
            inst_info = "node_id = %s, public_ip = %s , state = %s, zone = %s \
                    " % (instance.instances[0].id, 
                            instance.instances[0].ip_address, 
                            instance.instances[0].state,
                            instance.instances[0].placement)
            nodes.append(inst_info)
        return nodes

    def start_nodes(self, reg_name, node_ids):
        instances = self.get_instances(reg_name, node_ids)
        for instance in instances:
            instance.instances[0].start()

    def stop_nodes(self, reg_name, node_ids):
        instances = self.get_instances(reg_name, node_ids)
        for instance in instances:
            instance.instances[0].stop()


#Function

