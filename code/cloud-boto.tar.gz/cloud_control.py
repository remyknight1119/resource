#!/usr/bin/python

#Module documentation
"This is a client crontol module of the ADSG cloud module; developed by liu_yt@neusoft.com"

#Module imports
import re
import sys
import optparse
from cloud_common import (ec2_connection)

#Global variable
cloud_type = 'None'
access_id = 'None'
access_key = 'None'
aws_region = 'None'
action_list = {}
instance_list = []

#Class


#Function
def parse_option():
    global cloud_type, access_id, access_key, aws_region, action_list, \
            instance_list
    usage = "Usage: %prog <options>"
    parser = optparse.OptionParser(usage = usage)
    parser.add_option("-t", "--cloud-type", action = "store",
            type = "string", dest = "cloud_type",
            help = "specify cloud type, aws is the only choice for now",
            default = "None")
    parser.add_option("-u", "--access-id", action = "store",
            type = "string", dest = "access_id",
            help = "specify access id for the cloud",
            default = "None")
    parser.add_option("-p", "--access-key", action = "store",
            type = "string", dest = "access_key",
            help = "specify access key for the cloud",
            default = "None")
    parser.add_option("-r", "--region", action = "store",
            type = "string", dest = "region",
            help = "specify the region for the awc ec2",
            default = "None")
    parser.add_option("-i", "--instance", action = "store",
            type = "string", dest = "instance",
            help = "specify the instance for the awc ec2",
            default = "None")
    parser.add_option("-L", "--list", action = "store",
            type = "string", dest = "list",
            help = "specify list action",
            default = "None")
    parser.add_option("-S", "--start", action = "store_true", dest = "start",
            help = "start instance",
            default = False)
    parser.add_option("-D", "--stop", action = "store_true", dest = "stop",
            help = "stop instance",
            default = False)

    (options, args) = parser.parse_args() 
    cloud_type = options.cloud_type
    access_id = options.access_id
    access_key = options.access_key
    aws_region = options.region
    start_instance = options.start
    stop_instance = options.stop

    if options.instance != 'None':
        instances = re.split(',', options.instance)
        for instance in instances: 
            instance_list.append(instance)
    else:
        instance_list = None

    list = options.list

    if cloud_type == 'None':
        return "Must specify cloud type"

    if access_id == 'None':
        return "Must specify access_id type"

    if access_key == 'None':
        return "Must specify access_id key"

    if list != 'None':
        action_list['list'] = list

    if start_instance != False:
        action_list['start'] = 'None'
    elif stop_instance != False:
        action_list['stop'] = 'None'

    return True

def aws_ec2_ctl(**args):
    id = args['id']
    key = args['key']
    if 'region' not in args:
        print "Must specify aws region"
        return 1
        
    region = []
    region.append(args['region'])
    if 'action' not in args:
        print "No action"
        return 1
    actions = args['action']

    try:
        connection = ec2_connection(id, key)
    except Exception, msg:
        print 'Unknow region', msg
        return 1

    for action in actions.keys():
        if action == 'list':
            if actions[action] == 'nodes':
                try:
                    nodes = connection.list_nodes(region, instance_list)
                except Exception, msg:
                    print msg
                    return 1

                for node in nodes:
                    print node
                    
            elif actions[action] == 'regions':
                try:
                    regions = connection.list_regions()
                except Exception, msg:
                    print msg
                    return 1

                for region in regions:
                    print region.name
            else:
                print 'Unknow list type %s' % actions[action]
                return 1

        elif action == 'start':
            try:
                nodes = connection.start_nodes(region, instance_list)
            except Exception, msg:
                print msg
                return 1
        elif action == 'stop':
            try:
                nodes = connection.stop_nodes(region, instance_list)
            except Exception, msg:
                print msg
                return 1
        else:
            print 'Unkonw parameter %s' % action

    return 0

#other function

#Handler dict
cloud_handler = {'aws':aws_ec2_ctl}

#main
if __name__ == '__main__':
    ret = parse_option()
    if ret != True:
        print ret
        exit(1)

    try:
        handler = cloud_handler[cloud_type]
    except KeyError:
        print 'cloud type %s is not support' % cloud_type
        exit(1)

    err = handler(id = access_id, key = access_key, region = aws_region, 
            action = action_list)
    if err != 0:
        exit(1)
