#!/bin/bash

set -e

if [ $# -eq 0 ]; then
    echo "$0 [version]"
    exit 1
fi

pkg_version=$1
product_name=CrackObstaclor
install_dir=opt/$product_name
lib_dir=$install_dir/lib
bin_dir=$install_dir/bin
crackobstaclor_bin=crackobstaclor
conf_dir=$install_dir/conf
tmp_dir=/tmp/CrackObstaclor-tmp
cur_dir=$PWD

if [ -d $tmp_dir ]; then
    rm -rf $tmp_dir
fi

mkdir -p $tmp_dir/$lib_dir
mkdir -p $tmp_dir/$bin_dir
mkdir -p $tmp_dir/$conf_dir
mkdir -p $tmp_dir/usr/bin
cp third-party/proguard*/lib/proguard.jar $tmp_dir/$lib_dir/libCrackObstaclor.jar
cp -r conf/* $tmp_dir/$conf_dir/
cd src
./make.sh bin $tmp_dir/$bin_dir/$crackobstaclor_bin
ln -sf /$bin_dir/$crackobstaclor_bin $tmp_dir/usr/bin/$crackobstaclor_bin
cd $tmp_dir
tar czvf $cur_dir/$crackobstaclor_bin-$pkg_version.tar.gz *

