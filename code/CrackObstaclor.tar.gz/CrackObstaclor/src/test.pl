#!/usr/bin/perl

use strict;
use warnings;
use lib 'modules';
use common;
use Getopt::Std;
use File::Find;

use vars qw($opt_m $opt_h);
getopts('m:h');

my @test_files;
my $test_mod;
my $test_dir = 'test';
my $unit_test_dir = "unit-test";
my $int_test_dir = "integration-test";
my $std_out_file = "test.log";

sub usage {
    print ("usage: $0 -m [test module(unit, int, all)]\n");
    print ("\t\t\t\t-h (no args, help)\n");
}

sub _get_test_files {
    if (! -d $File::Find::name && $File::Find::name =~/^.*\.t$/) {
        push(@test_files, $File::Find::name);
    }
}

sub get_test_files {
    my $dir = shift(@_);

    @test_files = ();
    find(\&_get_test_files, $dir);

    return @test_files;
}

if ($opt_h) {
    &usage;
    exit(0);
}

$test_mod = $opt_m;
if (! $test_mod) {
    &usage;
    exit(0);
}

sub do_test {
    my $test_files = shift(@_);
    my $test_str = shift(@_);
    my $total = 0;
    my $failed = 0;

    print STDERR ("========$test_str test start========\n");
    foreach my $tc (@$test_files) {
        $total++;
        my $ret;
        $ret = system("perl $tc");
        if ($ret eq 0) {
            print STDERR ("Test $tc \t\tsuccess!\n");
        } else {
            print STDERR ("Test $tc \t\tfailed!\n");
            $failed++;
        }
    }
    print STDERR ("========$test_str test end========\n");
    print STDERR ("In $test_str Total:$total, filed:$failed\n");
}

open (STDOUT, ">$std_out_file") || die ("open STDOUT failed");
if ($test_mod eq "unit" || $test_mod eq "all") {
    my @unit_test_files;
    
    @unit_test_files = get_test_files("$test_dir/$unit_test_dir");
    do_test(\@unit_test_files, "unit");
}

if ($test_mod eq "int" || $test_mod eq "all") {
    my @int_test_files;
    
    @int_test_files = get_test_files("$test_dir/$int_test_dir");
    do_test(\@int_test_files, "int");
}

close(STDOUT);


