package bin_protect::co_binary_protect;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_bin_protect_handler);

sub co_bin_protect_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my %warrant = @_;

    return 0;
}


1;
