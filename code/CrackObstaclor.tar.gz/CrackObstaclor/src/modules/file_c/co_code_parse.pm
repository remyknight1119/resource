package file_c::co_code_parse;
require Exporter;
use Getopt::Std;
use Tie::File;
use Cwd;
use lib 'modules';
use common;
use file_c::co_function_parse;

@ISA = qw(Exporter);
@EXPORT = qw($co_func_name_key $co_input_param_key $co_local_param_key
                $co_code_start_line_key $co_func_array_key 
                co_c_code_parser);

$co_func_name_key = "function_name";
$co_func_array_key = "function_array";
$co_input_param_key = "input_param";
$co_local_param_key = "local_param";
$co_code_start_line_key = "code_start_line";

sub co_c_code_parser {
    my ($file_array) = shift(@_);
    my ($func_name) = shift(@_);
    my @funcs;
    my @func_array;
    my %code_info;
    my $line = 0;
    my $prev_line = 0;
    my $state = 0;
    my $i_param;
    my $func_h;
    my $l_param;

    foreach my $func (@$func_name) {
        $prev_line = 0;
        #多次定义相同的函数
        while (1) {
            #找到函数的位置
            my $func_line = co_c_rearrange_func($file_array, $func, $prev_line);
            if ($func_line < 0) {
                if ($prev_line == 0) {
                    return;
                }
                last;
            }

            $i_param = {};
            $func_h = {};
            #解析其输入列表
            my %input_list = co_c_parse_input_list($file_array, \$func_line);
            if (%input_list) {
                co_hash_merge($i_param, %input_list);
                $func_h->{$co_input_param_key} = $i_param;
            }
            #解析局部参数
            $l_param = {};
            my %local_param = co_c_parse_local_param($file_array, \$func_line); 
            if (%local_param) {
                co_hash_merge($l_param, %local_param);
                $func_h->{$co_local_param_key} = $l_param;
            }
            #记录函数代码起始行号
            $func_h->{$co_code_start_line_key} = $func_line;
            $func_h->{$co_func_name_key} = $func;
            $funcs[$func_line] = $func_h;
            $prev_line = $func_line + 1;
        }
    }

    #按照起始行号由大到小给函数排序
    foreach my $f (@funcs) {
        if ($f) {
            unshift(@func_array, $f);
        }
    }
    $code_info{$co_func_array_key} = [@func_array];

    foreach my $file_line (@$file_array) {
        $line++;
        #跳过#include关键字
        if ($state == 0 && $file_line !~ /\s*\#\s*include/ ) {
            $code_info{$co_code_start_line_key} = $line; 
            $state = 1;
        }
    }

    return %code_info;
}

1;
