package file_c::co_code_format;
require Exporter;
use Getopt::Std;
use Tie::File;
use Cwd;
use common;

@ISA = qw(Exporter);
@EXPORT = qw(co_c_code_rearrange);

#生成按;分行后的字符串
sub new_line_for_semicolon {
    my ($str) = (@_);
    my @sp;
    my @ret;
    my $m1;
    my $m2;
    my $tmp_str;

    @sp = split(/;/, $str);
    foreach my $s (@sp) {
        $m1 = str_contain_count($s, "\'");
        $m2 = str_contain_count($s, "\"");
        
        if ($tmp_str) {
            $tmp_str .= "$s;";
            push(@ret, $tmp_str);
            undef $tmp_str;
            next;
        } 
        #字符串中包含奇数个'或"，不能按照这个;来分割
        if ($m1 % 2 != 0 || $m2 % 2 != 0) {
            $tmp_str = "$s;";
            next;
        }
        #跳过空格
        if ($s =~ /^\s*$/) {
            next;
        }
        push(@ret, $s.";");
    }

    #原有字符串最后的字符不是;，则去掉添加的;
    if ($str !~ /;\s*$/) {
        chop($ret[-1]);
    }

    return @ret;
}

#按;分行
sub co_add_new_line_for_semicolon {
    my ($file_array) = shift(@_);
    my @lines;

    for(my $index = 0; $index < @$file_array; $index++) {
        my $content = $$file_array[$index];
        #for语句中的;不分行
        if ($content !~ /;/ || $content =~ /^\s*for\s*\(/) {
            next;
        }
        @lines = new_line_for_semicolon($content);
        splice(@$file_array, $index, 1, @lines);
        #跳过新增行
        $index = $index + @lines - 1;
    }
}

#删除空行
sub remove_blank {
    my ($file_array) = shift(@_);

    for(my $index = 0; $index < @$file_array; $index++) {
        if ($$file_array[$index] =~ /^\s*$/) {
            splice(@$file_array, $index, 1);
            $index--;
        }
    }
}

#删除注释和空行
sub remove_comment {
    my ($file_array) = shift(@_);
    my @lines;
    my $comment = 0;
    my $cotent = 0;

    for(my $index = 0; $index < @$file_array; $index++) {
        #删除单行/*comment*/形式的注释
        $$file_array[$index] =~ s/\/\*.*\*\///;
        $$file_array[$index] =~ s/\/\/.*//;

        $content = $$file_array[$index];

        #多行注释开头：/*
        if ($comment == 0 && $content =~ /\/\*/) {
            $$file_array[$index] =~ s/\/\*.*//;
            $comment = 1;
        }

        #多行注释结尾：*/
        if ($comment == 2 && $content =~ /\*\//) {
            $$file_array[$index] =~ s/.*\*\///;
            $comment = 0;
        }
        #删除多行注释
        if ($comment == 2) {
            splice(@$file_array, $index, 1);
            $index--;
        }
        if ($comment == 1) {
            $comment = 2;
        }
    }
}

#生成按{和}分行后的字符串
sub new_line_for_brace {
    my ($str) = shift(@_);
    my ($key) = shift(@_);

    return split_str_not_replace_key($str, $key);
}

#按{和}分行
sub co_add_new_line_for_brace {
    my ($file_array) = shift(@_);
    my ($key) = shift(@_);
    my @lines;

    for(my $index = 0; $index < @$file_array; $index++) {
        my $content = $$file_array[$index];
        if ($content !~ /$key/ || $content =~ /^\s*$key\s*$/) {
            next;
        }
        if ($content =~ /=.*\{.*\}\s*;$/) {
            next;
        }
        @lines = new_line_for_brace($content, $key);
        #};结尾不分开
        
        if ($lines[-1] =~ /\s*;\s*$/ && $lines[-2] =~ /\s*\}\s*$/) {
            $lines[-2] .= $lines[-1];
            pop(@lines);
        }
        splice(@$file_array, $index, 1, @lines);
        #跳过新增行
        $index = $index + @lines - 1;
    }
}

#小括号(不能作为一行的开始与结束, )不能作为开头
sub make_one_line_for_brace {
    my ($file_array) = shift(@_);
    my $state = 0;

    for(my $index = 0; $index < @$file_array; $index++) {
        my $content = $$file_array[$index];
        #以(或)开头
        if ($content =~ /^\s*(\(|\))/) {
            if ($index < 1) {
                die("Can't parse code!\n");
            }
            $$file_array[$index - 1] .= $content;
            splice(@$file_array, $index, 1);
            $index--;
        } 
        #以(结尾
        if ($$file_array[$index] =~ /\(\s*$/) {
            if ($index + 1 == @$file_array) {
                die("Can't parse code!\n");
            }
            $$file_array[$index] = remove_space_back($$file_array[$index]);
            $$file_array[$index] .= 
            remove_space_front_back($$file_array[$index + 1]);
            splice(@$file_array, $index + 1, 1);
            $index--;
        }
    }
}

#代码风格整理
sub co_c_code_rearrange {
    my ($file_array) = shift(@_);
    my ($func_array) = shift(@_);
    my @lines;

    #删除注释
    remove_comment($file_array);
    #每个语句一行
    co_add_new_line_for_semicolon($file_array);
    #每个大括号单独一行
    co_add_new_line_for_brace($file_array, '{');
    co_add_new_line_for_brace($file_array, '}');
    #删除空行
    remove_blank($file_array);
    #整理小括号
    make_one_line_for_brace($file_array);

    return 0;
}

1;
