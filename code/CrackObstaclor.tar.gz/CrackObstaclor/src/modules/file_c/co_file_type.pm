package file_c::co_file_type;
require Exporter;
use common;
use File::Find;

@ISA = qw(Exporter);
@EXPORT = qw(co_c_find_files co_c_file_check co_c_func_name_check);

my @co_code_files;

sub co_c_get_files {
    my $file;
    if (! -d $File::Find::name && $File::Find::name =~/^.*\.(c|h)$/) {
        $file = co_path_convert($File::Find::name);
        push(@co_code_files, $file);
    }
}

sub co_c_find_files {
    my $code_dir = shift(@_);
    @co_code_files = ();

    find(\&co_c_get_files, $code_dir);

    return @co_code_files;
}

sub co_c_file_check {
    my $file_name = shift(@_);

    if ($file_name =~ /^.*\.(c|h)$/) {
        return 1;
    }

    return 0;
}

sub co_c_func_name_check {
    return 1;
}

1;
