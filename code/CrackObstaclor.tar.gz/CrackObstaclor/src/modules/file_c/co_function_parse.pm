package file_c::co_function_parse;
require Exporter;
use common;
use file_c::co_sentence_parse;
use file_c::co_code_format;
use Getopt::Std;
use File::Find;
use Tie::File;
use Cwd;

@ISA = qw(Exporter);
@EXPORT = qw(func_parse find_all_funcs co_c_parse_input_list co_c_find_func_line
                co_c_parse_local_param co_c_function_is_define
                co_c_find_func_end co_c_rearrange_func co_parse_one_line_param);

sub find_all_funcs {
    my ($cfile) = shift(@_);
    my @all_funcs;


    return @all_funcs;
}

sub co_c_find_func_end {
    my ($file_array) = shift(@_);
    my ($start) = shift(@_);
    my $match = 0;
    my $s = 0;

    for(my $index = $start; $index < @$file_array; $index++) {
        my $content = $$file_array[$index];
        if ($content =~ /\{/) {
            $s = 1;
        }
        if ($s == 0) {
            next;
        }
        $match += $content =~ s/\{/\{/;
        $match -= $content =~ s/\}/\}/;
        if ($match == 0) {
            return $index;
        }
    }

    return -1;
}

#返回函数定义的位置
sub co_c_find_func_line {
    my ($file_array) = shift(@_);
    my ($fname) = shift(@_);
    my ($start) = shift(@_);

    $size = @$file_array;

    for(my $index = $start; $index < $size; $index++) {
        my $content = $$file_array[$index];
        if (!co_c_function_is_define($file_array, $index, $size, $fname)) {
            next;
        }

        return $index;
    } 
        
    return -1;
}

sub co_c_rearrange_func {
    my ($file_array) = shift(@_);
    my ($fname) = shift(@_);
    my ($start) = shift(@_);
    my $s_line;
    my $e_line;
    my $line;
    my @f_array = ();

    $size = @$file_array;

    $s_line = co_c_find_func_line($file_array, $fname, $start);
    if ($s_line < 0) {
        return -1;
    }
    $e_line = co_c_find_func_end($file_array, $s_line);
    if ($e_line < 0) {
        return -1;
    }
    $line = 0;
    for(my $index = $s_line; $index + $line <= $e_line; $line++) {
        my $content = $$file_array[$index];
        push(@f_array, $content);
        splice(@$file_array, $index, 1);
    }
    co_c_code_rearrange(\@f_array);
    splice(@$file_array, $s_line, 0, @f_array);

    return $s_line;
}

sub _parse_single_param {
    my ($param) = shift(@_);
    my $key;
    my $value;
    my $star = 0;
    my $size = 0;
    my @p;
    my @res;

    $param = remove_space_front_back($param);
    if ($param =~ /\*/) { #处理指针类型入参
        $star = $param =~ s/\*//g;
    }
    @p = split(/ /, $param);
    $key = remove_space_front_back($p[-1]);
    $value = remove_space_front_back($p[0]);

    for ($size = 1; $size + 1 < @p; $size++) {
        $value .= " $p[$size]";
    }

    for (; $star > 0; $star--) {
        $value .= '*';
    }

    $res[0] = $key;
    $res[1] = $value;

    return @res;
}

sub parse_single_param {
    my ($param) = shift(@_);
    my ($param_list) = shift(@_);
    my @p;

    @p = _parse_single_param($param);

    $param_list->{$p[0]} = $p[1];
}

sub co_parse_one_line_param {
    my ($param_list) = shift(@_);
    my %input_param = ();
    my @p;
    my @l;
    my $key;
    my $type;
    my $str;

    $param_list = remove_space_front_back($param_list);
    if ($param_list !~/ /) {
        return %input_param;
    }

    #int *a, *b = NULL, c = 2
    #解析第一个参数a
    @l = split(/,/, $param_list);
    @p = split(/=/, $l[0]);
    @p = _parse_single_param($p[0]);
    $key = $p[0]; #$key = a
    $input_param{$key} = $p[1]; #$p[1] = int *
    shift(@l);

    #解析剩余参数 *b, c
    @p = split(/\*/, $p[1]);
    $type = remove_space_front_back($p[0]); #$type = int
    foreach my $param (@l) { #$param = "*b = NULL", $param = "c = 2"
        @p = split(/=/, $param);
        $key = remove_space_front_back($p[0]); #$key = *b, $key = c
        $str = $type." $key"; #$str = "int *b", $str = "int c"
        parse_single_param($str, \%input_param);
    }

    return %input_param;
}


sub parse_input_param {
    my ($param_list) = shift(@_);
    my %input_param = ();
    my @p;
    my $key;

    $param_list = remove_space_front_back($param_list);
    if ($param_list !~/ /) {
        return %input_param;
    }

    my @l = split(/,/, $param_list);
    foreach my $param (@l) {
        parse_single_param($param, \%input_param);
    }

    return %input_param;
}

sub co_c_parse_input_list {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my %input_param_list;
    my $parse_step = 0;
    my $input_param;
    my $size;
    my $content;

    $size = @$file_array;

    for(my $index = $$start_line; $index < $size; $index++) {
        $$start_line++;
        $content = $$file_array[$index];
        #以;结尾的不是定义函数的代码
        if ($parse_step == 0) {
            #输入列表开始
            if ($content =~ /\(/) { # int func1 (int a, int b,
                $parse_step = 1;
                my @input_list = split(/\(/, $content);
                $input_param = $input_list[-1]; #$input_param = "int a, int b,"
            }
        } 
        
        if ($parse_step == 1) {
            #输入列表结束
            if ($content !~ /\(/) { # long c, long d,
                chomp($input_param);
                $input_param = $input_param.$content;
            }  #$input_param = "int a, int b, long c, long d"
            if ($content =~ /\)/) { # short e)
                my @input_list = split(/\)/, $input_param);
                $input_param = $input_list[0];
                %input_param_list = parse_input_param($input_param); 
                last;
            }  #$input_param = "int a, int b, long c, long d, short e"
        }
    }

    return %input_param_list;
}

sub parse_local_struct {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my $size;
    my $content;
    my $key;
    my $value;
    my @sp;
    my %param;

    $size = @$file_array;

    for(; $$start_line < $size; $$start_line++) {
        $content = $$file_array[$$start_line];
        if ($content =~ /^\s*struct\s*/ && $content !~ /;$/) { # struct a {
            @sp = split(/\{/, $content);
            $value = $sp[0]; #$value = "struct a"
        }
        if ($content =~ /^\s*\}.*;$/) { # } aaa, bbb;
            chop($content); # } aaa, bbb
            @sp = split(/\}/, $content); # 留下 "aaa, bbb"
            @sp = split(/,/, $sp[-1]); #分离 "aaa"与"bbb"
            last;
        }
    }

    foreach $key (@sp) {
        $key = remove_space_front_back($key);
        $param{$key} = remove_space_front_back($value);
    }

    return %param;
}

sub parse_local_array {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my $size;
    my $content;
    my $key;
    my $value;
    my @sp;
    my %param;

    $size = @$file_array;

    for(; $$start_line < $size; $$start_line++) {
        $content = $$file_array[$$start_line];
        if ($content =~ /.*\[*\]*/) {
            @sp = split(/\[/, $content);
            @sp = split(/ /, remove_space_front_back($sp[0]));
            $key = remove_space_front_back($sp[-1]);
            $value = remove_space_front_back($sp[0]);
            $param{$key} = $value;
        }
        if ($content =~ /.*;$/) {
            last;
        }
    }

    return %param;
}

sub co_c_function_is_define {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my ($end_line) = shift(@_);
    my ($func_name) = shift(@_);
    my $str;
    my $i;

    $str = $$file_array[$start_line];
    if (($str !~ /\s\s*\**$func_name\s*\(/ &&
        $str !~ /^\s*\**$func_name\s*\(/ &&
        $str !~ /\s\s*\**$func_name\s*$/ &&
        $str !~ /^\s*\**$func_name\s*$/) ||
        $str =~ /=/) {
        return 0;
    }

    for ($i = $start_line; $i <= $end_line; $i++) {
        $str = $$file_array[$i];
        if ($str =~ /;/ && $str !~ /\{.*;/) {
            return 0;
        }
        if ($str =~ /\)*\s*\{/) {
            return 1;
        }
    }

    return 0;
}

sub co_c_parse_local_param {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my %param;
    my %local_list = ();
    my $size;
    my $content;
    my $state = 0;
    my $n = 0;
    my @sp;
 
    $size = @$file_array;

    for(; $$start_line < $size; $$start_line++) {
        $content = $$file_array[$$start_line];
        #print("line = $$start_line, content = $content\n");
        #匹配到"{", 解析开始
        if ($content =~ /^\s*\{\s*/) {
            $n++;
            if ($state == 0) {
                $state = 1;
                next;
            }
        }

        #匹配到预处理命令
        if ($content =~ /^\s*#\s*if/) {
            last;
        }

        #匹配到"}"
        if ($content =~ /^\s*\}\s*/) {
            $n--;
        }

        if ($state == 1 && $n == 0) {
            last;
        }

        #到达非定义语句，退出
        if (!&co_c_sentence_is_define($content)) {
            last;
        }

        if ($content =~ /^\s*struct\s*/ && $content !~ /;$/) { # struct {
            my %struct_param = parse_local_struct($file_array, $start_line);
            &co_hash_merge(\%local_list, %struct_param);
            next;
        }

        if ($content =~ /.*\[*\].*/) {
            my %array_param = parse_local_array($file_array, $start_line);
            &co_hash_merge(\%local_list, %array_param);
            next;
        }

        if ($content =~ /;$/) {
            chop($content);
            %param = &co_parse_one_line_param($content);
            &co_hash_merge(\%local_list, %param);
            next;
        }
    }
 
    return %local_list;
}

1;
