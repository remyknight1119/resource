package file_c::co_sentence_parse;
require Exporter;
use common;
use Getopt::Std;
use File::Find;
use Tie::File;
use Cwd;

@ISA = qw(Exporter);
@EXPORT = qw(co_c_sentence_is_define);

sub co_c_sentence_is_define {
    my ($str) = shift(@_);
    my @sp;

    if ($str =~ /^\s*if\s*\(/ || $str =~ /^\s*for\s*\(/ ||
        $str =~ /^\s*while\s*\(/ || $str =~ /^\s*switch\s*\(/) {
        return 0;
    }

    #匹配到空行
    if ($str =~ /^\s*$/) {
        return 0;
    }

    $str = remove_space_front_back($str);
    # a = b;
    if ($str =~ /=/) {
        @sp = split(/=/, $str);
        $sp[0] = remove_space_front_back($sp[0]);
        if ($sp[0] !~ / /) {
            return 0;
        }
        #a++;
    } elsif ($str =~ /\+\+/) {
        return 0;
    } elsif ($str =~ /\:$/) {
        return 0;
    } elsif ($str =~ /\(/) {
        return 0;
    }

    return 1;
}



1;
