package co_license;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_lic_import co_lic_get_warrant $co_file_scope_name
            $co_func_scope_name);

$co_file_scope_name = "file_scope";
$co_func_scope_name = "func_scope";

sub co_lic_import {
    my ($lic_file) = shift(@_);

    return 0;
}

sub co_lic_get_warrant {
    my %warrant;

    push(@{$warrant{$co_file_scope_name}}, "C");
    push(@{$warrant{$co_file_scope_name}}, "Java");
    push(@{$warrant{$co_func_scope_name}}, "CodeObfuscate");

    return %warrant;
}


1;
