package co_file_type;
require Exporter;
use file_c::co_file_type;
use file_java::co_file_type;
use config::co_conf_common;
use common;
use File::Find;

@ISA = qw(Exporter);
@EXPORT = qw(co_ft_find_files co_ft_get_tfiles co_ft_get_dfiles);

my %co_ft_code_dir_handler = (
    $co_gs_file_type_c_key => \&co_c_find_files, 
    $co_gs_file_type_java_key => \&co_java_find_files, 
);

sub co_ft_find_files {
    my $file_type = shift(@_);
    my $code_dir = shift(@_);

    if (!exists($co_ft_code_dir_handler{$file_type})) {
        return;
    }

    if (! -d $code_dir) {
        return;
    }

    return $co_ft_code_dir_handler{$file_type}($code_dir);
}

sub _co_ft_get_files {
    my $code_files = shift(@_);
    my $scope_conf_array = shift(@_);
    my $key = shift(@_);
    my %tfile;
    my $file_name;
    my $value;
    my $fn;
    my $fc;

    foreach my $scope (@$scope_conf_array) {
        $file_name = $scope->{$co_file_name_key};
        $value = $scope->{$key};
        if ($file_name =~ /\*$/) {
            chop($file_name); 
            if ($file_name =~ /\\$/) {
                chop($file_name);
            }
            foreach my $f (@$code_files) {
                $fn = $file_name;
                $fc = $f;
                if (co_os_is_windows()) {
                    $fn =~ s/\\/\//g;
                    $fc =~ s/\\/\//g;
                }
                if (! $fn || $fc =~ /^$fn/) {
                    push(@{$tfile{$f}}, $value);
                }
            }
        } elsif (co_array_exist($file_name, $code_files)) {
            push(@{$tfile{$file_name}}, $value);
        }
    }

    return %tfile;
}

sub co_ft_get_tfiles {
    my $code_files = shift(@_);
    my $scope_conf_array = shift(@_);

    return _co_ft_get_files($code_files, $scope_conf_array,
        $co_func_name_key);
}

sub co_ft_get_dfiles {
    my $code_files = shift(@_);
    my $scope_conf_array = shift(@_);

    return _co_ft_get_files($code_files, $scope_conf_array,
        $co_ob_locate_key);
}


1;
