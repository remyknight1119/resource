package config::co_conf;
require Exporter;
use XML::Bare;
use code_protect::co_code_protect;
use code_revert::co_code_revert;
use code_analyse::co_code_analyse;
use bin_protect::co_binary_protect;
use config::co_conf_common;
use common;

@ISA = qw(Exporter);
@EXPORT = qw(co_do_protect);

my %co_conf_handler = (
    $co_conf_code_protect_key => \&co_code_protect_handler, 
    $co_conf_code_analyse_key => \&co_code_analyse_handler,
    $co_conf_bin_protect_key => \&co_bin_protect_handler,
    $co_conf_code_revert_key => \&co_code_revert_handler,
);

my $ret_code_name = "ret_code";
my $proc_func_name = "func";
my $key_name = "key";
my $conf_name = "conf";

sub co_conf_parse {
    my $conf = shift(@_);
    my %parse = ($ret_code_name => 0);
    my $conf_parse = new XML::Bare(file => "$conf");
    my $conf_root = $conf_parse->parse();
    my %handler;

    my $ret = co_conf_check_key($conf_root, $co_conf_root);
    if ($ret eq 1) {
        $parse{$ret_code_name} = 1;
        return %parse;
    }

    if ($ret eq 2) {
        $parse{$ret_code_name} = 2;
        return %parse;
    }

    while (my ($key, $value) = each %co_conf_handler) {
        if (exists($conf_root->{$co_conf_root}->{$key})) {
            if (%handler) {
                print("$key can't be configured with $handler{$key_name}!\n");
                $parse{$ret_code_name} = 3;
                return %parse;
            }
            $handler{$proc_func_name} = $value;
            $handler{$conf_name} = $conf_root->{$co_conf_root}->{$key};
        }
    }

    if (!%handler) {
        print("No valid configuration!\n");
        $parse{$ret_code_name} = 4;
        return %parse;
    }
    $parse{$proc_func_name} = $handler{$proc_func_name};
    $parse{$conf_name} = $handler{$conf_name};

    return %parse;
}

sub co_do_protect {
    my $conf_file = shift(@_);
    my $root_dir = shift(@_);
    my $warrant = shift(@_);

#解析配置
    my %conf = co_conf_parse($conf_file);
    if ($conf{$ret_code_name} ne 0) {
        return $conf{$ret_code_name};
    }

    return $conf{$proc_func_name}($root_dir, $conf{$conf_name}, $warrant);
}


1;
