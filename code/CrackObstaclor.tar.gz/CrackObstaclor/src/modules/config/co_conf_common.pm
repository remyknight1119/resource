package config::co_conf_common;
require Exporter;
use file_c::co_file_type;
use file_java::co_file_type;
use common;

@ISA = qw(Exporter);
@EXPORT = qw(
                $co_gs_file_type_key $co_code_obfuscate_key
                $co_gs_file_cstandard_key $co_gs_input_dir_key
                $co_gs_output_code_dir_key $co_gs_output_info_dir_key
                $co_gs_res_limit_key $co_gs_os_type_key $co_global_settings_key
                $co_conf_root $co_conf_code_protect_key $co_file_name_key 
                $co_conf_code_analyse_key $co_conf_bin_protect_key
                $co_conf_code_revert_key $co_warter_mark_key $co_anti_debug_key
                $co_tamper_proof_key $co_gs_file_type_c_key $co_func_name_key 
                $co_gs_file_type_java_key $co_c_standard_c89_key 
                $co_c_standard_c99_key $co_c_standard_misrac_key
                $co_res_level_low_key $co_res_level_medium_key
                $co_res_level_high_key $co_os_type_win_key
                $co_os_type_lin_key $co_os_type_bios6_key $co_scope_key
                $co_ob_appearance_key $co_ob_flow_key $co_ob_data_key
                $co_ob_struct_key $co_ob_pre_key $co_ob_dyn_key
                $co_gs_library_jars_key $co_ob_keep_option_key 
                $co_ob_keep_package_names_key $co_ob_keep_classes_key 
                $co_ob_keep_class_members_key $co_ob_data_type_key 
                $co_ob_keep_classes_with_members_key $co_ob_locate_key 
                $co_ob_keep_classes_with_members_names_key 
                @co_code_file_type @co_c_standard @co_resource_level
                @co_os_type @co_cp_sub_modules @co_obfuscate_method
                co_conf_parse_scope co_conf_get_value co_conf_item_parse
                co_conf_item_parse_check co_conf_check_key
                co_conf_multi_item_parse 
             );

$co_conf_root = "CrackObstaclor";

$co_conf_code_protect_key = "CodeProtect";
$co_conf_code_analyse_key = "CodeAnalyse";
$co_conf_bin_protect_key = "BinaryProtect";
$co_conf_code_revert_key = "CodeRevert";

$co_global_settings_key = "GlobalSettings";

$co_gs_file_type_key = "FileType";
$co_gs_file_cstandard_key = "CStandard";
$co_gs_file_type_c_key = "C";
$co_gs_file_type_java_key = "Java";
$co_gs_library_jars_key = "LibraryJars";
$co_gs_input_dir_key = "InputDir";
$co_gs_output_code_dir_key = "OutputCodeDir";
$co_gs_output_info_dir_key = "OutputInfoDir";
$co_gs_res_limit_key = "ResoureceLimit";
$co_gs_os_type_key = "OSType";
$co_warter_mark_key = "SoftwareWaterMark";
$co_anti_debug_key = "AntiDebug";
$co_tamper_proof_key = "DynTamperProof";
$co_code_obfuscate_key = "CodeObfuscate";
$co_c_standard_c89_key = "C89";
$co_c_standard_c99_key = "C99";
$co_c_standard_misrac_key = "MISRA-C:2004";
$co_res_level_low_key = "low";
$co_res_level_medium_key = "medium";
$co_res_level_high_key = "high";
$co_os_type_win_key = "Windows";
$co_os_type_lin_key = "Linux";
$co_os_type_bios6_key = "BIOS6";

$co_ob_appearance_key = "AppearanceObfuscate";
$co_ob_keep_option_key = "KeepOption";
$co_ob_keep_package_names_key = "KeepPackageNames";
$co_ob_keep_classes_key = "KeepClasses";
$co_ob_keep_class_members_key = "KeepClassMembers";
$co_ob_keep_classes_with_members_key = "KeepClassesWithMembers";
$co_ob_keep_classes_with_members_names_key = "KeepClassesWithMembersNames";
$co_ob_flow_key = "FlowObfuscate";
$co_ob_data_key = "DataObfuscate";
$co_ob_struct_key = "StructObfuscate";
$co_ob_pre_key = "PreObfuscate";
$co_ob_dyn_key = "DynamicObfuscate";
$co_ob_data_type_key = "DataType";
$co_ob_locate_key = "LocateKey";

$co_scope_key = "Scope";
$co_file_name_key = "FileName";
$co_func_name_key = "FunctionName";

@co_code_file_type = ($co_gs_file_type_c_key, $co_gs_file_type_java_key);
@co_c_standard = ($co_c_standard_c89_key, $co_c_standard_c99_key,
                    $co_c_standard_misrac_key);
@co_resource_level = ($co_res_level_low_key, $co_res_level_medium_key, 
                    $co_res_level_high_key);
@co_os_type = ($co_os_type_win_key, $co_os_type_lin_key, $co_os_type_bios6_key);
@co_obfuscate_method = ($co_ob_dyn_key, $co_ob_pre_key, $co_ob_struct_key, 
            $co_ob_data_key, $co_ob_flow_key, $co_ob_appearance_key);

my %co_ft_check_handler = (
    $co_gs_file_type_c_key => \&co_c_file_check, 
    $co_gs_file_type_java_key => \&co_java_file_check, 
);

my %co_conf_func_check_handler = (
    $co_gs_file_type_c_key => \&co_c_func_name_check, 
    $co_gs_file_type_java_key => \&co_java_func_name_check, 
);

sub co_ft_file_check {
    my $file_name = shift(@_);
    my $file_type = shift(@_);

    if (! exists($co_ft_check_handler{$file_type})) {
        return 0;
    }

    return $co_ft_check_handler{$file_type}($file_name);
}

sub co_conf_func_name_check {
    my $func_name = shift(@_);
    my $file_type = shift(@_);

    if ($func_name eq "*") {
        return 1;
    }

    if (! exists($co_conf_func_check_handler{$file_type})) {
        return 0;
    }

    return $co_conf_func_check_handler{$file_type}($func_name);
}

sub co_conf_check_key {
    my $conf = shift(@_);
    my $key = shift(@_);

    if (!exists($conf->{$key})) {
        print("$key missing!\n");
        return 1;
    }

    if (ref($conf->{$key}) ne 'HASH') {
        print("$key is duplicated!\n");
        return 2;
    }

    return 0;
}

sub co_conf_get_value {
    my $conf = shift(@_);
    my $value;

    $value = remove_space_front_back($conf->{value});
    $vlaue =~ s/\r\n//g;

    return $value;
}

sub co_conf_item_parse {
    my $conf = shift(@_);
    my $key = shift(@_);
    my $p = shift(@_);
    my $value = shift(@_);

    #解析FileType
    my $ret = co_conf_check_key($conf, $key);
    if ($ret eq 1) {
        return 1;
    }

    if ($ret eq 2) {
        return 2;
    }

    $$value = remove_space_front_back($conf->{$key}->{value});
    if (!$$value) {
        return 3;
    }

    $p->{$key} = $$value;

    return 0;
}

#解析后检查配置值是否在合法范围
sub co_conf_item_parse_check {
    my $conf = shift(@_);
    my $key = shift(@_);
    my $p = shift(@_);
    my $value = shift(@_);
    my $scope = shift(@_);


    my $ret = co_conf_item_parse($conf, $key, $p, $value);
    if ($ret ne 0) {
        return 1;
    }

    if (!co_array_exist($$value, $scope)) {
        print("$key value $$value invalid!\n");
        return 2;
    }

    return 0;
}

sub co_conf_multi_item_parse {
    my $conf = shift(@_);
    my $conf_key = shift(@_);
    my $item_value_array = shift(@_);
    my $item_conf;
    my $value;
    my @item_conf_array;

    if (!exists($conf->{$conf_key})) {
        return 1;
    }

    $item_conf = $conf->{$conf_key};
    #配置了多条文件->函数
    if (ref($item_conf) eq 'ARRAY') {
        foreach my $c (@$item_conf) {
            push(@item_conf_array, $c);
        }
    } else {
        push(@item_conf_array, $item_conf);
    }

    #遍历所有配置
    foreach my $c (@item_conf_array) {
        $value = co_conf_get_value($c);
        if (!$value) {
            next;
        }

        push(@$item_value_array, $value);
    }

    return 0;
}


sub co_conf_parse_scope {
    my $conf = shift(@_);
    my $p_mod = shift(@_);
    my $code_root_dir = shift(@_);
    my $scope_conf_array = shift(@_);
    my $file_type = shift(@_);
    my $scope_conf;
    my $file_conf;
    my $file_name;
    my $func_name;
    my $locate;
    my $full_path;
    my $scope;
    my @scope_array;

    my $ret = co_conf_check_key($conf, $co_scope_key);
    if ($ret ne 0) {
        return 1;
    }

    $scope_conf = $conf->{$co_scope_key};
    if (!exists($scope_conf->{$co_file_name_key})) {
        print("$co_file_name_key in $p_mod not exist!\n");
        return 2;
    }

    $file_conf = $scope_conf->{$co_file_name_key};
    #配置了多条文件->函数
    if (ref($file_conf) eq 'ARRAY') {
        foreach my $c (@$file_conf) {
            push(@scope_array, $c);
        }
    } else {
        push(@scope_array, $file_conf);
    }

    #遍历所有文件配置
    foreach my $c (@scope_array) {
        $scope = {};
        $file_name = co_conf_get_value($c);
        if (!$file_name) {
            print("$co_file_name_key $file_name in $p_mod not valid!\n");
            return 3;
        }

        if (co_path_is_abs($file_name)) {
            print("$file_name in $p_mod is not a relative path!\n");
            return 4;
        }

        $full_path = co_get_path($code_root_dir, $file_name);
        if ($file_name ne "*") {
            if (! -f $full_path) {
                print("$full_path in $p_mod not exist!\n");
                return 5;
            }

            if (! co_ft_file_check($file_name, $file_type)) {
                print("$file_name is not $file_type type!\n");
                return 8;
            }
        }

        if (exists($c->{$co_func_name_key})) {
            $func_name = co_conf_get_value($c->{$co_func_name_key});
            if (!$func_name) {
                print("$co_file_name_key in $p_mod is NULL!\n");
                return 7;
            }

            if (! co_conf_func_name_check($func_name, $file_type)) {
                print("$func_name is not valid for $file_type type files!\n");
                return 9;
            }
            $scope->{$co_func_name_key} = $func_name;
        } elsif (exists($c->{$co_ob_locate_key})) {
            $locate = co_conf_get_value($c->{$co_ob_locate_key});
            if (!$locate) {
                print("$co_ob_locate_key in $p_mod is NULL!\n");
                return 10;
            }
            $scope->{$co_ob_locate_key} = $locate;
        } else {
            $func_name = '*';
            $scope->{$co_func_name_key} = $func_name;
        }

        $scope->{$co_file_name_key} = $full_path;
        push(@$scope_conf_array, $scope);
    }

    return 0;
}

1;
