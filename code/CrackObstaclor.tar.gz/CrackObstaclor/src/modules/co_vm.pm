package co_vm;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_vm_check);

sub co_vm_check {

    return 0;
}


1;
