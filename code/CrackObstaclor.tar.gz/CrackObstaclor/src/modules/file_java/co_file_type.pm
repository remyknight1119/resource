package file_java::co_file_type;
require Exporter;
use File::Find;

@ISA = qw(Exporter);
@EXPORT = qw(co_java_find_files co_java_file_check co_java_func_name_check);

my @co_code_files;

sub co_java_get_files {
    if (! -d $File::Find::name &&
        $File::Find::name =~/^.*\.(class|jar|war|ear)$/) {
        push(@co_code_files, $File::Find::name);
    }
}

sub co_java_find_files {
    my $code_dir = shift(@_);

    find(\&co_java_get_files, $code_dir);

    return @co_code_files;
}

sub co_java_file_check {
    my $file_name = shift(@_);

    if ($file_name =~ /^.*\.(class|jar|war|ear)$/) {
        return 1;
    }

    return 0;
}

sub co_java_func_name_check {
    return 1;
}

1;
