package common;
require Exporter;
use Tie::File;
use Digest::MD5;
use File::Spec;
use File::Copy;
use Text::Diff;
use Data::Compare;
use Data::Dumper;
use File::Basename;
use Cwd;

@ISA = qw(Exporter);
@EXPORT = qw(
                co_get_tmp_file_name remove_space_front_back get_rand_name
                copy_to_line co_hash_merge remove_space_back co_get_conf_dir
                str_contain_count split_str_not_replace_key co_diff_files
                co_array_exist co_get_rand_file_or_dir_name co_get_abs_cwd
                co_get_diff_name co_file_proc co_data_cmp co_get_install_dir 
                co_print_data co_os_is_windows co_path_is_abs co_get_path 
                co_get_lib_dir co_get_rand_array co_gen_rand_str co_path_convert
                co_intiger_pack 
                $co_map_file_name $co_cmd_name $co_product_name 
             );

$co_product_name = "CrackObstaclor";
$co_cmd_name = "crackobstaclor";
my $co_tmp_prefix = "tmp_";
my $co_conf_dir_name = "conf";
my $co_lib_dir_name = "lib";
$co_map_file_name = "$co_product_name.map";

sub gen_md5_str {
    my ($str) = shift(@_);
    my $md5 = Digest::MD5->new;

    $md5->add($str);

    return $md5->hexdigest;
}

sub co_gen_rand_str {
    my $s = shift(@_);
    $str = rand();

    $str = gen_md5_str($str); 

    return $s.$str;
}

sub co_get_tmp_file_name {
    my $root_dir = shift(@_);
    my $file_name;
    my $str;

    while (1) {
        $str = co_gen_rand_str();
        $file_name = co_get_path($root_dir, $str.".tmp"); 
        if (! -f $file_name) {
            last;
        }
    }

    return $file_name;
}

sub co_get_rand_file_or_dir_name {
    my $dir = shift(@_);
    my $name;
    my $str;

    while (1) {
        $str = co_gen_rand_str();
        $name = $dir.$co_tmp_prefix.$str; 
        if (! -e $name) {
            last;
        }
    }

    return $name;
}

sub get_rand_name {
    my $name;
    my $str;

    $str = co_gen_rand_str();

    $name = $co_tmp_prefix.$str; 

    return $name;
}

sub split_str_not_replace_key {
    my ($str) = shift(@_);
    my ($key) = shift(@_);
    my $new_key;
    my @sp;

    while (1) {
        $new_key = co_gen_rand_str();
        if ($str !~ /$new_key/) {
            last;
        }
    }

    $str =~ s/$key/$new_key$key$new_key/g;

    @sp = split(/$new_key/, $str);

    #删除空行
    return grep(/\S/, @sp);
}

#去掉后空格 
sub remove_space_back {
    my ($str) = @_;

    $str =~ s/\s+$//g;

    return $str;
}


#去掉前后空格 
sub remove_space_front_back {
    my ($str) = @_;

    $str =~ s/^(\s+)|(\s+)$//g;

    return $str;
}

sub co_data_cmp {
    my $data1 = shift(@_);
    my $data2 = shift(@_);

    my $c = new Data::Compare;

    return $c->Cmp($data1, $data2);
}

sub co_hash_merge {
    my ($hash1) = shift(@_);
    my (%hash2) = @_;
    my $key;

    foreach $key (keys %hash2) {
        $hash1->{$key} = $hash2{$key};
    }
}

#返回$str中包含$key的个数
sub str_contain_count {
    my ($str) = shift(@_);
    my ($key) = shift(@_);
    my $count = 0;

    $count = ($str =~ s/$key/$key/g);

    return $count;
}

sub co_array_exist {
    my $key = shift(@_);
    my $array = shift(@_);
    my @output;

    @output = grep(/^$key$/, @$array);
    foreach my $a (@output) {
        if ($a eq $key) {
            return 1;
        }
    }

    return 0;
}

sub co_get_abs_cwd {
    my $file = shift(@_);
    my $path_curf = File::Spec->rel2abs($file);
    my ($vol, $dirs, $file) = File::Spec->splitpath($path_curf);

    return $dirs;
}

sub co_get_install_dir {
    my $bin_file = shift(@_);
    my $bin_dir;

    #如果是链接文件，则需要找到源
    while (-l $bin_file) {
        $bin_file = readlink($bin_file);
    }
    $bin_dir = co_get_abs_cwd($bin_file);

    return dirname($bin_dir);
}

sub co_os_is_windows {
    my $dir;
    
    $dir = co_get_abs_cwd(__FILE__);
    if ($dir =~ /^\\/) {
        return 1;
    }

    return 0;
}

sub co_path_convert {
    my $dir = shift(@_);

    if (co_os_is_windows()) {
        $dir =~ s/\//\\/g;
    }

    return $dir;
}

sub co_path_is_abs {
    my $path = shift(@_);

    if (co_os_is_windows()) {
        if ($path =~ /^\\/ || $path =~ /^[\wA-Z]\:/
            || $path =~ /^[\wa-z]\:/) {
            return 1;
        }
        return 0;
    }

    if ($path =~ /^\//) {
        return 1;
    }
    return 0;
}

sub co_get_path {
    my $p = shift(@_);

    if ($p =~ /^\// && co_os_is_windows()) {
        $p =~ s/\//\\/;
    }

    foreach my $d (@_) {
        if (co_os_is_windows()) {
            $p = "$p\\$d";
        } else {
            $p = "$p/$d";
        }
    }

    return $p;
}

sub co_get_conf_dir {
    my $install_dir = shift(@_);

    return co_get_path($install_dir, $co_conf_dir_name);
}

sub co_get_lib_dir {
    my $install_dir = shift(@_);

    return co_get_path($install_dir, $co_lib_dir_name);
}


#对比file1和file2，生成差异信息
sub co_diff_files {
    my $file1 = shift(@_);
    my $file2 = shift(@_);
    my $handle = shift(@_);

    my $diff = diff($file1, $file2, {STYLE => "Unified"});
    print $handle $diff;
}

sub co_get_diff_name {
    my $root_dir = shift(@_);
    my $seq = shift(@_);
    my $info = shift(@_);

    return $root_dir."/".$$seq."-$info".".diff";
}

sub co_file_proc {
    my $src_file = shift(@_);
    my $root_dir = shift(@_);
    my $diff_file = shift(@_);
    my $proc_func = shift(@_);
    my $diff_handle;
    my @file_array;
    my $tmp_file = co_get_tmp_file_name($root_dir);

    copy($src_file, $tmp_file) or die("Copy $src_file to $tmp_file failed!");
    tie(@file_array,'Tie::File', $tmp_file) or die("Tile $tmp_file failed!\n");

    &$proc_func(\@file_array, @_);

    #生成diff文件
    open($diff_handle, ">>$diff_file") || die ("Open $diff_file failed!\n");
    co_diff_files($src_file, $tmp_file, $diff_handle);
    close($diff_handle);

    untie(@file_array);
    move($tmp_file, $src_file) or die("Move $tmp_file to $src_file failed!");
}

sub co_print_data {
    my $data = shift(@_);

    print Dumper($data);
}

sub co_get_rand_array {
    my $size = shift(@_);
    my $index;
    my @tmp;
    my @array;

    for($index = 0; $index < $size; $index++) {
        $tmp[$index] = $index;
    }

    while(1) {
        $size = @tmp;
        if ($size == 0) {
            last;
        }
        $index = int(rand($size));
        push(@array, $tmp[$index]);
        splice(@tmp, $index, 1);
    }

    return @array;
}

sub co_intiger_pack {
    my $value = shift(@_);
    my $type = shift(@_);
    my $format;

    if ($type =~ /^\s*int\s*$/) {
        $format = "l";
    } elsif ($type =~ /^\s*unsigned\s\s*int\s*$/) {
        $format = "L";
    } elsif ($type =~ /^\s*short\s*$/) {
        $format = "s";
    } elsif ($type =~ /^\s*unsigned\s\s*short\s*$/) {
        $format = "S";
    } else {
        print STDERR ("Unknow intiger type $type\n");
    }
    
    return pack("$format", $value);
}


1;
