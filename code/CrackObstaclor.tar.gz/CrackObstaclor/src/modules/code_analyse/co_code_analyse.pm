package code_analyse::co_code_analyse;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_code_analyse_handler);

sub co_code_analyse_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my %warrant = @_;

    return 0;
}


1;
