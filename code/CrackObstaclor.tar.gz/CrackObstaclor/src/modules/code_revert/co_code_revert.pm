package co_code_revert;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_code_revert_handler);

sub co_code_revert_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my %warrant = @_;

    return 0;
}


1;
