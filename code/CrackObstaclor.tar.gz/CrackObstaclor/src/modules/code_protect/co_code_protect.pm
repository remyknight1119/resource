package code_protect::co_code_protect;
require Exporter;
use code_protect::water_mark::co_water_mark;
use code_protect::anti_debug::co_anti_debug;
use code_protect::tamper_proof::co_tamper_proof;
use code_protect::obfuscate::co_code_obfuscate;
use config::co_conf_common;
use common;
use co_license;
use File::Path;
use File::Find;
use File::Basename;
use File::Copy::Recursive qw(dircopy);

@ISA = qw(Exporter);
@EXPORT = qw(co_cp_gs_handler co_code_protect_handler);

my @co_cp_sub_modules = (
    $co_warter_mark_key,
    $co_anti_debug_key,
    $co_tamper_proof_key,
    $co_code_obfuscate_key,
);

my %co_cp_sub_handler = (
    $co_warter_mark_key => \&co_water_mark_handler,
    $co_anti_debug_key => \&co_anti_debug_handler,
    $co_tamper_proof_key => \&co_tamper_proof_handler,
    $co_code_obfuscate_key => \&co_obfusate_handler,
);

sub co_cp_gs_handler {
    my $conf = shift(@_);
    my $global_settings = shift(@_);
    my $value;
    my $key;
    my $full_path;
    my @itme_value_array;

    #解析FileType
    my $ret = co_conf_item_parse_check($conf, $co_gs_file_type_key,
                $global_settings, \$value, \@co_code_file_type);

    if ($ret eq 1) {
        return 1;
    }

    if ($ret eq 2) {
        return 2;
    }

    if ($value eq $co_gs_file_type_c_key) {
        #解析CStandard
        my $ret = co_conf_item_parse_check($conf->{$co_gs_file_type_key},
            $co_gs_file_cstandard_key, $global_settings, \$value,
            \@co_c_standard);

        if ($ret eq 1) {
            return 3;
        }

        if ($ret eq 2) {
            return 4;
        }

        #解析OSType
        my $ret = co_conf_item_parse_check($conf->{$co_gs_file_type_key},
            $co_gs_os_type_key, $global_settings, \$value, \@co_os_type);

        if ($ret ne 0) {
            return 5;
        }
        #解析OSType完毕
    }

    if ($value eq $co_gs_file_type_java_key) {
        #解析LibraryJars
        co_conf_multi_item_parse($conf->{$co_gs_file_type_key},
            $co_gs_library_jars_key, \@itme_value_array);
    }

    $global_settings->{$co_gs_library_jars_key} = [@itme_value_array];
    #解析FileType完毕

    #解析InputDir
    my $ret = co_conf_item_parse($conf, $co_gs_input_dir_key,
                $global_settings, \$value);

    if ($ret ne 0) {
        return 6;
    }

    if (!co_path_is_abs($value)) {
        print("$value is not a absolute path!\n");
        return 7;
    }

    if (! -d $value) {
        print("$value is not existed!\n");
        return 8;
    }
    #解析InputDir完毕

    #检查LibraryJars是否存在
    foreach my $item (@itme_value_array) {
        if (!co_path_is_abs($item)) {
            $full_path = co_get_path($value, $item);
        } else {
            $full_path = $item;
        }
        if (! -e $full_path) {
            print("$full_path is not existed!\n");
            return 9;
        }
    }

    #解析OutputCodeDir
    $key = $co_gs_output_code_dir_key;
    my $ret = co_conf_item_parse($conf, $key,
                $global_settings, \$value);
    if ($ret ne 0 || !$value) {
        return 10;
    }

    if (!co_path_is_abs($value)) {
        print("$value is not a absolute path!\n");
        return 11;
    }

    if ($value eq $global_settings{$co_gs_input_dir_key}) {
        print("Output code dir is same as input dir!\n");
        return 12;
    }
    #解析OutputCodeDir完毕

    #解析OutputInfoDir
    my $ret = co_conf_item_parse($conf, $co_gs_output_info_dir_key,
                $global_settings, \$value);

    if ($ret ne 0) {
        return 13;
    }

    if (!co_path_is_abs($value)) {
        print("$value is not a absolute path!\n");
        return 14;
    }
    #解析OutputInfoDir完毕

    #解析ResoureceLimit
    my $ret = co_conf_item_parse_check($conf, $co_gs_res_limit_key,
                $global_settings, \$value, \@co_resource_level);

    if ($ret ne 0) {
        return 15;
    }
    #解析ResoureceLimit完毕
 
    return 0;
}

sub co_cp_gen_diff {
}

sub co_cp_gen_map {
}

sub co_code_protect_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my $warrant = shift(@_);
    my %global_settings;
    my %map_info;
    my @enabled_mod;
    my $modify_seq = 1;
    my $input_dir;
    my $output_code_dir;
    my $output_info_dir;
    my $orig_code_dir;
    my $ret;

    if (!exists($conf->{$co_global_settings_key})) {
        print("$co_global_settings_key missing!\n");
        return 1;
    }

    #解析全局配置
    $ret = co_cp_gs_handler($conf->{$co_global_settings_key},
            \%global_settings);
    if ($ret ne 0) {
        return 2;
    }

    #查看哪些功能开启
    foreach my $sub_mod (@co_cp_sub_modules) {
        if (exists($conf->{$sub_mod})) {
            #匹配授权
            if (!co_array_exist($global_settings{$co_gs_file_type_key},
                    \@{$warrant->{$co_file_scope_name}})) {
                return 3;
            }
            
            if (!co_array_exist($sub_mod,
                    \@{$warrant->{$co_func_scope_name}})) {
                return 4;
            }
            
            #记录合法的功能
            push(@enabled_mod, $sub_mod);
        }
    }

    if (!@enabled_mod) {
        return 5;
    }

    $output_code_dir = $global_settings{$co_gs_output_code_dir_key};
    $output_info_dir = $global_settings{$co_gs_output_info_dir_key};
    $input_dir = $global_settings{$co_gs_input_dir_key};
    #复制文件到输出代码目录
    if ($global_settings{$co_gs_file_type_key} ne
        $co_gs_file_type_java_key) {
        my $base_dir = dirname($output_info_dir);
        if (! -d $base_dir) {
            mkpath($base_dir) or die("Create $base_dir failed\n!");
        }
        dircopy($input_dir, $output_code_dir) or 
        die("Copy $code_dir to $output_dir failed!");
    }
    $orig_code_dir = $input_dir;

    if (! -d $output_info_dir) {
        mkpath($output_info_dir) or die("Create $output_info_dir failed\n!");
    }

    #依次执行各个子功能
    foreach my $sub_mod (@enabled_mod) {
        $ret = $co_cp_sub_handler{$sub_mod}($root_dir, $conf->{$sub_mod}, 
            \%global_settings, \$modify_seq, \%map_info);
        if ($ret ne 0) {
            if ($orig_code_dir ne $input_dir) {
                rmtree($orig_code_dir);
            }
            return $ret;
        }
    }

    #生成总体diff文件
    co_cp_gen_diff($orig_code_dir, $output_code_dir, $output_info_dir);
    co_cp_gen_map(\%map_info, $output_info_dir);

    return 0;
}


1;
