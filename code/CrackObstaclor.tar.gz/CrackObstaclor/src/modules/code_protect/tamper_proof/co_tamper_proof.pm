package code_protect::tamper_proof::co_tamper_proof;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_tamper_proof_handler);

sub co_tamper_proof_handler {

    return 0;
}


1;
