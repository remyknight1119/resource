package code_protect::water_mark::co_water_mark;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_water_mark_handler);

sub co_water_mark_handler {

    return 0;
}


1;
