package code_protect::anti_debug::co_anti_debug;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_anti_debug_handler);

sub co_anti_debug_handler {

    return 0;
}


1;
