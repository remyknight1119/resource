package code_protect::obfuscate::ob_data::co_ob_data;
require Exporter;
use common;
use co_file_type;
use config::co_conf_common;
use code_protect::obfuscate::ob_data::c_code::co_c_ob_data;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_data_handler co_ob_data_config_parse);

my $co_ob_data_int = "Int";
my $co_ob_data_str = "Str";
my $co_ob_data_bool = "Bool";
my $co_ob_data_float = "Float";
my $co_ob_data_array = "Array";
my $co_ob_data_pre_proc = "pre_proc";

my @type_scope = (
        $co_ob_data_str, 
        $co_ob_data_int,
        $co_ob_data_bool, 
        $co_ob_data_float,
        $co_ob_data_array,
    );

my %ob_data_obfuscate = (
    $co_gs_file_type_c_key => {
        $co_ob_data_pre_proc => \&co_c_ob_data_pre_proc, 
        $co_ob_data_int => \&co_c_ob_data_int,
        $co_ob_data_str => \&co_c_ob_data_str, 
        $co_ob_data_bool => \&co_c_ob_data_bool, 
        $co_ob_data_float => \&co_c_ob_data_float,
        $co_ob_data_array => \&co_c_ob_data_array,
    },
    $co_gs_file_type_java_key => {
    },
);

sub co_ob_data_config_parse {
    my $root_dir = shift(@_);
    my $config = shift(@_);
    my $code_dir = shift(@_);
    my $file_type = shift(@_);
    my $mode_name = "ob_data";
    my $type;
    my $type_value;
    my $locate;
    my $conf;
    my $ret;
    my @type_array;
    my @scope_conf_array;

    if (!exists($root_dir->{$co_ob_data_type_key})) {
        print("$co_ob_data_type_key missing!\n");
        return 1;
    }

    $type = $root_dir->{$co_ob_data_type_key};
    if (ref($type) eq 'ARRAY') {
        foreach my $c (@$type) {
            push(@type_array, $c);
        }
    } else {
        push(@type_array, $type);
    }

    foreach my $c (@type_array) {
        $conf = {};
        $type_value = co_conf_get_value($c);
        if (!$type_value) {
            return 2;
        }
        if (!co_array_exist($type_value, \@type_scope)) {
            return 3;
        }
        $ret = co_conf_parse_scope($c, $mode_name, $code_dir,
            \@scope_conf_array, $file_type);
        if ($ret ne 0) {
            print("Parse scope failed!\n");
            return 4;
        }

        foreach my $s (@scope_conf_array) {
            if (!exists($s->{$co_ob_locate_key})) {
                return 5;
            }
        }
        $conf->{$co_ob_data_type_key} = $type_value;
        $conf->{$co_scope_key} = [@scope_conf_array];
        push(@$config, $conf);
    }

    return 0;
}

sub co_ob_data_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my $global_settings = shift(@_);
    my $modify_seq = shift(@_);
    my $code_files = shift(@_);
    my $p_mod = shift(@_);
    my $map_info = shift(@_);
    my $file_type;
    my $diff_file;
    my $pre_proc;
    my $proc;
    my $ret;
    my $diff_info = "data_obfuscate";
    my @data_ob_conf;
    my %files;
    my %dfiles;

    $file_type = $global_settings->{$co_gs_file_type_key};
    $ret = co_ob_data_config_parse($conf, \@data_ob_conf,
                    $global_settings->{$co_gs_output_code_dir_key},
                    $file_type);
    if ($ret ne 0) {
        print("Parse data config failed!\n");
        return 1;
    }

    $diff_file = 
    co_get_diff_name($global_settings->{$co_gs_output_info_dir_key},
        $modify_seq, $diff_info);
  
    $rand_str = co_gen_rand_str();
    $pre_proc = $ob_data_obfuscate{$file_type}{$co_ob_data_pre_proc};

    #遍历数据类型
    foreach my $df (@data_ob_conf) {
        #找到文件类型和数据类型对应的处理函数
        $proc = $ob_data_obfuscate{$file_type}{$df->{$co_ob_data_type_key}};
        #找到数据所在文件
        %dfiles = co_ft_get_dfiles($code_files, $df->{$co_scope_key});
        #存储文件名信息
        foreach my $src_file (keys %dfiles) {
            $files{$src_file} = "in";
        }
    }

    foreach my $src_file (keys %files) {
        co_file_proc($src_file, $root_dir, $diff_file,
            $pre_proc, $rand_str, $root_dir, $map_info,
                $global_settings->{$co_gs_res_limit_key});
    }

    #遍历数据类型
    foreach my $df (@data_ob_conf) {
        #找到文件类型和数据类型对应的处理函数
        $proc = $ob_data_obfuscate{$file_type}{$df->{$co_ob_data_type_key}};
        #找到数据所在文件
        %dfiles = co_ft_get_dfiles($code_files, $df->{$co_scope_key});
        #遍历文件，开始数据加密
        foreach my $src_file (keys %dfiles) {
            my  $data = $dfiles{$src_file};
            co_file_proc($src_file, $root_dir, $diff_file,
                $proc, $data, $map_info,
                $global_settings->{$co_gs_res_limit_key},
                $rand_str);
        }
    }

    return 0;
}


1;
