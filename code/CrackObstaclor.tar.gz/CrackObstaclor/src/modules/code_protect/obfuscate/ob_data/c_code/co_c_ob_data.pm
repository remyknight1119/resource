package code_protect::obfuscate::ob_data::c_code::co_c_ob_data;
require Exporter;
use Tie::File;
use common;
use file_c::co_function_parse;
use code_protect::obfuscate::ob_flow::c_code::co_ob_obfuscate;

@ISA = qw(Exporter);
@EXPORT = qw(co_c_ob_data_int co_c_ob_data_str co_c_ob_data_bool
            co_c_ob_float co_c_ob_data_array co_c_ob_data_pre_proc);

my $co_c_dc_str_prefix = "dc_str_";
my $co_c_dc_num_prefix = "dc_num_";
my $co_c_dc_data_array_prefix = "co_data_";
my $co_c_data_offset = 10;
my $co_c_dc_str_input = "short *d, unsigned int len";

sub co_c_ob_data_pre_proc {
    my $file_array = shift(@_);
    my $rand_str = shift(@_);
    my $root_dir = shift(@_);
    my $map_info = shift(@_);
    my $res_limit = shift(@_);
    my $dc_str = $co_c_dc_str_prefix.$rand_str;
    my $dc_num = $co_c_dc_num_prefix.$rand_str;
    my $code_file;
    my $line = 0;
    my @tmp_file_array;
    my @func_array;

    $tmp_file = co_get_tmp_file_name($root_dir);
    open($code_file, ">$tmp_file") || die("Open $tmp_file failed!\n");
    print $code_file <<EOF;
char *$dc_str($co_c_dc_str_input)
{
    int i;
    char *d2;

    d2 = (char *)d;
    for (i = 0; i < len; i++) {
        d2[i] = d[i] - $co_c_data_offset;
    }
    d2[i] = 0;
    return d2;
}

#define $dc_num(ds, type) \\
({type ret; \\
    $dc_str(ds, sizeof(type)); \\
    ret = *((type *)ds);\\
ret;})

EOF
    close($code_file);
    tie(@tmp_file_array,'Tie::File', $tmp_file) or die("Tile $tmp_file failed!\n");
    #使用代码混淆保护解密函数
    push(@func_array, $dc_str);
    &co_ob_flow_proc_c(\@tmp_file_array, \@func_array, $map_info,
        $res_limit);
    foreach my $c (@$file_array) {
        if ($c !~ /\#include/) {
            last;
        }
        $line++;
    }
    splice(@$file_array, $line, 0, @tmp_file_array);
    untie(@tmp_file_array);
    unlink($tmp_file);
}

sub co_c_ob_data_encrypt {
    my $str = shift(@_);
    my $len = shift(@_);
    my $en_str;
    my $nl;

    for (my $i = 0 ; $i < $len ; $i++) {
        $nl = unpack("c2", substr($str, $i));
        $nl += $co_c_data_offset;
        $en_str .= "$nl,";
    }

    chop($en_str);

    return $en_str;
}

sub _co_c_ob_data_int {
    my $file_array = shift(@_);
    my $line = shift(@_);
    my $s = shift(@_);
    my $dec_func = shift(@_);
    my $str;
    my $value;
    my $orig_str;
    my $en_str;
    my $data_array_name;
    my $len;
    my $st;
    my $type;
    my @str_array;

    $str = $$file_array[$line];
    if ($str !~ /=/) {
        return;
    }
    @str_array = split(/=/, $str);
    $value = $str_array[-1];
    $value =~ s/;//;
    $value = remove_space_front_back($value); 

    #解析语句，得到变量名
    my %param = &co_parse_one_line_param($str);
    foreach my $p (keys %param) {
        $type = $param{$p};
        $type =~ s/const//;
        $type = remove_space_front_back($type); 
        $data_array_name = &co_gen_rand_str($co_c_dc_data_array_prefix); 
        $orig_str = &co_intiger_pack($value, $type); 
        $len = length $orig_str;
        #得到保存加密数据的数组的名
        $en_str = &co_c_ob_data_encrypt($orig_str, $len);
        $en_str = "static short $data_array_name\[\] = \{$en_str\};";
        push(@$s, $en_str);
        #重新定义变量
        $st = "#define $p $dec_func\($data_array_name, $type\)";
        push(@$s, $st);
    }

    $$file_array[$line] = " ";
}

sub co_c_ob_data_int {
    my $file_array = shift(@_);
    my $data = shift(@_);
    my $map_info = shift(@_);
    my $res_limit = shift(@_);
    my $rand_str = shift(@_);
    my $dc_int = $co_c_dc_num_prefix.$rand_str;
    my $insert_line;
    my $match;
    my @s;

    for (my $i = 0; $i < @$file_array; $i++) {
        my $c = $$file_array[$i];
        if ($c =~ /$dc_num/ && !$insert_line) {
            for (; $i < @$file_array; $i++) {
                if ($$file_array[$i] =~ /\}\)/) {
                    last;
                }
            }
            $insert_line = $i + 1;
            next;
        }

        $match = 0;
        foreach my $d (@$data) {
            if ($c =~ /$d/) {
                $match = 1;
                last;
            }
        }
        if ($match eq 1) {
            if (!$insert_line) {
                return;
            }
            &_co_c_ob_data_int($file_array, $i, \@s, $dc_int);
        }
    }
 
    #插入保存加密数据的数组
    splice(@$file_array, $insert_line, 0, @s);
}

sub _co_c_ob_data_str {
    my $file_array = shift(@_);
    my $line = shift(@_);
    my $s = shift(@_);
    my $dec_func = shift(@_);
    my $str;
    my $orig_str;
    my $en_str;
    my $data_array_name;
    my $len;
    my $st;
    my @str_array;

    $str = $$file_array[$line];
    #一行代码中可能有多个字符串
    @str_array = split(/\"/, $str);
    for(my $i = 1; $i < @str_array; $i += 2) {
        $orig_str = $str_array[$i];
        $len = length $orig_str;
        #得到保存加密数据的数组的名
        $data_array_name = co_gen_rand_str($co_c_dc_data_array_prefix); 
        $en_str = co_c_ob_data_encrypt($orig_str, $len);
        $en_str = "static short $data_array_name\[\] = \{$en_str\};";
        push(@$s, $en_str);
        #赋值语句
        if ($str =~ /=/) {
            #解析语句，得到变量名
            my %param = &co_parse_one_line_param($str);
            foreach my $p (keys %param) {
                #重新定义变量
                $st = "#define $p $dec_func\($data_array_name, $len\)";
                push(@$s, $st);
            }
            $$file_array[$line] = " ";
        } else {
            #用解密函数替代原来的字符串
            $$file_array[$line] =~ 
            s/\"$orig_str\"/$dec_func\($data_array_name, $len\)/;
        }
    }
}

sub co_c_ob_data_str {
    my $file_array = shift(@_);
    my $data = shift(@_);
    my $map_info = shift(@_);
    my $res_limit = shift(@_);
    my $rand_str = shift(@_);
    my $dc_str = $co_c_dc_str_prefix.$rand_str;
    my $line = 0;
    my $insert_line;
    my $match;
    my @s;

    $s[0] = "extern char *$dc_str($co_c_dc_str_input);";

    foreach my $c (@$file_array) {
        if ($c =~ /$dc_str/ && !$insert_line) {
            $insert_line = $line;
        }

        $match = 0;
        foreach my $d (@$data) {
            if ($c =~ /$d/) {
                $match = 1;
                last;
            }
        }
        if ($match eq 1) {
            if (!$insert_line) {
                return;
            }
            &_co_c_ob_data_str($file_array, $line, \@s, $dc_str);
        }
        $line++;
    }
 
    #插入保存加密数据的数组
    splice(@$file_array, $insert_line, 0, @s);
}

sub co_c_ob_data_bool {
}

sub co_c_ob_data_float {
}

sub co_c_ob_data_array {
}

1;
