package code_protect::obfuscate::ob_flow::co_ob_flow;
require Exporter;
use common;
use co_file_type;
use config::co_conf_common;
use file_c::co_code_format;
use code_protect::obfuscate::ob_flow::c_code::co_ob_obfuscate;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_flow_handler);

my %co_ob_flow_proc = (
    $co_gs_file_type_c_key => \&co_ob_flow_proc_c, 
    $co_gs_file_type_java_key => \&co_ob_flow_proc_java, 
);

sub co_ob_flow_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my $global_settings = shift(@_);
    my $modify_seq = shift(@_);
    my $code_files = shift(@_);
    my $p_mod = shift(@_);
    my $map_info = shift(@_);
    my $diff_file;
    my @scope_conf_array;
    my %tfile;
    my $func;
    my $proc;
    my $diff_info = "flow_obfuscate";

    print("Flow handler, $root_dir, $$modify_seq \n");
    my $ret = co_conf_parse_scope($conf, $p_mod,
        $global_settings->{$co_gs_output_code_dir_key},
        \@scope_conf_array,
        $global_settings->{$co_gs_file_type_key});
    if ($ret ne 0) {
        print("Parse scope failed!\n");
        return 1;
    }

    %tfiles = co_ft_get_tfiles($code_files, \@scope_conf_array);
    $diff_file = 
    co_get_diff_name($global_settings->{$co_gs_output_info_dir_key},
        $modify_seq, $diff_info);
    
    $proc = $co_ob_flow_proc{$global_settings->{$co_gs_file_type_key}};
    if (!%tfiles) {
        print("No file to be proccessed!\n");
        return 2;
    }
    #遍历文件，开始混淆
    foreach my $src_file (keys %tfiles) {
        my  $funcs = $tfiles{$src_file};
        co_file_proc($src_file, $root_dir, $diff_file,
                $proc, $funcs, $map_info,
                $global_settings->{$co_gs_res_limit_key});
    }

    $modify_seq++;

    return 0;
}


1;
