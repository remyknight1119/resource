package code_protect::obfuscate::ob_flow::java_code::co_ob_obfuscate;
require Exporter;
use common;
use co_file_type;
use config::co_conf_common;
use file_c::co_code_format;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_flow_proc_java);

sub co_ob_flow_proc_java {
    my $file_array = shift(@_);
    my $func_array = shift(@_);
    my $map_info = shift(@_);
    my %code_info;
    my $ret;

    return;
}


1;
