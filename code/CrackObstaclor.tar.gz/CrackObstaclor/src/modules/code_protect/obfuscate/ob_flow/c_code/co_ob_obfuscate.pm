package code_protect::obfuscate::ob_flow::c_code::co_ob_obfuscate;
require Exporter;
use common;
use co_file_type;
use config::co_conf_common;
use file_c::co_code_format;
use file_c::co_code_parse;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_flow_proc_c co_ob_c_split_func);

sub co_ob_c_split_func {
    my ($file_array) = shift(@_);
    my ($start_line) = shift(@_);
    my $layer = 0;
    my $if = 0;
    my $goto = 0;
    my $str;
    my @split_array;
    my @block;

    while (@$file_array != $start_line) {
        $str = $$file_array[$start_line];
#        print("$str\n");
        #遇到空行
        if ($str =~ /^\s*$/) {
            splice(@$file_array, $start_line, 1);
            next;
        }
        if ($str =~ /\{\s*$/) {
            $layer++;
            if ($layer == 1 && $if == 1) {
                $if = 2;
            }
        } elsif ($str =~ /\}\s*$/) {
            $layer--;
            if ($layer == 0 && $if == 2) {
                $if = 3;
            }
        }
        # if (...)
        #   aaa;
        if ($layer == 0 && $if == 1) {
            $if = 3;
            push(@block, $str);
            splice(@$file_array, $start_line, 1);
            next;
        }
        # $if == 3意味着一个if块或else块结束
        if ($if == 3 && $str !~ /^\s*else\s*/ && $str !~ /\}\s*$/) {
            $if = 0;
            if ($goto == 0) {
                push(@split_array, [@block]);
                @block = ();
            }
        }
        
        if ($if == 3 && $str =~ /^\s*else\s*/) {
            $if = 1;
        }
        #匹配到if语句
        if ($layer == 0 && $str =~ /^\s*if\s*\(.*\)/) {
            $if = 1;
        }
        #匹配到xxx:，即goto语句跳转标签
        if ($layer == 0 && $if == 0 &&
            $str =~ /^\s*.*\s*\:$/ && $str !~ /=/) {
            $goto = 1;
        }

        if ($goto != 0 && $layer == 0 && $if == 0 &&
            ($str =~ /^\s*return\s.*;\s*$/ || $str =~ /^\s*goto\s\s*.*;\s*$/) ||
                $str =~ /^\s*break\s.*;\s*$/) {
            $goto = 0;
        }

        if ($layer < 0) {
            if (@block != 0) {
                push(@split_array, [@block]);
            }
            last;
        }
        push(@block, $str);
        #删除当前行
        splice(@$file_array, $start_line, 1);
        if ($layer == 0 && ($str =~ /;\s*$/ || $str =~ /\}\s*$/) &&
            $if == 0 && $goto == 0) {
            push(@split_array, [@block]);
            @block = ();
        }
    }

    return @split_array;
}

sub co_ob_flow_obf_func1 {
    my ($file_array) = shift(@_);
    my ($code_info) = shift(@_);
    my $global_var;
    my $line;
    my $size;
    my $int_array_str;
    my $int_array_name;
    my $int_p;
    my $seq;
    my @split_array;
    my @seq_array;
    my @switch_seq;
    my @code_array;

    $line = 
    $code_info->{$co_code_start_line_key};
    @split_array = co_ob_c_split_func($file_array, $line); 
    $size = @split_array;
    if ($size < 2) {
        return;
    }
    @seq_array = co_get_rand_array($size);
    @switch_seq = co_get_rand_array($size);
    $int_array_name = co_gen_rand_str("co_"); 
    $int_array_str = "\tstatic int ".$int_array_name.'[] = {';
    foreach my $seq (@seq_array) {
        $int_array_str = $int_array_str."$seq,";
    }
    chop($int_array_str);
    $int_array_str = $int_array_str.'};';
    #插入全局数组代码
    push(@code_array, $int_array_str);
    $int_p = co_gen_rand_str("co_int_"); 
    push(@code_array, "\tint *$int_p = &$int_array_name\[0\];");

    push(@code_array, "\twhile (1) {");
    push(@code_array, "\t\tswitch (*$int_p) {");
    
    for (my $index = 0; $index < $size; $index++) {
        $seq = $switch_seq[$index];
        push(@code_array, "\t\t\tcase $seq_array[$seq]:");
        push(@code_array, "\t\t\t\t$int_p++;");
        push(@code_array, @{$split_array[$seq]});
        if ($seq == $size - 1) {
            push(@code_array, "\t\t\t\treturn;");
        } else {
            push(@code_array, "\t\t\t\tbreak;");
        }
    }
    push(@code_array, "\t\t}");
    push(@code_array, "\t}");
    splice(@$file_array, $line, 0, @code_array);
}

my @co_obf_res_low_algorithm = (\&co_ob_flow_obf_func1);
my %co_obf_res = (
    $co_res_level_low_key => \@co_obf_res_low_algorithm,
);

#为每个文件随机选取混淆算法
sub co_ob_obfuscate_code { 
    my $algorithm = shift(@_);

    my $size = @$algorithm;
    my $index = int(rand($size));

    $$algorithm[$index](@_);
}

sub co_ob_flow_proc_c {
    my $file_array = shift(@_);
    my $func_array = shift(@_);
    my $map_info = shift(@_);
    my $res_limit = shift(@_);
    my %code_info;
    my $ret;

    #解析代码信息
    %code_info = co_c_code_parser($file_array, $func_array);
    if (! %code_info) {
        die("Parse failed!\n");
    }

    #混淆代码
    foreach my $func (@{$code_info{$co_func_array_key}}) {
        co_ob_obfuscate_code($co_obf_res{$res_limit}, $file_array, 
            $func);
    }
}


1;
