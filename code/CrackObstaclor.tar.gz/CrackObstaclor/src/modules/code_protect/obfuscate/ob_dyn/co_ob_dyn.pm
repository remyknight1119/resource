package code_protect::obfuscate::ob_dyn::co_ob_dyn;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_dyn_handler);

sub co_ob_dyn_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);

    return 0;
}


1;
