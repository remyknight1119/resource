package code_protect::obfuscate::ob_struct::co_ob_struct;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_struct_handler);

sub co_ob_struct_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);

    return 0;
}


1;
