package code_protect::obfuscate::co_code_obfuscate;
require Exporter;
use code_protect::obfuscate::ob_appearance::co_ob_appearance;
use code_protect::obfuscate::ob_data::co_ob_data;
use code_protect::obfuscate::ob_dyn::co_ob_dyn;
use code_protect::obfuscate::ob_flow::co_ob_flow;
use code_protect::obfuscate::ob_pre::co_ob_pre;
use code_protect::obfuscate::ob_struct::co_ob_struct;
use config::co_conf_common;
use co_file_type;

@ISA = qw(Exporter);
@EXPORT = qw(co_obfusate_handler);

my %co_obfuscate_sub_handler = (
    $co_ob_dyn_key => \&co_ob_dyn_handler, 
    $co_ob_pre_key => \&co_ob_pre_handler, 
    $co_ob_flow_key => \&co_ob_flow_handler, 
    $co_ob_struct_key => \&co_ob_struct_handler, 
    $co_ob_data_key => \&co_ob_data_handler, 
    $co_ob_appearance_key => \&co_ob_appearance_handler,
);

sub co_obfusate_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my $global_settings = shift(@_);
    my $modify_seq = shift(@_);
    my @enabled_mod;
    my @code_files;
    my $file_type;
    my $code_dir;
    my $ret;

    $file_type = $global_settings->{$co_gs_file_type_key};
    foreach my $sub_mod (@co_obfuscate_method) {
        if (exists($conf->{$sub_mod})) {
            if ($sub_mod eq $co_ob_appearance_key &&
                $file_type eq $co_gs_file_type_c_key) {
                print("$sub_mod can't enabled in $co_gs_file_type_c_key\n");
                return 1;
            }
            #记录配置的功能
            push(@enabled_mod, $sub_mod);
        }
    }

    if (!@enabled_mod) {
        print("No module enabled!\n");
        return 2;
    }

    if ($file_type eq $co_gs_file_type_java_key) {
        $code_dir = $global_settings->{$co_gs_input_dir_key};
    } else {
        $code_dir = $global_settings->{$co_gs_output_code_dir_key};
    }
    #找到所有的代码文件
    @code_files = co_ft_find_files($file_type, $code_dir);
    if (!@code_files) {
        print("No $file_type type files\n");
        return 3;
    }

    #依次执行各个子功能
    foreach my $sub_mod (@enabled_mod) {
        $ret = $co_obfuscate_sub_handler{$sub_mod}($root_dir, 
            $conf->{$sub_mod}, $global_settings, $modify_seq,
            \@code_files, $sub_mod);
        if ($ret ne 0) {
            return 4;
        }
    }

    return 0;
}


1;
