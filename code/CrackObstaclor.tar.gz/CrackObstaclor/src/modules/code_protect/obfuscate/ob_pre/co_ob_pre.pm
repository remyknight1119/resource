package code_protect::obfuscate::ob_pre::co_ob_pre;
require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_pre_handler);

sub co_ob_pre_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);

    return 0;
}


1;
