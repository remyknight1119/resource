package code_protect::obfuscate::ob_appearance::java_code::co_ob_obfuscate;
require Exporter;
use config::co_conf_common;
use common;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_java_get_keep_options co_ob_java_do_obfuscate
            @co_ob_java_match_key);

my @co_ob_java_keep_option = ($co_ob_keep_package_names_key, 
                $co_ob_keep_classes_key,
                $co_ob_keep_class_members_key,
                $co_ob_keep_classes_with_members_key,
                $co_ob_keep_classes_with_members_names_key);

my %co_ob_java_keep_key = (
    $co_ob_keep_package_names_key => "keeppackagenames", 
    $co_ob_keep_classes_key => "keep",
    $co_ob_keep_class_members_key => "keepclassmembers",
    $co_ob_keep_classes_with_members_key => "keepclasseswithmembers",
    $co_ob_keep_classes_with_members_names_key => "keepclasseswithmembernames");

@co_ob_java_match_key = ("init", "fields", "methods");

my $co_ob_java_proguard_conf = "jp.conf";
my $co_ob_java_proguard_jar = "libCrackObstaclor.jar";

sub co_ob_java_get_keep_options {
    my $conf = shift(@_);
    my $keep_settings = shift(@_);
    my @keep_value;
    my $ret;

    foreach my $keep (@co_ob_java_keep_option) {
        @keep_value = ();
        co_conf_multi_item_parse($conf->{$co_ob_keep_option_key},
            $keep, \@keep_value);
        foreach my $v (@keep_value) {
            #XML格式的配置文件中不允许有<或>作为配置的值，故在设置配置值时
            #使用%代替<和>，现在需要转换回来
            # %init% -> <init>
            # %fields% -> <fields>
            # %methods% -> <methods>
            foreach my $m (@co_ob_java_match_key) {
                $v =~ s/\%$m\%/\<$m\>/g;
            }
        }
        $keep_settings->{$keep} = [@keep_value];
    }

    return 0;
}

sub co_ob_java_gen_config {
    my $file = shift(@_);
    my $gs = shift(@_);
    my $keep_settings = shift(@_);
    my $jfiles = shift(@_);
    my $rt_lib;
    my $map_path;

    $map_path = co_get_path($gs->{$co_gs_output_info_dir_key},
        $co_map_file_name); 
    foreach my $jf (@$jfiles) {
        print $file <<EOF;
-injars $jf
EOF
    }

    print $file <<EOF;
-outjars $gs->{$co_gs_output_code_dir_key}
-dontoptimize
-dontshrink
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
-dontwarn com.classpackage.AA
-dontwarn android.support.v4.**
-keepattributes **
-printmapping $map_path
EOF
    foreach my $lib (@{$gs->{$co_gs_library_jars_key}}) {
            print $file <<EOF;
-libraryjars $lib
EOF
    }

    foreach my $keep (@co_ob_java_keep_option) {
        foreach my $v (@{$keep_settings->{$keep}}) {
            print $file <<EOF;
-$co_ob_java_keep_key{$keep} $v
EOF
        }
    }
}

sub co_ob_java_do_obfuscate {
    my $install_dir = shift(@_);
    my $global_settings = shift(@_); 
    my $keep_settings = shift(@_);
    my $jfiles = shift(@_);
    my $conf_dir;
    my $lib_dir;
    my $lib_jar;
    my $conf;
    my $conf_file;

    $conf_dir = co_get_conf_dir($install_dir);
    $conf = co_get_tmp_file_name('.');
    print("Java Appearance $install_dir, $conf_dir, $conf\n");

    open($conf_file, ">$conf") || die("Open $conf failed!\n");
    co_ob_java_gen_config($conf_file, $global_settings, 
        $keep_settings, $jfiles);
    close($conf_file);
    $lib_dir = co_get_lib_dir($install_dir);
    $lib_jar = co_get_path($lib_dir, $co_ob_java_proguard_jar);
    system("java -jar \"$lib_jar\" \@$conf");
    unlink($conf);
}


1;
