package code_protect::obfuscate::ob_appearance::co_ob_appearance;
require Exporter;
use config::co_conf_common;
use code_protect::obfuscate::ob_appearance::java_code::co_ob_obfuscate;
use common;

@ISA = qw(Exporter);
@EXPORT = qw(co_ob_appearance_handler);

my %co_ob_get_keep_options = (
    $co_gs_file_type_java_key => \&co_ob_java_get_keep_options, 
);

my %co_ob_appearance_action = (
    $co_gs_file_type_java_key => \&co_ob_java_do_obfuscate, 
);

sub co_ob_appearance_get_keep_options {
    my $file_type = shift(@_);
    my $conf = shift(@_);
    my $keep_settings = shift(@_);
    my @keep_value;
    my $ret;

    $ret = co_conf_check_key($conf, $co_ob_keep_option_key);
    if ($ret ne 0) {
        return 1;
    }

    $ret = $co_ob_get_keep_options{$file_type}($conf, $keep_settings);
    if ($ret ne 0) {
        return 2;
    }

    return 0;
}

sub co_ob_appearance_handler {
    my $root_dir = shift(@_);
    my $conf = shift(@_);
    my $global_settings = shift(@_);
    my $modify_seq = shift(@_);
    my $code_files = shift(@_);
    my $p_mod = shift(@_);
    my $map_info = shift(@_);
    my $diff_file;
    my $diff_info = "appearance_obfuscate";
    my $func;
    my $proc;
    my $file_type;
    my @scope_conf_array;
    my @tfiles;
    my %keep_settings;

    $file_type = $global_settings->{$co_gs_file_type_key};
    my $ret = co_conf_parse_scope($conf, $p_mod,
        $global_settings->{$co_gs_input_dir_key},
        \@scope_conf_array, $file_type);
    if ($ret ne 0) {
        return 1;
    }

    foreach my $scope (@scope_conf_array) {
        push(@tfiles, $scope->{$co_file_name_key});
    }

    #解析KeepOption
    co_ob_appearance_get_keep_options($file_type, $conf, \%keep_settings);
    
    $ret = $co_ob_appearance_action{$file_type}($root_dir, $global_settings, 
        \%keep_settings, \@tfiles);
    if ($ret ne 0) {
        return 2;
    }

    return 0;
}


1;
