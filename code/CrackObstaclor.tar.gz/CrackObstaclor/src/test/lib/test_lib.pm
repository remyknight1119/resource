package test_lib;
require Exporter;
use common;
use File::Path;
use File::Basename;

@ISA = qw(Exporter);
@EXPORT = qw(
            co_test_gen_input_list co_test_gen_local_list
            co_do_integration_test 
             );

sub co_test_gen_input_list {
    my (%param) = @_;
    my $str = "";

    if (!%param) {
        return "void";
    }

    foreach my $key (keys %param) {
        $str = $str.$param{$key}." $key ,";
    }

    #去掉最后一个字符
    chop($str);

    return $str;
}

sub co_test_gen_local_list {
    my (%param) = @_;
    my $str = "";

    if (!%param) {
        return $str;
    }

    foreach my $key (keys %param) {
        $str = $str.$param{$key}." $key;\n\t";
    }

    chop($str);

    return $str;
}

sub co_do_integration_test {
    my $test_write_conf = shift(@_);
    my $test_write_code = shift(@_); 
    my $test_dir= co_get_abs_cwd(__FILE__);
    my $tmp_dir = get_rand_name();
    $tmp_dir = $test_dir.$tmp_dir;
    my $conf_file = $tmp_dir."/conf.xml";
    my $c_file_name = "code.c";
    my $code_dir = $tmp_dir."/code";
    my $code_file = $code_dir."/$c_file_name";
    my $bin_file = $tmp_dir."/test_bin";
    my $output_dir = $tmp_dir."/output";
    my $test_func = "test_func";
    my $testfile;
    my $result = 0;
    my $right;
    my $ret;

    mkpath($tmp_dir);
    mkpath($code_dir);

    open($testfile, ">$conf_file") || die("Open $conf_file failed!\n");
    &$test_write_conf($testfile, $code_dir, $output_dir, $test_func);
    close($testfile);

    open($testfile, ">$code_file") || die("Open $code_file failed!\n");
    &$test_write_code($testfile, $test_func);
    close($testfile);

    $ret = system("gcc -o $bin_file $code_file");
    if ($ret != 0) {
        $result = 1;
    }
    $right = system("$bin_file");
    $ret = system("perl code/$co_cmd_name.pl -c $conf_file");
    if ($ret != 0) {
        $result = 1;
    }

    $ret = system("gcc -o $bin_file $output_dir/$c_file_name");
    if ($ret != 0) {
        $result = 1;
    }
    $ret = system("$bin_file");
    if ($ret != $right) {
        $result = 1;
    }
    rmtree($tmp_dir);
    return $result;
}

1;
