#!/usr/bin/perl

use strict;
#use warnings;
use lib 'modules';
use common;
use co_vm;
use co_license;
use config::co_conf;
use Getopt::Std;
use File::Copy;
use File::Copy::Recursive qw(dircopy);

use vars qw($opt_c $opt_l $opt_v $opt_h);
getopts('c:l:vh');

my $crackobstaclor_name = "CrackObstaclor";

sub usage {
    print ("usage: $0 -c [configure file path] -l [license file path]\n");
    print ("\t\t\t\t-v (no args, version)\n");
    print ("\t\t\t\t-h (no args, help)\n");
}

sub co_print_version {
    print ("$crackobstaclor_name v0.0.1\n");
}

if ($opt_h) {
    &usage;
    exit(0);
}

if ($opt_v) {
    &co_print_version;
    exit(0);
}

my $conf_file = $opt_c;
my $lic_file = $opt_l;
my $install_dir = co_get_install_dir(__FILE__);

#检查是否运行在虚拟机中
my $ret = co_vm_check();
if ($ret ne 0) {
    print("CrackObstaclor is running in a virtual machine!\n");
    exit(1);
}

if ($lic_file) {
    if ($lic_file !~ /^\//) {
        print("$lic_file is not a absolute path!\n");
        exit(1);
    }

    if (! -f $lic_file) {
        print("File $lic_file is not existed!\n");
        exit(1);
    }

    #导入License
    exit(co_lic_import($lic_file));
}

#获取授权
my %warrant = co_lic_get_warrant();
if (!%warrant) {
    exit(1);
}

if (! $conf_file) {
    print("Configure file is not set!\n");
    &usage;
    exit(1);
}

if (! -f $conf_file) {
    print("File $conf_file is not existed!\n");
    exit(1);
}

co_do_protect($conf_file, $install_dir, \%warrant);

