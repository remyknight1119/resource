#!/bin/bash

action=$1
output_bin=$2
module=modules
code_dir=code

install()
{
    echo "Install"
}

usage()
{
    echo "$0 [bin|clean] [bin_file_name]"
}

if [ $# -ne 2 ]; then
    usage
    exit 0
fi

if [ "x$action" = "xbin" ]; then
    if [ "x$output_bin" = "x" ]; then
        echo "Error"
        exit 1
    fi
    ./make.pl -o $output_bin -m $module -c $code_dir/crackobstaclor.pl
fi

if [ "x$action" = "xclean" ]; then
    rm -f $output_bin
fi
