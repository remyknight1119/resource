#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Std;

use vars qw($opt_o $opt_m $opt_c $opt_h);
getopts('o:c:m:h');

my @module_files;
my $module_dir;
my $cmd_file;
my $output_file;

sub usage {
    print ("usage: $0 -o [out file path] -m [module file dir]\n");
    print ("\t\t\t\t-c [cmd file path]\n");
    print ("\t\t\t\t-h (no args, help)\n");
}

if ($opt_h) {
    &usage;
    exit(0);
}

$module_dir = $opt_m;
if (! $module_dir || ! -d $module_dir) {
    &usage;
    exit(0);
}

$cmd_file = $opt_c;
if (! $cmd_file || ! -f $cmd_file) {
    &usage;
    exit(0);
}

$output_file = $opt_o;

my $ret = `pp -o $output_file $cmd_file -M /usr/share/perl5/File/Find/Rule.pm`;

