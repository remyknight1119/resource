#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>

#include "pa_itc.h"
#include "pa_tcp.h"
#include "pa_debug.h"
#include "pa_main.h"

#define PA_LISTEN_BACKLOG	1000
#define CLIENT_MAX	100

/*
 * Debug controller, if it is 1, debug infomation will be print
 * on screen, otherwise no debug infomation will be print.
 */
int pa_debug_on = 1;

static const char *program_name;
static const char *program_version;

static const struct option long_opts[] = {
	{"help", 0, 0, 'H'},
	{"debug", 1, 0, 'D'},
	{"lip", 1, 0, 'l'},
	{"lport", 1, 0, 'p'},
	{"tproto", 1, 0, 't'},
	{"thread-num", 1, 0, 'm'},
	{0, 0, 0, 0},
};

static const char *options[] = {
	"--debug		-D  for start debug print\n",
	"--lip			-l  the IP address to listen\n",
	"--lport		-p  the port to listen\n",
	"--tproto		-t  the transport layer protocol type, 1 for TCP, 2 for UDP\n",
	"--thread-num		-m  the number of threads which proccess application protocol, \n"
							"must bigger than 0;\n",
	"--help		-H  Print help information\n",
};
	
static void help()
{
	int i;

	fprintf(stdout, "Version: %s\n", program_version);
	
	fprintf(stdout, "\nOptions:\n");
	for(i = 0; i < sizeof(options)/sizeof(char *); i ++) {
		fprintf(stdout, "  %s", options[i]);
	}
		
	return;
}

int pa_udp_init(pa_cmd_info *cmd_info);
void pa_udp_exit(void);

/*
 * Transport handler array, which contain the transport protocol processor
 */
static 
pa_transport_handler	tp_handler[] = {
	{
		.th_tproto = 1, 
		.th_init = pa_tcp_init,
		.th_exit = pa_tcp_exit,
	},
	{
		.th_tproto = 2, 
		.th_init = pa_udp_init,
		.th_exit = pa_udp_exit,
	},
};

#define pa_handler_size (sizeof(tp_handler)/sizeof(pa_transport_handler))

#define PA_IPADDR_LEN	128
#define PA_PORT_LEN		6

#define	PA_CMD_LADDR		0x01
#define	PA_CMD_LPORT		0x02
#define	PA_CMD_TPROTO		0x04
#define	PA_CMD_THREADNUM	0x08

static int pa_check_cmd(unsigned int cmd)
{
	if (!(cmd & PA_CMD_LADDR)){
		printf("Please input listen addr by -l!\n");
		return -1;
	}

	if (!(cmd & PA_CMD_LPORT)){
		printf("Please input listen port by -p!\n");
		return -1;
	}

	if (!(cmd & PA_CMD_TPROTO)){
		printf("Please input transprot protocol by -t!\n");
		return -1;
	}

	return 0;
}

/*
 * Initailize the IPv6 address structure in pa_cmd_info.
 * @info: the configure which input by commondline
 * @laddr: IPv6 address string
 * @lport: transport layer protocol port number
 */
static int
pa_init_addr(pa_cmd_info *info, char *laddr, char *lport)
{
	struct addrinfo hints;
	struct addrinfo *res = NULL;
	int ret = 0;

	memset(&hints, 0, sizeof(hints));

	if((ret = getaddrinfo(laddr, lport, &hints, &res)) != 0) {
		PA_PRINT("Get address info failed!\n");
		return -1;
	}

	memcpy(&info->pci_addr[0], res->ai_addr, res->ai_addrlen);

	freeaddrinfo(res);

	return 0;
}

/*
 * Point to transport layer handle structure
 */
static 
pa_transport_handler *handler = NULL;

/*
 * Signal process function
 * @signo: signal number
 */
static void
pa_sig_handler(int signo)
{
	PA_PRINT("Catch signal!\n");
	if (signo == SIGINT) {
		PA_PRINT("Catch SIGINT!\n");
		handler->th_exit();
	}
	exit(0);
}

/*
 * Main function
 */
int 
main(int argc, char *argv[]) 
{
	char laddr[PA_IPADDR_LEN] = {};
	char lport[PA_PORT_LEN] = {};
	unsigned short tproto = 0;
	unsigned int cmd = 0;
	unsigned int thread_num = 0;
	pa_cmd_info cmd_info;
	int c = 0;
	int index = 0;
	int ret = 0;

	program_name = argv[0];
	program_version = "1.0";

	while((c = getopt_long(argc, argv,
					"HDl:p:n:t:m:",  long_opts, NULL)) != -1) {
		switch(c) {
			case 'H':
				help();
				goto out;
			case 'D':
				pa_debug_on = 1;
				break;
			case 'l':
				strncpy(laddr, optarg, PA_IPADDR_LEN);
				cmd |= PA_CMD_LADDR;
				break;
			case 'p':
				strncpy(lport, optarg, PA_PORT_LEN);
				cmd |= PA_CMD_LPORT;
				break;
			case 't':
				tproto = atoi(optarg);
				cmd |= PA_CMD_TPROTO;
				break;
			case 'm':
				thread_num = atoi(optarg);
				cmd |= PA_CMD_THREADNUM;
				break;
			default:
				break;
		}
	}

	/*
	 * Check input cmd 
	 */
	if (pa_check_cmd(cmd) < 0){
		PA_PRINT("Check cmd error!\n");
		return -1;
	}

	if (thread_num > PA_THREAD_MAX_NUM){
		PA_PRINT("Error! thread_num(%u) which input by -m is bigger than MAX value(%u)!\n",thread_num, PA_THREAD_MAX_NUM);
		goto out;
	}

	if (!(cmd & PA_CMD_THREADNUM)) {
		thread_num = 1;
	}

	/*
	 * Find the proper transport handler to create thread to proccess
	 */
	handler = tp_handler;
	for (index = 0; index < pa_handler_size; index++, handler++){
		if (handler->th_tproto == tproto){
			ret = pa_init_addr(&cmd_info, laddr, lport);
			if (ret < 0) {
				goto out;
			}
			cmd_info.pci_thread_num = thread_num;

			if (handler->th_init(&cmd_info) < 0){ 
				goto out;
			}

			goto success;
		}
	}

	goto out;

success:
	if (signal(SIGINT, pa_sig_handler) == SIG_ERR) {
		PA_PRINT("Cann't catch SIGINT!\n");
	}

	while (1){
		sleep(1000);
	}

	handler->th_exit();
out:
	PA_PRINT("PA main exited!\n");
	return 0;
}
