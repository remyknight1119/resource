#ifndef __PA_HTTP_H__
#define __PA_HTTP_H__

#include <stdbool.h>

#define PA_HTTP_BUFF_LEN	5000

typedef struct _pa_http_conn {
	bool hc_closing;
	int hc_sock_fd;								//The socket fd of this http connection
	int hc_peer_fd;								//The socket fd of the comparative connection of this connection 
	int hc_poll_index;							//The index in poll array
	unsigned int hc_data_len;					//The length of data in hc_buff
	unsigned char hc_buff[PA_HTTP_BUFF_LEN];	//Data buffer
}pa_http_conn;

void *pa_http_handler(void *arg);

#endif
