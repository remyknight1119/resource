#include <stdio.h>
#include <pthread.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <poll.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <errno.h>
	
#include "pa_app.h"
#include "pa_debug.h"
#include "pa_main.h"

/*
 * Store the number of application thread configure by command line
 */
static unsigned int pa_app_thread_num = 0;

/*
 * Application thread infomation array
 */
static pa_app_thread_info 
app_thread_array[PA_THREAD_MAX_NUM] = {};

/*
 * Find an appropriate application thread to process the TCP connection
 * @tid: point to the memory to save the result 
 * Return the pthread identification of the thread which process the connection
 */
void
pa_app_find_thread(pthread_t *tid)
{
	pa_app_thread_info *th_info = NULL;
	unsigned int conn_num = 0;
	unsigned long index = 0;
	unsigned long result = 0;

	th_info = &app_thread_array[0];
	pthread_mutex_lock(&th_info->ati_lock);
	conn_num = th_info->ati_conn_num;
	pthread_mutex_unlock(&th_info->ati_lock);
	for (index = 1; index < pa_app_thread_num; index++) {
		th_info = &app_thread_array[index];
		pthread_mutex_lock(&th_info->ati_lock);
		if (conn_num > th_info->ati_conn_num) {
			conn_num = th_info->ati_conn_num;
			result = index;
		}
		pthread_mutex_unlock(&th_info->ati_lock);
	}

	*tid = app_thread_array[result].ati_tid;
}

/*
 * Find the application thread information struct by thread id
 * @id: identification of pthread
 * If success, return the information struct of the caller thread
 * If error, return NULL
 */
static pa_app_thread_info *
pa_app_find_thread_info_by_id(pthread_t tid)
{
	pa_app_thread_info *th_info = NULL;
	unsigned long index = 0;

	for (index = 0; index <= pa_app_thread_num; index++) {
		th_info = &app_thread_array[index];
		if (pthread_equal(tid, th_info->ati_tid)) {
			return th_info;
		}
	}

	return NULL;
}


/*
 * Use for TCP thread to notify the application thread about the event arrived
 * @tid: pthread identification of the application thread the caller want to wakeup
 * If success, return 0
 * If error, return -1
 */
int
pa_app_wakeup_thread(pthread_t tid)
{
	pa_app_thread_info *th_info = NULL;
	int err = 0;

	th_info = pa_app_find_thread_info_by_id(tid);
	if (th_info == NULL) {
		return -1;
	}

	pthread_mutex_lock(&th_info->ati_lock);
	th_info->ati_has_event = 1;
	err = pthread_cond_signal(&th_info->ati_cond); 
	if (err < 0) {
		PA_PRINT("Send pthread signal failed!errno=%d\n",errno);
	}
	pthread_mutex_unlock(&th_info->ati_lock);

	return err;
}

/*
 * Find the application thread information struct
 * If success, return the information struct of the caller thread
 * If error, return NULL
 */
static pa_app_thread_info *
pa_app_find_thread_info(void)
{
	pthread_t self_id = pthread_self();

	return pa_app_find_thread_info_by_id(self_id);
}

/*
 * Use for application thread to sleep when no events to process, 
 * otherwise return immedately
 * @timeout: the number of sleep seconds when need to sleep, 
 * If have events, return 0
 * If timeout, return 1
 * If error, return -1
 */
int
pa_app_thread_sleep(int timeout)
{
	pa_app_thread_info *th_info = NULL;
	struct timespec exp_time;
	time_t abstime;
	time_t time_ret;
	int err = 0;

	th_info = pa_app_find_thread_info();
	if (th_info == NULL) {
		PA_PRINT("Find thread info failed!\n");
		return -1;
	}

	if (timeout == 0) {
		goto out;
	}

	pthread_mutex_lock(&th_info->ati_lock);
	while (!th_info->ati_has_event) {
		if (timeout > 0) {
			time_ret = time(&abstime);
			if (time_ret == (time_t)-1) {
				pthread_mutex_unlock(&th_info->ati_lock);
				PA_PRINT("Get time failed!\n");
				return -1;
			}
			exp_time.tv_sec = abstime + timeout;
			exp_time.tv_nsec = 0;
			pthread_cond_timedwait(&th_info->ati_cond, &th_info->ati_lock, &exp_time);
			if (errno == ETIMEDOUT) {
				err = 1;
				break;
			}
		} else {
			PA_PRINT("Before sleep!\n");
			pthread_cond_wait(&th_info->ati_cond, &th_info->ati_lock); 
			PA_PRINT("Wake up!\n");
		}
	}
	th_info->ati_has_event = 0;
	pthread_mutex_unlock(&th_info->ati_lock);

	PA_PRINT("Return!\n");

out:
	return err;
}

/*
 * Use for TCP thread to add an new connection in the accept queue 
 * of application thread
 * @tid: pthread identification of the application thread to which the
 * 		new connection belongs
 * @sockfd: the socket fd of the new connection
 * If success, return 0
 * If error, return -1
 */
int 
pa_app_add_new_conn(pthread_t tid, int sockfd)
{
	pa_app_thread_info *th_info = NULL;
	pa_app_conn_queue *queue = NULL;
	unsigned int tail = 0;
	int err = -1;

	th_info = pa_app_find_thread_info_by_id(tid);
	if (th_info == NULL) {
		return err;
	}

	pthread_mutex_lock(&th_info->ati_lock);
	queue = &th_info->ati_accept_queue;
	if (queue->acq_sockfd[tail] >= 0) {
		PA_PRINT("Accept queue is full!");
		goto out;
	}

	queue->acq_sockfd[tail] = sockfd; 

	tail = queue->acq_tail + 1; 
	if (tail >= PA_APP_ACCEPT_CONN_NUM) {
		tail = 0;
	}

	queue->acq_tail = tail;
	th_info->ati_has_event = 1;
	err = pthread_cond_signal(&th_info->ati_cond); 
	if (err < 0) {
		PA_PRINT("Send pthread signal failed!errno=%d\n",errno);
	} else {
		PA_PRINT("Send pthread signal success!\n");
	}

	th_info->ati_conn_num++;
out:
	pthread_mutex_unlock(&th_info->ati_lock);

	return err;
}

/*
 * Get a socket fd from applicatin thread accept queue
 * If success, return the socket fd
 * If error, return -1
 */
int 
pa_app_get_accept_sockfd(void)
{
	pa_app_thread_info *th_info = NULL;
	pa_app_conn_queue *queue = NULL;
	unsigned int head = 0;
	int sock_fd = -1;

	th_info = pa_app_find_thread_info();
	if (th_info == NULL) {
		return -1;
	}

	pthread_mutex_lock(&th_info->ati_lock);
	queue = &th_info->ati_accept_queue;
	head = queue->acq_head;
	sock_fd = queue->acq_sockfd[head]; 
	if (sock_fd >= 0){
		queue->acq_sockfd[head] = -1; 
		head++;
		if (head >= PA_APP_ACCEPT_CONN_NUM) {
			head = 0;
		}

		queue->acq_head = head;
	}

	pthread_mutex_unlock(&th_info->ati_lock);


	return sock_fd;
}

/*
 * Check the accept queue has new connection or not
 * If has, return 1
 * If no, return 0
 */
bool 
pa_app_has_new_conn(void) 
{
	pa_app_thread_info *th_info = NULL;
	pa_app_conn_queue *queue = NULL;
	bool result = 0;

	th_info = pa_app_find_thread_info();
	if (th_info == NULL) {
		return -1;
	}

	pthread_mutex_lock(&th_info->ati_lock);
	queue = &th_info->ati_accept_queue;
	
	result = (queue->acq_sockfd[queue->acq_head] >= 0);
	pthread_mutex_unlock(&th_info->ati_lock);

	return result;
}

/*
 * Initialize accept queue in application thread information struct
 * @accept_queue: pointer to accept queue struct
 */
static void 
pa_app_accept_queue_init(pa_app_conn_queue *accept_queue)
{
	int index = 0;

	for (index = 0; index < PA_APP_ACCEPT_CONN_NUM; index++) {
		accept_queue->acq_sockfd[index] = -1;
	}
}

/*
 * Create thread_num application threads to process application connection
 * @app_handler: the function called by application thread
 * @thread_num: the number of application thread set by commandline
 * If success, return 0
 * If error, return -1
 */
int 
pa_app_create_thread(void *(*app_handler)(void *), unsigned int thread_num)
{
	pa_app_thread_info *th_info = NULL;
	int thread_index = 0;

	th_info = &app_thread_array[0];
	for(thread_index = 0; thread_index  < thread_num; thread_index++, th_info++){
		memset(th_info, 0, sizeof(*th_info));
		if (pthread_create(&th_info->ati_tid, NULL, app_handler, NULL) < 0){
			PA_PRINT("Create application thread failed!\n");
			return -1;
		}
		th_info->ati_lock = PTHREAD_MUTEX_INITIALIZER; 
		th_info->ati_cond = PTHREAD_COND_INITIALIZER; 
		pa_app_accept_queue_init(&th_info->ati_accept_queue);
	}

	pa_app_thread_num = thread_num;

	return 0;
}

/*
 * Free the resource alloc in pa_app_create_thread
 */
void 
pa_app_thread_exit(void)
{
	pa_app_thread_info *th_info = NULL;
	int thread_index = 0;

	th_info = &app_thread_array[0];
	for(thread_index = 0; thread_index  < pa_app_thread_num; thread_index++, th_info++){
		if (pthread_cancel(th_info->ati_tid) < 0){
			PA_PRINT("Cancel application thread failed!\n");
		} else {
			PA_PRINT("Application thread canceled!\n");
		}
	}
}
