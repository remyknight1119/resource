#ifndef __PA_DEBUG_H__
#define __PA_DEBUG_H__

#define PA_PRINT(str,args...) \
	do {\
		if (pa_debug_on) { \
			printf("[%s: %d]",__FUNCTION__,__LINE__);\
			printf(str,##args);\
		} \
	}while(0)

#define pa_data_print(data, len) \
	do {\
		int i = 0; \
		if (pa_debug_on) { \
			printf("In %s %d, len = %d, data = %p\n",__FUNCTION__,__LINE__,(int)len, data); \
			for (i = 0; i < len; i++) { \
				printf("%x ", *((unsigned char *)data + i)); \
			} \
			printf("\n"); \
		} \
	}while(0)


extern int pa_debug_on;

#endif
