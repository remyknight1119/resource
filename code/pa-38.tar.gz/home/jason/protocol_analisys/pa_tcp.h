#ifndef __PA_TCP_H__
#define __PA_TCP_H__

#include <stdbool.h>
#include <netinet/in.h>
#include <pthread.h>

#define PA_TCP_MAX_CONN_NUM		65535

#define PA_INFINITE	-1

#define	PA_TCP_EVENT_NONE	0x00
#define PA_TCP_EVENT_IN		0x01
#define PA_TCP_EVENT_OUT	0x02
#define PA_TCP_EVENT_ERR	0x04

#define PA_TCP_BUFF_LEN	2000

enum {
	PA_TCP_STATE_CLOSING = 1,
	PA_TCP_STATE_ABNORMAL,
};

typedef struct _pa_tcp_data_buff{
	pthread_mutex_t tdb_lock;
	unsigned char tdb_buff[PA_TCP_BUFF_LEN];
	ssize_t tdb_buff_len;	//Identify the length of data in ptm_buff from the beginning of it
}pa_tcp_data_buff;

typedef struct _pa_tcp_conn_info {
	bool tci_listen;			//Identify this connection is a listen socket, not receive and send data
	bool tci_has_thread;		//Identify theis connection is already had a application thread to process 
								//process it
	int tci_tcp_sockfd;			//The socket fd of socketpair of the TCP client thread or 
								//server thread to which this struct belongs
	int tci_poll_index;			//Record the index of socket fd of this connection in poll array
	pthread_t 	tci_tid;		//Thread id of the thread to which this connection belongs
	struct sockaddr tci_laddr[0]; //Used to pointer to addr_in
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}tci_laddr_in;				//Addr of destination
	struct sockaddr tci_faddr[0]; //Used to pointer to addr_in
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}tci_faddr_in;				//Addr of destination

	pthread_mutex_t tci_events_lock; //Event lock, protect tci_events
	unsigned short tci_events;		//The event type with which the application thread interests

	unsigned short tci_tcp_state;	//The state of TCP connection

	pa_tcp_data_buff tci_recv_buff; //Store the data receive from TCP socket, should be receive by application thread
	pa_tcp_data_buff tci_send_buff; //Store the data receive from application thread, should be send by TCP client or server thread
}pa_tcp_conn_info;

extern int pa_client_thread_fd;
extern int pa_server_thread_fd;

extern int pa_tcp_listen(struct sockaddr *addr, socklen_t addrlen);
extern int pa_tcp_connect(struct sockaddr *addr, socklen_t addrlen);
extern int pa_tcp_accept(struct sockaddr *laddr, struct sockaddr *faddr, socklen_t *addrlen);
extern int pa_tcp_poll(struct pollfd fds[], nfds_t nfds, int timeout);
extern ssize_t pa_tcp_recv(int sockfd, void *buf, size_t len, int flags);
extern ssize_t pa_tcp_send(int sockfd, void *buf, size_t len, int flags);
extern int pa_tcp_close(int sockfd);
extern int pa_tcp_get_addr(int sock_fd, struct sockaddr *laddr, struct sockaddr *faddr, socklen_t *addrlen);

struct _pa_cmd_info; 
extern int pa_tcp_init(struct _pa_cmd_info *cmd_info);
extern void pa_tcp_exit(void);

#endif
