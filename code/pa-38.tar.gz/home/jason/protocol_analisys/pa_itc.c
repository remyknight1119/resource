#include <stdio.h>
#include <pthread.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <poll.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
	
#include "pa_app.h"
#include "pa_itc.h"
#include "pa_debug.h"

/*
 * Send a message to communication with the TCP client or server thread
 * @unix_sockfd: the unix socket fd of the TCP thread create for 
 * 		commuication with application thread
 * @msg_type: message type 
 * @sock_fd: socket fd for TCP thread to process
 * If sucess, return 0
 * If error, return -1
 */
int
pa_tcp_itc_send(int unix_sockfd, unsigned int msg_type, int sock_fd)
{
	pa_itc_msg send_msg;
	ssize_t send_len;

	send_msg.im_msg_type = msg_type;
	send_msg.im_sockfd = sock_fd;

	send_len = send(unix_sockfd, &send_msg, sizeof(send_msg), MSG_DONTWAIT);
	if (send_len < 0) {
		PA_PRINT("Msg send fialed!unix_sockfd=%dsockfd = %d,send_len = %d,type=%d,data_len=%lu,errno=%d\n",unix_sockfd,sock_fd, (int)send_len,msg_type,sizeof(send_msg),errno);
		return -1;
	}

	PA_PRINT("Msg sockfd = %d,send_len = %d,type=%d,data_len=%lu\n",sock_fd, (int)send_len,msg_type,sizeof(send_msg));
	return 0;
}


