#ifndef __PA_ITC_H__
#define __PA_ITC_H__

#include <netinet/in.h>

enum{
	PA_MSG_TYPE_SOCK_LISTEN = 1, //Add a listen socket to poll array for application thread
	PA_MSG_TYPE_SOCK_CONN,		 //Add a connected socket to poll array for application thread
	PA_MSG_TYPE_SOCK_RECV,		 //Allow th TCP client or server thread to receive data from TCP socket
	PA_MSG_TYPE_SOCK_SEND,		 //Notify th TCP client or server thread to send data though TCP socket
};

typedef struct _pa_itc_msg {
	unsigned int im_msg_type;	//Message type in above
	int im_sockfd;				//Socket fd for TCP thread to process
}pa_itc_msg;

extern int pa_tcp_itc_send(int unix_sockfd, unsigned int msg_type, int sock_fd);

#endif
