#ifndef __PA_MAIN_H__
#define __PA_MAIN_H__

#include <sys/socket.h>
#include <netinet/in.h>

/*
 * Used to pass on the parameter in main function
 */ 
typedef struct _pa_cmd_info{
	struct sockaddr pci_addr[0]; //Used to pointer to addr_in
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}pci_addr_in;				 //Addr of destination
	unsigned int pci_thread_num; //The number of thread which to process application data
}pa_cmd_info;

/*
 * The transport handler table
 */
typedef struct _pa_transport_handler{
	unsigned short	th_tproto;			//Transport layre protocol, TCP or UDP
	int (*th_init) (pa_cmd_info *);	//The transport protocol initial function
	void (*th_exit) (void);			//Free the resource alloc in initial function
}pa_transport_handler;

/*
 * The MAX number of thread which asigned by pa_cmd_info->pci_thread_num
 */
#define PA_THREAD_MAX_NUM	10

#endif
