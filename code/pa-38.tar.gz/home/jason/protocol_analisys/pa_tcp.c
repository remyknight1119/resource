#include <stdio.h>
#include <pthread.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <poll.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
	
#include "pa_main.h"
#include "pa_itc.h"
#include "pa_app.h"
#include "pa_tcp.h"
#include "pa_http.h"
#include "pa_debug.h"

#define PA_TCP_BACKLOG	1000
#define PA_CLIENT_MAX	65535

/*
 * TCP connection table
 */
static pa_tcp_conn_info tcp_conn[PA_TCP_MAX_CONN_NUM] = {};

/*
 * One of the socket pair file descriptor of client thread, which used
 * by application thread to communication with clietn thread
 */
int pa_client_thread_fd = 0;

/*
 * One of the socket pair file descriptor of server thread, which used
 * by application thread to communication with server thread
 */
int pa_server_thread_fd = 0;

static pa_app_proc pa_tcp_app_handler[] = {
	{80, pa_http_handler},
};

#define PA_TCP_APP_HANDLER_SIZE (sizeof(pa_tcp_app_handler)/sizeof(pa_app_proc))

static void 
pa_tcp_conn_init(pa_tcp_conn_info *conn)
{
	memset(conn, 0, sizeof(*conn));
	conn->tci_events = PA_TCP_EVENT_NONE;
}

/* 
 * Create a new TCP socket to listen on an IP address & port
 * @addr: point to the IP address and port informations 
 * @addrlen: the size of address to which addr point
 * If success, return the socket fd; 
 * If error return -1
 */
int
pa_tcp_listen(struct sockaddr *addr, socklen_t addrlen)
{
	pa_tcp_conn_info *conn = NULL;
	int sock_fd = 0;
	int err = 0;

	sock_fd = socket(addr->sa_family, SOCK_STREAM, IPPROTO_TCP);
	if (sock_fd < 0){
		PA_PRINT("Socket syscall failed!errno = %d\n",errno);
		goto out;
	}

	err = bind(sock_fd, addr, addr->sa_len);
	if (err < 0){
		PA_PRINT("Bind syscall failed!errno = %d\n",errno);
		goto out;
	}

	err = listen(sock_fd, PA_TCP_BACKLOG);
	if (err < 0){
		PA_PRINT("Listen syscall failed!errno = %d\n",errno);
		goto out;
	}

	conn = &tcp_conn[sock_fd];
	pa_tcp_conn_init(conn);
	conn->tci_tid = pthread_self();
	memcpy(&conn->tci_laddr[0], addr, addrlen);

	pa_tcp_itc_send(pa_client_thread_fd, PA_MSG_TYPE_SOCK_LISTEN, sock_fd);

	return sock_fd;
out:
	return -1;
}

/*
 * Create a new TCP socket to connect an remote process
 * @addr: point to the IP address and port informations 
 * @addrlen: the size of address to which addr point
 * If success, return the socket fd; 
 * If error return -1
 */
int
pa_tcp_connect(struct sockaddr *addr, socklen_t addrlen)
{
	pa_tcp_conn_info *conn = NULL;
	int sock_fd = 0;
	int err = 0;

	sock_fd = socket(addr->sa_family, SOCK_STREAM, IPPROTO_TCP);
	if (sock_fd < 0){
		PA_PRINT("Socket syscall failed!errno = %d\n",errno);
		goto out;
	}

	err = connect(sock_fd, addr, addrlen);
	if (err < 0){
		PA_PRINT("Connect syscall failed!errno = %d\n",errno);
		close(sock_fd);
		goto out;
	}

	conn = &tcp_conn[sock_fd];
	pa_tcp_conn_init(conn);

	conn->tci_tid = pthread_self();
	conn->tci_tcp_sockfd = pa_server_thread_fd;
	memcpy(&conn->tci_faddr[0], addr, addrlen);

	pa_tcp_itc_send(conn->tci_tcp_sockfd, PA_MSG_TYPE_SOCK_CONN, sock_fd);

	return sock_fd;
out:
	return -1;
}

/*
 * Accept an connection  
 * @laddr: point to the local IP address and port informations 
 * @faddr: point to the foreign IP address and port informations 
 * @addrlen: the size of address to which laddr and faddr point, 
 * If success, return the socket fd, and fill the address and port information
 * 		to laddr and fadd; 
 * If error return -1
 */
int
pa_tcp_accept(struct sockaddr *laddr, struct sockaddr *faddr, socklen_t *addrlen)
{
	pa_tcp_conn_info *conn = NULL;
	struct sockaddr *addr = NULL;
	int sock_fd = 0;

	sock_fd = pa_app_get_accept_sockfd();
	if(sock_fd < 0) {
		goto out;
	}

	conn = &tcp_conn[sock_fd];
	addr = &conn->tci_laddr[0];
	*addrlen = addr->sa_len;
	memcpy(laddr, &conn->tci_laddr[0], *addrlen);
	memcpy(faddr, &conn->tci_faddr[0], *addrlen);

	return sock_fd;
out:
	return -1;
}

/*
 */
unsigned short
pa_tcp_do_poll(pa_tcp_conn_info *conn)
{
	pa_tcp_data_buff *data_buff = NULL;
	unsigned short mask = 0;

	data_buff = &conn->tci_recv_buff;
	pthread_mutex_lock(&data_buff->tdb_lock);
	if (data_buff->tdb_buff_len) {
		mask |= PA_TCP_EVENT_IN;
	}
	pthread_mutex_unlock(&data_buff->tdb_lock);
	
	data_buff = &conn->tci_send_buff;
	pthread_mutex_lock(&data_buff->tdb_lock);
	if (data_buff->tdb_buff_len < PA_TCP_BUFF_LEN) {
		mask |= PA_TCP_EVENT_OUT;
	}
	pthread_mutex_unlock(&data_buff->tdb_lock);
	if (conn->tci_tcp_state == PA_TCP_STATE_CLOSING) {
		mask |= PA_TCP_EVENT_IN;
	}

	if (conn->tci_tcp_state == PA_TCP_STATE_ABNORMAL) {
		mask |= PA_TCP_EVENT_ERR;
	}

	return mask;
}

/* 
 * Wait for some event on a TCP socket file descriptor
 * @fds: the set of file descriptors to be monitored
 * @nfds: the number of items in the fds array
 * @timeout: specifies  an upper limit on the time for which pa_tcp_poll() will block, in seconds.  
 * 		Specifying a negative value in timeout means an infinite timeout.
 * If success, return the number of events.
 * If error, return -1.
 */
int
pa_tcp_poll(struct pollfd fds[], nfds_t nfds, int timeout)
{
	pa_tcp_conn_info *conn = NULL;
	unsigned short revents = 0;
	unsigned short mask = 0;
	int sock_fd = 0;
	int index = 0;
	int nready = 0;
	int ret = 0;

	while (1) {
//		PA_PRINT("Before check!\n");
	 	if(pa_app_has_new_conn()) {
			PA_PRINT("Has new connection!\n");
			nready++;
		}

		for (index = 0; index < nfds; index++) {
			if ((sock_fd = fds[index].fd) < 0) {
				continue;
			}
			conn = &tcp_conn[sock_fd];
			pthread_mutex_lock(&conn->tci_events_lock);
			conn->tci_events = fds[index].events;
			pthread_mutex_unlock(&conn->tci_events_lock);
//			PA_PRINT("conn = %p,tci_events=%x\n",conn, fds[index].events);
			revents = pa_tcp_do_poll(conn);
			mask = fds[index].events & revents;
			if (mask) {
				nready++;
			}
			fds[index].revents = mask;
		}

		if (nready) {
			break;
		}

		/*
		 * Timeout
		 */
		if (ret == 1) {
			break;
		}

		ret = pa_app_thread_sleep(timeout);
		if (ret < 0) {
			return -1;
		}
	}

	return nready;
}

/*
 * Receive data from a TCP socket.
 * @sock_fd: fd of the TCP socket
 * @buf: buffer for reveive data
 * @len: the length of the buffer
 * @flags: for future use
 * If success, return the length of data.
 * 		if the length is 0, means the TCP
 * 		socket received a FIN package
 * If error, return -1.
 */
ssize_t 
pa_tcp_recv(int sock_fd, void *buf, size_t len, int flags)
{
	pa_tcp_conn_info *conn = NULL;
	pa_tcp_data_buff *data_buff = NULL;
	unsigned char *recv_buff = NULL;
	ssize_t data_len = 0;
	ssize_t copy_len = 0;

	conn = &tcp_conn[sock_fd];
	data_buff = &conn->tci_recv_buff;
	recv_buff = &data_buff->tdb_buff[0];

	pthread_mutex_lock(&data_buff->tdb_lock);
	if (data_buff->tdb_buff_len == 0) {
		goto out;
	}
	data_len = data_buff->tdb_buff_len;
	copy_len = (len < data_len) ? len : data_len;
	PA_PRINT("len=%d,data_len=%d,copy_le=%d\n",(int)len,(int)data_len,(int)copy_len);
//	pa_data_print(data_buff, copy_len);
	memcpy(buf, recv_buff, copy_len);

	data_buff->tdb_buff_len -= copy_len;
	if (data_buff->tdb_buff_len > 0) {
		memmove(data_buff, data_buff + copy_len, copy_len);
	}

out:
	pthread_mutex_unlock(&data_buff->tdb_lock);

	if (copy_len) {
		pa_tcp_itc_send(conn->tci_tcp_sockfd, PA_MSG_TYPE_SOCK_RECV, sock_fd);
	}

	return copy_len;
}

/*
 * Send data from a TCP socket.
 * @sock_fd: fd of the TCP socket
 * @buf: buffer for send data
 * @len: the length of the data
 * @flags: for future use
 * If success, return the length of data which has 
 * 		been send succeed.
 * If error, return -1.
 */
ssize_t 
pa_tcp_send(int sock_fd, void *buf, size_t len, int flags)
{
	pa_tcp_conn_info *conn = NULL;
	pa_tcp_data_buff *data_buff = NULL;
	unsigned char *send_buff = NULL;
	ssize_t space = 0;
	ssize_t copy_len = 0;

	conn = &tcp_conn[sock_fd];
	data_buff = &conn->tci_send_buff;
	send_buff = &data_buff->tdb_buff[0];
	pthread_mutex_lock(&data_buff->tdb_lock);
	space = PA_TCP_BUFF_LEN - data_buff->tdb_buff_len;
	if (space == 0) {
		goto out;
	}
	send_buff += data_buff->tdb_buff_len;
	copy_len = (len < space) ? len : space;

	memcpy(send_buff, buf, copy_len);

	conn->tci_send_buff.tdb_buff_len += copy_len;
out:
	pthread_mutex_unlock(&data_buff->tdb_lock);

	PA_PRINT("copy_len = %d, sockfd = %d\n",(int)copy_len, sock_fd);
	if (copy_len) {
		pa_tcp_itc_send(conn->tci_tcp_sockfd, PA_MSG_TYPE_SOCK_SEND, sock_fd);
	}

	return copy_len;
}

/*
 * Get the address and port information of a TCP connection
 * @laddr: point to the local IP address and port informations 
 * @faddr: point to the foreign IP address and port informations 
 * @addrlen: the size of address to which laddr and faddr point, 
 * If success, return the socket fd, and fill the address and port information
 * 		to laddr, fadd and addrlen; 
 * If error return -1
 */
int
pa_tcp_get_addr(int sock_fd, struct sockaddr *laddr, struct sockaddr *faddr, socklen_t *addrlen)
{
	pa_tcp_conn_info *conn = NULL;
	struct sockaddr *l_addr = NULL;
	struct sockaddr *f_addr = NULL;

	conn = &tcp_conn[sock_fd];
	l_addr = &conn->tci_laddr[0];
	f_addr = &conn->tci_faddr[0];
	memcpy(laddr, l_addr, l_addr->sa_len);
	memcpy(faddr, f_addr, f_addr->sa_len);
	*addrlen = l_addr->sa_len;

	return 0;
}

/*
 * Close a TCP connection
 * @sockfd: 
 * If sucess, return 0
 * If error, return -1
 */
int
pa_tcp_close(int sockfd)
{
//	PA_PRINT("Sockfd=%d!\n",sockfd);
	return close(sockfd);
}

/*
 * Notify an application thread for an event
 * @conn: point to TCP connection infomation struction
 * @event: event type
 */
static void 
pa_tcp_submit_event(pa_tcp_conn_info *conn, unsigned int event)
{
	unsigned int mask = 0;

	if (event & PA_TCP_EVENT_ERR) {
		conn->tci_tcp_state = PA_TCP_STATE_ABNORMAL;
	}
	pthread_mutex_lock(&conn->tci_events_lock);
	mask = conn->tci_events & event;
	pthread_mutex_unlock(&conn->tci_events_lock);
	if (mask) {
		pa_app_wakeup_thread(conn->tci_tid);
	}
}

/*
 * Find application protocol handler for a connection
 * @thread_num:
 * @prot:
 *
 * If success, return 0 and create thread_num numbers of thread 
 * 		to process application data
 * If error return -1
 */
static int 
pa_tcp_create_app_thread(unsigned int thread_num, unsigned short port)
{
	void *(*app_handler)(void *) = NULL;
	int handler_index = -1;
	int err = 0;
	int index = 0;

	for (index = 0; index < PA_TCP_APP_HANDLER_SIZE; index++) {
		if (pa_tcp_app_handler[index].ap_port == ntohs(port)) {
			handler_index = index;
		}
	}


	if (handler_index < 0) {
		return -1;
	}
	app_handler = pa_tcp_app_handler[handler_index].ap_handler;
	err = pa_app_create_thread(app_handler, thread_num);
	if (err < 0) {
		return -1;
	}

	return 0;
}

/*
 * Receive data from a TCP socket and copy the data to
 * 		the connection data buffer
 * @sock_fd: socket file descriptor
 * If sucess, return 0
 * If error, return -1
 */
static int 
pa_tcp_recv_data(int sock_fd)
{
	pa_tcp_conn_info *conn = NULL;
	pa_tcp_data_buff *data_buff = NULL;
	unsigned char *recv_buff = NULL;
	ssize_t space = 0;
	ssize_t recv_len = 0;

	PA_PRINT("Receive data!sockfd=%d\n",sock_fd);
	conn = &tcp_conn[sock_fd];
	data_buff = &conn->tci_recv_buff;
	recv_buff = &data_buff->tdb_buff[0];

	pthread_mutex_lock(&data_buff->tdb_lock);
	recv_buff += data_buff->tdb_buff_len;
	space = PA_TCP_BUFF_LEN - data_buff->tdb_buff_len;
	if (space == 0) {
		pthread_mutex_unlock(&data_buff->tdb_lock);
		PA_PRINT("Space is 0!\n");
		return 1;
	}
	recv_len = recv(sock_fd, recv_buff, space, MSG_DONTWAIT);

	if (recv_len < 0) {
		PA_PRINT("Recv syscall failed!errno = %d\n",errno);
		pa_tcp_submit_event(conn, PA_TCP_EVENT_ERR);
		pthread_mutex_unlock(&data_buff->tdb_lock);
		return -1;
	}

	PA_PRINT("Recv len = %d,data_len=%d!\n",(int)recv_len,(int)data_buff->tdb_buff_len);
	data_buff->tdb_buff_len += recv_len;
	pa_data_print(recv_buff, data_buff->tdb_buff_len);

	if (recv_len == 0) {
		conn->tci_tcp_state = PA_TCP_STATE_CLOSING; 
	}
	pa_tcp_submit_event(conn, PA_TCP_EVENT_IN);
	pthread_mutex_unlock(&data_buff->tdb_lock);

	return 0;
}

/*
 * Send out the data which application thread send to connection buffer
 * @sock_fd: socket file descriptor
 * If sucess, return 0
 * If error, return -1
 */
static int
pa_tcp_send_data(int sock_fd)
{
	pa_tcp_conn_info *conn = NULL;
	pa_tcp_data_buff *data_buff = NULL;
	unsigned char *send_buff = NULL;
	ssize_t send_len = 0;
	ssize_t data_len = 0;

	conn = &tcp_conn[sock_fd];
	data_buff = &conn->tci_send_buff;
	pthread_mutex_lock(&data_buff->tdb_lock);
	send_buff = &data_buff->tdb_buff[0];
	data_len = data_buff->tdb_buff_len;
	send_len = send(sock_fd, send_buff, data_len, MSG_DONTWAIT);
	if (send_len < 0){
		PA_PRINT("Send syscall failed!sockfd = %d,errno = %d\n",sock_fd, errno);
		pa_tcp_submit_event(conn, PA_TCP_EVENT_ERR);
		pthread_mutex_unlock(&data_buff->tdb_lock);
		return -1;
	}

	PA_PRINT("Send data!sockfd = %d, send len = %d,conn=%p\n",sock_fd, (int)send_len,conn);
//	pa_data_print(send_buff, data_len);
	conn->tci_send_buff.tdb_buff_len -= send_len;
	if (send_len < data_len){
		memmove(send_buff, send_buff + send_len, send_len);
		return 1;
	}
	if (conn->tci_send_buff.tdb_buff_len == 0) {
		pa_tcp_submit_event(conn, PA_TCP_EVENT_OUT);
	}
	pthread_mutex_unlock(&data_buff->tdb_lock);

	return 0;
}
	
/*
 * TCP client thread process function. It serve for the remote client process
 * which connection to the listening address and TCP port.
 */
static void *
pa_tcp_client(void *arg)
{
	pa_cmd_info *cmd_info = (pa_cmd_info *)arg;
	pa_tcp_conn_info *conn = NULL;
	pa_tcp_conn_info *new_conn = NULL;
	struct pollfd client[PA_CLIENT_MAX] = {};
	struct pollfd *poll_array = NULL;
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	} accept_addr;
	socklen_t accept_addr_size;
	struct sockaddr *addr = NULL;
	int pair_fd[2] = {};
	pa_itc_msg msg_buff;
	pa_itc_msg *itc_msg = &msg_buff;
	ssize_t recv_len = 0;
	int fd_num = 0;
	int poll_index = 0;
	int nready = 0;
	int listen_fd = 0;
	int listen_thread_fd = 0;
	int connfd = 0;
	int sock_fd = 0;
	int err = 0;

	/*
	 * Create a pair of unix socket for conmunication with
	 * application thread
	 */
	err = socketpair(AF_UNIX, SOCK_DGRAM, 0, pair_fd);
	if (err < 0){
		PA_PRINT("Server socketpair failed! errno = %d\n",errno);
		return NULL;
	}

	listen_thread_fd = pair_fd[0];
	pa_client_thread_fd = pair_fd[1];

	client[0].fd = listen_thread_fd;
	client[0].events = POLLIN;
	client[0].revents = 0;

	fd_num++;

	addr = &cmd_info->pci_addr[0];
	/*
	 * Create a TCP socket for conmunication with remote process
	 */
	listen_fd = socket(addr->sa_family, SOCK_STREAM, IPPROTO_TCP);
	if (listen_fd < 0){
		PA_PRINT("Socket syscall failed!errno = %d\n",errno);
		goto out;
	}

	err = bind(listen_fd, addr, addr->sa_len);
	if (err < 0){
		PA_PRINT("Bind syscall failed!errno = %d\n",errno);
		goto out;
	}

	err = listen(listen_fd, PA_TCP_BACKLOG);
	if (err < 0){
		PA_PRINT("Listen syscall failed!errno = %d\n",errno);
		goto out;
	}

	conn = &tcp_conn[listen_fd];
	pa_tcp_conn_init(conn);
	
	conn->tci_listen = 1;
	memcpy(&conn->tci_laddr[0], addr, addr->sa_len);

	client[1].fd = listen_fd;
	client[1].events = POLLIN;
	client[1].revents = 0;

	fd_num++;
	
	for (poll_index = 2; poll_index < PA_CLIENT_MAX; poll_index++) {
		client[poll_index].fd = -1;
	}

	while(1){
		PA_PRINT("Before poll fd_num=%d!\n",fd_num);
		nready = poll(client, fd_num, PA_INFINITE);
//		PA_PRINT("After poll!\n");
		if(nready < 0){
			PA_PRINT("Poll error!ret = %d\n",nready);
		}

		if (nready == 0) {
			PA_PRINT("Poll timeout !\n");
			goto out;
		}

		/*
		 * Proccess message from application thread
		 */
		if (client[0].revents & POLLIN){
			PA_PRINT("Socket pair message!\n");
			recv_len = recv(listen_thread_fd, itc_msg, sizeof(*itc_msg), MSG_DONTWAIT);
			if (recv_len < 0) {
				PA_PRINT("Recv error!errno=%d\n",errno);
				continue;
			}

			if (recv_len == 0) {
				PA_PRINT("No message received!\n");
				continue;
			}

			sock_fd = itc_msg->im_sockfd;
			conn = &tcp_conn[sock_fd];
			switch (itc_msg->im_msg_type) {
				case PA_MSG_TYPE_SOCK_LISTEN:
					for (poll_index = 1; poll_index < PA_CLIENT_MAX; poll_index++) {
						if (client[poll_index].fd < 0){
							client[poll_index].fd = sock_fd;
							client[poll_index].events = POLLIN;
							client[poll_index].revents = 0;
							conn->tci_poll_index = poll_index;
							break;
						}
					}

					if (poll_index >= PA_CLIENT_MAX) {
						PA_PRINT("Too many clients!\n");
						pa_tcp_submit_event(conn, PA_TCP_EVENT_ERR);
						continue;
					}

					conn->tci_listen = 1;

					if (poll_index >= fd_num) {
						fd_num = poll_index + 1;
					}

					break;
				case PA_MSG_TYPE_SOCK_RECV:
					poll_array = &client[conn->tci_poll_index];
					poll_array->events |= POLLIN;
					break;
				case PA_MSG_TYPE_SOCK_SEND:
					poll_array = &client[conn->tci_poll_index];
					err = pa_tcp_send_data(sock_fd);
					if (err < 0) {
						poll_array->events &= ~(POLLIN|POLLOUT);
					} else if (err == 1){
						poll_array->events |= POLLOUT;
					} else {
						poll_array->events &= ~POLLOUT;
					}
					break;
				default:
					PA_PRINT("Msg type error!%u\n",itc_msg->im_msg_type);
					return NULL;
			}

			continue;
		}

		poll_array = &client[1];
		for (poll_index = 1; poll_index < fd_num; poll_index++, poll_array++) {
			if ((sock_fd = poll_array->fd) < 0) {
				continue;
			}

//			PA_PRINT("index = %d,sock_fd = %d, listen fd = %d\n",poll_index, sock_fd,listen_fd);
			conn = &tcp_conn[sock_fd];
			if (conn->tci_listen) {
				/*
				 * Proccess listen socket
				 */
				if (poll_array->revents & POLLIN){
					PA_PRINT("Listen socket have message!\n");
					addr = (struct sockaddr *)&accept_addr;
					connfd = accept(listen_fd, addr, &accept_addr_size);
					if (connfd < 0){
						PA_PRINT("Accept failed!errno = %d\n",errno);
						continue;
					}

					for (poll_index = 1; poll_index < PA_CLIENT_MAX; poll_index++) {
						if (client[poll_index].fd < 0){
							client[poll_index].fd = connfd;
							client[poll_index].events = POLLIN;
							client[poll_index].revents = 0;
							conn->tci_poll_index = poll_index;
							break;
						}
					}

					if (poll_index >= PA_CLIENT_MAX) {
						PA_PRINT("Too many clients!\n");
						continue;
					}

					new_conn = &tcp_conn[connfd];
					pa_tcp_conn_init(new_conn);
					new_conn->tci_tcp_sockfd = pa_client_thread_fd; 

					/*
					 * Choose an application thread to process this connection
					 */
					pa_app_find_thread(&new_conn->tci_tid);
					conn->tci_has_thread = 1;

					memcpy(&new_conn->tci_faddr[0], addr, addr->sa_len);
					addr = &conn->tci_laddr[0];
					memcpy(&new_conn->tci_laddr[0], addr, addr->sa_len);

					/*
					 * Send new connection notification to proccess thread
					 */
					err = pa_app_add_new_conn(new_conn->tci_tid, connfd);
					if (err < 0) {
						PA_PRINT("Add new connection failed!\n");
						client[poll_index].fd = -1;
						close(connfd);
						continue;
					}

					PA_PRINT("Add new connection success!\n");
					if (poll_index >= fd_num) {
						fd_num = poll_index + 1;
					}

					if (--nready <= 0) {
						continue;
					}
				}
				continue;
			}

			if (poll_array->revents & (POLLIN|POLLERR)) {
				/*
				 * Proccess message from common connection
				 */
				err = pa_tcp_recv_data(sock_fd);
				if (err < 0) {
					continue;
				}
				if (err == 1) {
					poll_array->revents &= ~POLLIN;
				}
			}

			/*
			 * Write able events comming
			 */
			if (poll_array->revents & POLLOUT) {
				/*
				 * Proccess message from common connection
				 */
				err = pa_tcp_send_data(sock_fd);
				if (err < 0) {
					poll_array->events &= ~(POLLIN|POLLOUT);
				} else if (err == 1){
					poll_array->events &= ~POLLOUT;
				}
			}

			/*
			 * Invalid fd event, this happend when application thread
			 * close the fd
			 */
			if (poll_array->revents & POLLNVAL) {
				PA_PRINT("Close socket sockfd=%d!\n",sock_fd);
				poll_array->fd = -1;
				close(sock_fd);
				continue;
			}

			if (--nready <= 0){
				break;
			}
		}
	}

out:
	return NULL;
}

/*
 * TCP server thread process function. It serve for the application thread,
 * and connect to the real server
 */
static void *
pa_tcp_server(void *arg)
{
	struct pollfd client[PA_CLIENT_MAX] = {};
	struct pollfd *poll_array = NULL;
	pa_tcp_conn_info *conn = NULL;
	pa_itc_msg msg_buff;
	pa_itc_msg *itc_msg = &msg_buff;
	int pair_fd[2] = {};
	ssize_t recv_len = 0;
	int listen_fd = 0;
	int sock_fd = 0;
	int fd_num = 0;
	int poll_index = 0;
	int nready = 0;
	int err = 0;

	/*
	 * Create a pair of unix socket for conmunication with
	 * application thread
	 */
	err = socketpair(AF_UNIX, SOCK_DGRAM, 0, pair_fd);
	if (err < 0){
		PA_PRINT("Server socketpair failed! errno = %d\n",errno);
		return NULL;
	}

	listen_fd = pair_fd[0];
	pa_server_thread_fd = pair_fd[1];

	client[0].fd = listen_fd;
	client[0].events = POLLIN;
	client[0].revents = 0;
	fd_num++;

	for (poll_index = 1; poll_index < PA_CLIENT_MAX; poll_index++) {
		client[poll_index].fd = -1;
	}

	while(1){
		PA_PRINT("Before poll!\n");
		nready = poll(client, fd_num, PA_INFINITE);
		PA_PRINT("After poll!\n");
		if (nready < 0) {
			PA_PRINT("Poll error!ret = %d\n",nready);
		}

		if (nready == 0) {
			PA_PRINT("Poll timeout !\n");
			goto out;
		}

		/*
		 * Proccess message from application thread
		 */
		if (client[0].revents & (POLLIN|POLLERR)) {
			recv_len = recv(listen_fd, itc_msg, sizeof(*itc_msg), MSG_DONTWAIT);
			if (recv_len < 0) {
				PA_PRINT("Recv error!errno=%d\n",errno);
				continue;
			}

			sock_fd = itc_msg->im_sockfd;
			PA_PRINT("Msg sockfd = %d,type=%d\n",sock_fd,itc_msg->im_msg_type);
			conn = &tcp_conn[sock_fd];
			switch (itc_msg->im_msg_type) {
				case PA_MSG_TYPE_SOCK_CONN:
					for (poll_index = 1; poll_index < PA_CLIENT_MAX; poll_index++) {
						if (client[poll_index].fd < 0){
							client[poll_index].fd = sock_fd;
							client[poll_index].events = POLLIN;
							client[poll_index].revents = 0;
							conn->tci_poll_index = poll_index;
							break;
						}
					}

					if (poll_index >= PA_CLIENT_MAX) {
						PA_PRINT("Too many clients!\n");
						pa_tcp_submit_event(conn, PA_TCP_EVENT_ERR);
						continue;
					}

					/*
					 * Send new connection notification to proccess thread
					 */
					if (poll_index >= fd_num) {
						fd_num = poll_index + 1;
					}

					break;
				case PA_MSG_TYPE_SOCK_RECV:
					poll_array = &client[conn->tci_poll_index];
					poll_array->events |= POLLIN;
					break;
				case PA_MSG_TYPE_SOCK_SEND:
					PA_PRINT("Send data!sockfd = %d\n",sock_fd);
					poll_array = &client[conn->tci_poll_index];
					err = pa_tcp_send_data(sock_fd);
					if (err < 0) {
						poll_array->events &= ~(POLLIN|POLLOUT);
					} else if (err == 1){
						poll_array->events |= POLLOUT;
					} else {
						poll_array->events &= ~POLLOUT;
					}
					break;
				default:
					PA_PRINT("Msg type error!%u\n",itc_msg->im_msg_type);
					return NULL;
			}
			continue;
		}

		for (poll_index = 1; poll_index < fd_num; poll_index++) {
			poll_array = &client[poll_index];
			if ((sock_fd = poll_array->fd) < 0) {
				continue;
			}

			if (poll_array->revents & (POLLIN|POLLERR)) {
				/*
				 * Proccess message from common connection
				 */
				PA_PRINT("Receive data!\n");
				err = pa_tcp_recv_data(sock_fd);
				if (err < 0) {
					continue;
				}
				if (err == 1) {
					poll_array->revents &= ~POLLIN;
				}
			}

			/*
			 * Write able events comming
			 */
			if (poll_array->revents & POLLOUT) {
				/*
				 * Proccess message from common connection
				 */
				err = pa_tcp_send_data(sock_fd);
				if (err < 0) {
					poll_array->events &= ~(POLLIN|POLLOUT);
				} else if (err == 1){
					poll_array->events &= ~POLLOUT;
				}
			}

			/*
			 * Invalid fd event, this happend when application thread
			 * close the fd
			 */
			if (poll_array->revents & POLLNVAL) {
				poll_array->fd = -1;
				close(sock_fd);
				continue;
			}
		}
	}

out:
	return NULL;
}

/*
 * Save the thread id of TCP client thread
 */
pthread_t 	pa_tcp_client_id;

/*
 * Save the thread id of TCP server thread
 */
pthread_t 	pa_tcp_server_id;

/*
 * Initialize TCP resource before process TCP data
 * @cmd_info: command parameter assigned by command line 
 * If success, return 0
 * If error, return -1
 */
int 
pa_tcp_init(pa_cmd_info *cmd_info)
{
	unsigned short *port = 0;
	pa_tcp_conn_info *conn = NULL;
	int index = 0;
	int err = 0;

	for (index = 0; index < PA_TCP_MAX_CONN_NUM; index++) {
		conn = &tcp_conn[index];
		conn->tci_events_lock = PTHREAD_MUTEX_INITIALIZER;
		conn->tci_recv_buff.tdb_lock = PTHREAD_MUTEX_INITIALIZER; 
		conn->tci_send_buff.tdb_lock = PTHREAD_MUTEX_INITIALIZER; 
	}

	/*
	 * Create TCP client thread
	 */
	if (pthread_create(&pa_tcp_client_id, NULL, pa_tcp_client, cmd_info) < 0){
		PA_PRINT("Create client thread of protocol failed!\n");
		return -1;
	}

	/*
	 * Create TCP server thread
	 */
	if (pthread_create(&pa_tcp_server_id, NULL, pa_tcp_server, NULL) < 0){
		PA_PRINT("Create server thread of protocol failed!\n");
		return -1;
	}

	/*
	 * Create application thread
	 */
	port = (unsigned short *)(&cmd_info->pci_addr->sa_data[0]);
	err = pa_tcp_create_app_thread(cmd_info->pci_thread_num, *port);
	if (err < 0){
		PA_PRINT("TCP thread create failed!\n");
		return -1;
	}

	return 0;
}

/*
 * Free the resource alloc in pa_tcp_init
 */
void 
pa_tcp_exit(void)
{
	PA_PRINT("TCP exit!\n");
	pa_app_thread_exit();

	if (pthread_cancel(pa_tcp_server_id) < 0){
		PA_PRINT("Cancel TCP server thread failed!\n");
	} else {
		PA_PRINT("TCP server thread canceled!\n");
	}

	if (pthread_cancel(pa_tcp_client_id) < 0){
		PA_PRINT("Cancel TCP client thread failed!\n");
	} else {
		PA_PRINT("TCP client thread canceled!\n");
	}
}
