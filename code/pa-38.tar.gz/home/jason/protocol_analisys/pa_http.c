#include <stdio.h>
#include <pthread.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <arpa/inet.h>
#include <poll.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
	
#include "pa_app.h"
#include "pa_tcp.h"
#include "pa_http.h"
#include "pa_debug.h"

#define PA_HTTP_POLL_NUM	2

#define PA_HTTP_CONN_NUM	65535

/*
 * The http connection array
 */
static pa_http_conn http_conn[PA_HTTP_CONN_NUM] = {};

/*
 * Initiallize a http connection structure
 * @conn: http connection
 */
static void pa_http_conn_init(pa_http_conn *conn)
{
	memset(conn, 0, sizeof(*conn));
	conn->hc_sock_fd = -1;
	conn->hc_peer_fd = -1;
}

/*
 * Get the dest address of the server
 * @addr: address pointer
 * @addrlen: pointer to the length of addr
 * If success, return address and the length of it in addr and addrlen
 */
static int 
pa_http_get_server_addr(struct sockaddr *addr, socklen_t *addrlen)
{
	char addr_buff[128] = {"192.168.204.217"};
	struct sockaddr_in in;

	*addrlen = sizeof(in);
	in.sin_family = AF_INET;
	in.sin_port = htons(80);
	in.sin_addr.s_addr = inet_addr(addr_buff);
	memcpy(addr, &in, *addrlen);

	return 0;
}

#define PA_HTTP_CLIENT_MAX	30000

/*
 * HTTP process thread handler
 */
void *pa_http_handler(void *arg)
{
	struct pollfd client[PA_HTTP_CLIENT_MAX] = {};
	struct pollfd *poll_array = NULL;
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}l_addr;
	struct sockaddr *laddr = (struct sockaddr *)&l_addr;
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}f_addr;
	struct sockaddr *faddr = (struct sockaddr *)&f_addr;
	socklen_t addrlen;
	union{
		struct sockaddr_in in4;
		struct sockaddr_in6 in6;
	}s_addr;
	struct sockaddr *server_addr = (struct sockaddr *)&s_addr;
	socklen_t server_addrlen;
	pa_http_conn *conn = NULL;
	pa_http_conn *peer_conn = NULL;
	unsigned char *recv_buff = NULL;
	unsigned char *send_buff = NULL;
	unsigned int space = 0;
	ssize_t recv_len = 0;
	ssize_t send_len = 0;
	int conn_num = 0;
	int sock_fd = 0;
	int peer_fd = 0;
	int accept_sockfd = 0;
	int conn_sockfd = 0;
	int poll_index = 0;
	int nready = 0;
	int err = 0;

	PA_PRINT("Http start!\n");

	for (poll_index = 0; poll_index < PA_HTTP_CLIENT_MAX; poll_index++) {
		poll_array = &client[poll_index];
		poll_array->fd = -1;
	}

	while (1) {
		PA_PRINT("Before poll!\n");
		nready = pa_tcp_poll(client, conn_num, PA_INFINITE);
		PA_PRINT("After poll!nready=%d\n",nready);
		/*
		 * Find acceptable connection from client
		 */
		accept_sockfd = pa_tcp_accept(laddr, faddr, &addrlen);
		if (accept_sockfd >= 0) {
			PA_PRINT("Accept!\n");
			err = pa_http_get_server_addr(server_addr, &server_addrlen);
			if (err < 0) {
				pa_tcp_close(accept_sockfd);
				continue;
			}
			/*
			 * Connection to server
			 */
			conn_sockfd = pa_tcp_connect(server_addr, server_addrlen);
			if (conn_sockfd < 0) {
				pa_tcp_close(accept_sockfd);
				continue;
			}
			PA_PRINT("Connect sock fd = %d!\n",conn_sockfd);
			conn = &http_conn[accept_sockfd];
			pa_http_conn_init(conn);
			conn->hc_sock_fd = accept_sockfd;
			conn->hc_peer_fd = conn_sockfd;
			peer_conn = &http_conn[conn_sockfd];
			pa_http_conn_init(peer_conn);
			peer_conn->hc_sock_fd = conn_sockfd;
			peer_conn->hc_peer_fd = accept_sockfd;
			for (poll_index = 0; poll_index < PA_HTTP_CLIENT_MAX; poll_index++) {
				poll_array = &client[poll_index];
				if (poll_array->fd < 0) {
					poll_array->fd = accept_sockfd; 
					poll_array->events = (PA_TCP_EVENT_IN|PA_TCP_EVENT_ERR);
					poll_array->revents = 0;
					break;
				}
			}
			if (poll_index >= PA_HTTP_CLIENT_MAX) {
				PA_PRINT("Too many clients!\n");
				pa_tcp_close(accept_sockfd);
				pa_tcp_close(conn_sockfd);
				break;
			}
			conn->hc_poll_index = poll_index;
			for (; poll_index < PA_HTTP_CLIENT_MAX; poll_index++) {
				poll_array = &client[poll_index];
				if (poll_array->fd < 0) {
					poll_array->fd = conn_sockfd; 
					poll_array->events = (PA_TCP_EVENT_IN|PA_TCP_EVENT_ERR);
					poll_array->revents = 0;
					break;
				}
			}
			if (poll_index >= PA_HTTP_CLIENT_MAX) {
				PA_PRINT("Too many clients!\n");
				client[conn->hc_poll_index].fd = -1;
				pa_tcp_close(accept_sockfd);
				pa_tcp_close(conn_sockfd);
				break;
			}
			peer_conn->hc_poll_index = poll_index;
			if (poll_index >= conn_num) {
				conn_num = poll_index + 1;
			}
		}

		/*
		 * Receive or send data
		 */
		for (poll_index = 0; poll_index < conn_num; poll_index++) {
			PA_PRINT("Sockfd=%d,index=%d!\n",sock_fd,poll_index);
			poll_array = &client[poll_index];
			if ((sock_fd = poll_array->fd) < 0) {
				continue;
			}

			conn = &http_conn[sock_fd];
			peer_fd = conn->hc_peer_fd;
			peer_conn = &http_conn[peer_fd];
			if (poll_array->revents & (PA_TCP_EVENT_IN|PA_TCP_EVENT_ERR)) {
				PA_PRINT("Sockfd=%d!\n",sock_fd);
				send_buff = &peer_conn->hc_buff[0];
				recv_buff = send_buff + peer_conn->hc_data_len;
				space = PA_HTTP_BUFF_LEN - peer_conn->hc_data_len;
				recv_len = pa_tcp_recv(sock_fd, recv_buff, space, 0);
				if (recv_len <= 0) {
					PA_PRINT("Close sockfd=%d!\n",sock_fd);
					conn->hc_closing = 1;
					if (conn->hc_data_len == 0) {
						poll_array->fd = -1; 
						pa_tcp_close(sock_fd);
					}

					peer_conn->hc_closing = 1;
					if (peer_conn->hc_data_len == 0) {
						client[peer_conn->hc_poll_index].fd = -1;
						pa_tcp_close(peer_fd);
					}
					continue;
				}

				peer_conn->hc_data_len += recv_len;
				PA_PRINT("Send sock fd = %d!,data_len=%d\n",peer_fd,(int)peer_conn->hc_data_len);
				pa_data_print(send_buff, peer_conn->hc_data_len);
				send_len = pa_tcp_send(peer_fd, send_buff, peer_conn->hc_data_len, 0);
				if (send_len < 0) {
					poll_array->fd = -1; 
					pa_tcp_close(sock_fd);
					client[peer_conn->hc_poll_index].fd = -1;
					pa_tcp_close(peer_fd);
					continue;
				}
				peer_conn->hc_data_len -= send_len;
				if (send_len < peer_conn->hc_data_len) {
					poll_array->events |= POLLOUT;
					if (send_len > 0) {
						memmove(send_buff, send_buff + send_len, send_len);
					}
				} else {
					poll_array->events &= ~POLLOUT;
				}

				if (peer_conn->hc_data_len == 0 && peer_conn->hc_closing) {
					client[peer_conn->hc_poll_index].fd = -1;
					pa_tcp_close(peer_fd);
				}
			}

			if (poll_array->revents & PA_TCP_EVENT_OUT) {
				PA_PRINT("POLLOUT sockfd=%d!\n",sock_fd);
				if (conn->hc_data_len == 0) {
					continue;
				}
				send_buff = &conn->hc_buff[0];
				send_len = pa_tcp_send(sock_fd, send_buff, conn->hc_data_len, 0);
				if (send_len < 0) {
					conn->hc_closing = 1;
					if (conn->hc_data_len == 0) {
						poll_array->fd = -1; 
						pa_tcp_close(sock_fd);
					}

					peer_conn->hc_closing = 1;
					if (peer_conn->hc_data_len == 0) {
						client[peer_conn->hc_poll_index].fd = -1;
						pa_tcp_close(peer_fd);
					}
					continue;
				}
				conn->hc_data_len -= send_len;
				if (send_len < conn->hc_data_len) {
					if (send_len > 0) {
						memmove(send_buff, send_buff + send_len, send_len);
					}
				} else {
					poll_array->events &= ~POLLOUT;
				}

				if (conn->hc_data_len == 0 && conn->hc_closing) {
					client[conn->hc_poll_index].fd = -1;
					pa_tcp_close(sock_fd);
				}
			}

			if (--nready <= 0) {
				continue;
			}
		}
	}

	return NULL;
}

