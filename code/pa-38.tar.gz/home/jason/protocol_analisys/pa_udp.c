#include <stdio.h>
#include <pthread.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <errno.h>
	
#include "pa_main.h"
#include "pa_debug.h"

void *
pa_udp_server(void *arg)
{
	return NULL;
}

void *
pa_udp_client(void *arg)
{
	return NULL;
}

int 
pa_udp_init(pa_cmd_info *cmd_info)
{
	return 0;
}

void pa_udp_exit(void)
{
}
