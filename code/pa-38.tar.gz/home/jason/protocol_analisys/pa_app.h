#ifndef __PA_APP_H__
#define __PA_APP_H__

#include <stdbool.h>
#include <netinet/in.h>
#include <pthread.h>

typedef struct _pa_app_proc {
	unsigned short ap_port;			//Transport layer port number
	void *(*ap_handler)(void *); 	//Application process function
}pa_app_proc;

#define PA_APP_ACCEPT_CONN_NUM	10000

typedef struct _pa_app_conn_queue{
	int acq_head;							//Accept queue ring head
	int acq_tail;							//Accept queue ring tail
	int	acq_sockfd[PA_APP_ACCEPT_CONN_NUM];	//Accept queue ring array	
}pa_app_conn_queue;

typedef struct _pa_app_thread_info{
	pthread_mutex_t ati_lock;				//Mutex lock, protect the whole struct
	pthread_cond_t ati_cond;				//Application thread weekup condition struct
	bool ati_has_event;						//When the TCP thread has event to notify the application thread,
											//ati_has_event will be set to 1
	unsigned int ati_conn_num;				//The number of connection process by this application thread
	pa_app_conn_queue ati_accept_queue;		//Accept queue
	pthread_t 	ati_tid;					//Thread id of the thread
}pa_app_thread_info;

extern void pa_app_find_thread(pthread_t *tid);
extern int pa_app_create_thread(void *(*app_handler)(void *), unsigned int thread_num);
extern void pa_app_thread_exit(void);
extern int pa_app_wakeup_thread(pthread_t tid);
extern int pa_app_thread_sleep(int timeout);
extern int pa_app_add_new_conn(pthread_t tid, int sockfd);
extern int pa_app_get_accept_sockfd(void);
extern bool pa_app_has_new_conn(void);
extern int pa_app_get_new_conn(unsigned long thread_index, int *accept_buff, int buf_len);

#endif
