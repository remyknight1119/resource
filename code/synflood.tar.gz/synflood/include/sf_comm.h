#ifndef __SF_COMM_H__
#define __SF_COMM_H__

enum{
	SF_CMD_START = 1 << 5,
	KS_SYSCALL_OPEN,
	KS_SYSCALL_SET_FILTER,
	KS_SYSCALL_REGISTER_VM,
	SF_CMD_REGISGER,
	SF_CMD_UNREGISGER,
	SF_CMD_MAX,
};

#define KS_VM_DIR_IN    1
#define KS_VM_DIR_OUT   2

typedef struct {
    const char   *vm_name;
    unsigned int dir;
} ks_filter_t;

typedef struct {
    ks_filter_t     *filter;
    int             count;
} ks_cmd_set_filter_t;

typedef struct {
    unsigned char mac[6];
} ks_macs_t;

typedef struct {
    const char  *vm_name;
    ks_macs_t   *macs;
    int          count;
} ks_cmd_macs_t;

#define INTERFACE_NAME_LEN	8

#ifndef ETH_ALEN 
#define ETH_ALEN 6
#endif

typedef struct _synflood_thread_info {
	char	sti_if_name[INTERFACE_NAME_LEN];
	unsigned char	sti_dst_mac[ETH_ALEN];
	unsigned short	sti_th_num;
	unsigned int	sti_start_saddr;
	unsigned int	sti_end_saddr;
	unsigned int	sti_saddr;
	unsigned int	sti_daddr;
	unsigned short	sti_start_sport;
	unsigned short	sti_end_sport;
	unsigned short	sti_sport;
	unsigned short	sti_dport;
}synflood_thread_info; 

#endif
