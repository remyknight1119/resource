#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


extern int ks_open(const char *vmname, int flags);

int main(void)
{
    int fd;

    fd = ks_open("/path/to/vm", O_RDONLY);
    if (fd < 0) {
        printf("open failed\n");
        return -1;
    }

    return 0;
}

