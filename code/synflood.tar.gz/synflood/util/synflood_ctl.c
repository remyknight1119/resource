#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/poll.h>
//#include <linux/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../include/sf_comm.h"

static const char *program_name;
static const char *program_version;

static const struct option long_opts[] = {
	{"help", 0, 0, 'H'},
	{"register", 1, 0, 'R'},
	{"unregister", 1, 0, 'U'},
	{"eth-name", 1, 0, 'e'},
	{"thread-id", 1, 0, 't'},
	{"dmac", 1, 0, 'i'},
	{"dip", 1, 0, 'j'},
	{"dport", 1, 0, 'q'},
	{"start-sip", 1, 0, 'a'},
	{"end-sip", 1, 0, 'b'},
	{"start-sport", 1, 0, 'c'},
	{"end-sport", 1, 0, 'd'},
	{0, 0, 0, 0},
};

static const char *options[] = {
	"--register		-R  register a kernel thread to send syn\n",
	"--unregister		-U  unregister a kernel thread\n",
	"--eth-name			-e  the name of interface which the thread to send from\n",
	"--thread-id			-t  the id of the thread\n",
	"--dmac			-i  dest mac address of the syn\n",
	"--dip			-j  dest ip address of the syn\n",
	"--dport		-q  dest port number of the syn\n",
	"--start-sip		-a  the start scope of the source ip of syn\n",
	"--end-sip		-b  the end scope of the source ip of syn\n",
	"--start-sport		-c  the start scope of the source port of syn\n",
	"--end-sport		-d  the end scope of the source port of syn\n",
	"--help		-H  Print help information\n",
};
	
static void help()
{
	int i;

	fprintf(stdout, "Version: %s\n", program_version);
	
	fprintf(stdout, "\nOptions:\n");
	for(i = 0; i < sizeof(options)/sizeof(char *); i ++) {
		fprintf(stdout, "  %s", options[i]);
	}
		
	return;
}

#define SF_SEEN_TH_NUM		0x0001
#define SF_SEEN_MAC			0x0002
#define SF_SEEN_DIP			0x0004
#define SF_SEEN_DPORT		0x0008
#define SF_SEEN_START_SIP	0x0010
#define SF_SEEN_END_SIP		0x0020
#define SF_SEEN_START_SPORT	0x0040
#define SF_SEEN_END_SPORT	0x0080
#define SF_SEEN_ETH_NAME	0x0100

int sf_check_arg(unsigned int cmd, unsigned int seen, synflood_thread_info *info)
{
	if (cmd == SF_CMD_REGISGER){
		if (!(seen & SF_SEEN_MAC)){
			printf("Please input dest mac with -i!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_DIP)){
			printf("Please input dest IP with -j!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_DPORT)){
			printf("Please input dest port with -q!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_START_SIP)){
			printf("Please input start source IP with -a!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_END_SIP)){
			printf("Please input end source IP with -b!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_START_SPORT)){
			printf("Please input start source port with -c!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_END_SPORT)){
			printf("Please input end source port with -d!\n");
			return -1;
		}

		if (!(seen & SF_SEEN_ETH_NAME)){
			printf("Please input eth name with -e!\n");
			return -1;
		}

		if (ntohl(info->sti_start_saddr) >= ntohl(info->sti_end_saddr)){
			printf("Error!end saddr is smaller than start saddr!\n");
			return -1;
		}

		if (ntohs(info->sti_start_sport) >= ntohs(info->sti_end_sport)){
			printf("Error!end sport is smaller than start sport!\n");
			return -1;
		}
	} else if (cmd != SF_CMD_UNREGISGER){
		printf("Please input -R or -U!\n");
		return -1;
	}

	if (!(seen & SF_SEEN_TH_NUM)){
		printf("Please input thread number with -t!\n");
		return -1;
	}

	return 0;
}

int sf_syscall(unsigned int cmd, void *arg);

#define IP_ADDR_LEN 128

int main(int argc, char *argv[]) 
{
	int c = 0;
	char addr[IP_ADDR_LEN] = {};
	unsigned int cmd = 0;
	unsigned int seen = 0;
	synflood_thread_info info;

	program_name = argv[0];
	program_version = "1.0";

	memset(&info, 0, sizeof(info));
	while((c = getopt_long(argc, argv,
					"HRUi:j:t:q:a:b:c:d:e:",  long_opts, NULL)) != -1) {
		switch(c) {
			case 'H':
				help();
				goto out;
			case 'R':
				cmd = SF_CMD_REGISGER;
				break;
			case 'U':
				cmd = SF_CMD_UNREGISGER;
				break;
			case 'i':
				seen |= SF_SEEN_MAC;
				strncpy((char *)(&info.sti_dst_mac), optarg, ETH_ALEN);
				break;
			case 'j':
				seen |= SF_SEEN_DIP;
				memset(addr, 0, IP_ADDR_LEN);
				strncpy(addr, optarg, IP_ADDR_LEN);
				info.sti_daddr = inet_addr(addr);
				break;
			case 't':
				seen |= SF_SEEN_TH_NUM;
				info.sti_th_num = atoi(optarg);
				break;
			case 'q':
				seen |= SF_SEEN_DPORT;
				info.sti_dport = atoi(optarg);
				break;
			case 'a':
				seen |= SF_SEEN_START_SIP;
				memset(addr, 0, IP_ADDR_LEN);
				strncpy(addr, optarg, IP_ADDR_LEN);
				info.sti_start_saddr = inet_addr(addr);
				break;
			case 'b':
				seen |= SF_SEEN_END_SIP;
				memset(addr, 0, IP_ADDR_LEN);
				strncpy(addr, optarg, IP_ADDR_LEN);
				info.sti_end_saddr = inet_addr(addr);
				break;
			case 'c':
				seen |= SF_SEEN_START_SPORT;
				info.sti_start_sport = atoi(optarg);
				break;
			case 'd':
				seen |= SF_SEEN_END_SPORT;
				info.sti_end_sport = atoi(optarg);
				break;
			case 'e':
				seen |= SF_SEEN_ETH_NAME;
				strncpy(info.sti_if_name, optarg, INTERFACE_NAME_LEN);
				break;
			default:
				break;
		}
	}

	if (sf_check_arg(cmd, seen, &info) < 0){
		return -1;
	}

	if (sf_syscall(cmd, &info) < 0){
		return -1;
	}

out:
	return 0;
}

