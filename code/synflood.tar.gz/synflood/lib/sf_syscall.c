/**
 * ===========================================================================
 * FILENAME:   	sf_syscall.c 
 * VERSION:     3.0
 * AUTHOR:      liu_yt
 * DATE:        2010-06-3
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>

int sf_syscall(unsigned int cmd, void *arg)
{
	int sf_cdev_fd = 0;
	int ret = 0;

	sf_cdev_fd = open("/dev/synflood_cdev", O_RDWR);
	if(sf_cdev_fd < 0){
		printf("Open /dev/synflood_cdev failed!\n");
		return -1;
	}


	ret = ioctl(sf_cdev_fd, cmd, arg);
	close(sf_cdev_fd);
	return ret;
}

