/**
 * ===========================================================================
 * FILENAME:   	sf_api.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-10-22
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#include "sf_comm.h"

#define KS_DEV_FILE "/dev/synflood_cdev"

int ks_open(const char *vmname, int flags)
{
    int fd;
    int ret;

	fd = open(KS_DEV_FILE, flags);
	if(fd < 0){
        printf("Open failed\n");
        return -1;
    }

	ret = ioctl(fd, KS_SYSCALL_OPEN, vmname);
    if (ret < 0) {
        close(fd);
        printf("Ioctl failed\n");
        return -1;
    }

    return fd;
}

int ks_set_filters(int fd, ks_filter_t *filter, int count)
{
    ks_cmd_set_filter_t filters;

    filters.filter = filter;
    filters.count = count;

	return ioctl(fd, KS_SYSCALL_SET_FILTER, &filters);
}

int ks_register_vm(const char *vmname, ks_macs_t *mac, int count)
{
    ks_cmd_macs_t macs;
    int fd;
    int ret;

    macs.vm_name = vmname;
    macs.macs = mac;
    macs.count = count;

	fd = open(KS_DEV_FILE, O_RDONLY);
	if(fd < 0){
        printf("Open failed\n");
        return -1;
    }

	ret = ioctl(fd, KS_SYSCALL_REGISTER_VM, &macs);
    if (ret < 0) {
        close(fd);
        printf("Ioctl failed\n");
        return -1;
    }

    return fd;
}

