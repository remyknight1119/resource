#ifndef __SF_MAIN_H__
#define __SF_MAIN_H__

#include "../include/sf_comm.h"

int synflood_register_send_thread(synflood_thread_info *th_info);
void synflood_unregister_send_thread(int thread_number);

#endif
