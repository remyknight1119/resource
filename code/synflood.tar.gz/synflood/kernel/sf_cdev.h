#ifndef __SF_CDEV_H__
#define __SF_CDEV_H__

#include <linux/cdev.h>

typedef struct {
	struct cdev cdev;
}sf_cdev_dev;

extern int sf_cdev_init(void);
extern void sf_cdev_exit(void);

#endif
