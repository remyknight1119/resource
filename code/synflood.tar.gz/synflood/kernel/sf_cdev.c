#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <asm/uaccess.h>
#include <linux/string.h>
#include <linux/skbuff.h>
#include <linux/poll.h>

#include "sf_cdev.h"
#include "sf_main.h"

typedef struct {
    struct list_head head;
    spinlock_t  lock;
} ks_list_head;

ks_list_head ks_nf_rule_list;
ks_list_head ks_vm_list;

u8 ks_ignore_mac[ETH_ALEN];

typedef struct {
    u8 mac[ETH_ALEN];
} ks_mac_info_t;

typedef struct {
    char *vm_name;
    ks_mac_info_t *macs;
    u32 mac_num;
    struct list_head list;
} ks_vm_info;

struct ks_file {
    char *vm_name;
    ks_mac_info_t *macs;
    u32 mac_num;
    ks_list_head rule;
    ks_vm_info *reg_vm;
    struct socket_wq    wq;
    struct sk_buff_head receive_queue;
};

typedef struct {
    struct list_head nf_list;
    struct list_head kf_list;
    u8 src_mac[ETH_ALEN];
    u8 dst_mac[ETH_ALEN];
    struct ks_file *receiver;
} ks_filter_rule_t;

void ks_list_init(ks_list_head *list)
{
    spin_lock_init(&list->lock);
    INIT_LIST_HEAD(&list->head);
}

void ks_list_add_tail(ks_list_head *list, struct list_head *new)
{
    spin_lock_bh(&list->lock);
    list_add_tail(new, &list->head);
    spin_unlock_bh(&list->lock);
}

void ks_list_unlink(ks_list_head *list, struct list_head *entry)
{
    spin_lock_bh(&list->lock);
    list_del(entry);
    spin_unlock_bh(&list->lock);
}

struct ks_file *ks_find_rule(struct sk_buff *skb)
{
    unsigned char *mac_header;
    ks_filter_rule_t *rule;
    struct ks_file *kfile = NULL;

    mac_header = skb_mac_header(skb);

    spin_lock(&ks_nf_rule_list.lock);
    list_for_each_entry(rule, &ks_nf_rule_list.head, nf_list) {
        if ((memcpy(rule->dst_mac, ks_ignore_mac, ETH_ALEN) || 
                    memcmp(rule->dst_mac, mac_header, ETH_ALEN))
                && (memcpy(rule->src_mac, ks_ignore_mac, ETH_ALEN) ||
                    memcmp(rule->src_mac, mac_header + ETH_ALEN, ETH_ALEN))) {
            kfile = rule->receiver;
            break;
        }
    }
    spin_unlock(&ks_nf_rule_list.lock);

    return kfile;
}

loff_t sf_cdev_llseek(struct file *file, loff_t offset, int origin)
{                 
	return 0;
}  

ssize_t sf_cdev_read(struct file *file, char __user *buf, size_t size, loff_t *offset)
{
	return 0;
}

ssize_t sf_cdev_write(struct file *file, const char __user *buf, size_t size, loff_t *offset)
{
	return 0;
}

ks_mac_info_t *ks_find_vm_macs(const char *vmname, u32 *count)
{
    ks_mac_info_t *macs = NULL;
    ks_vm_info *vm;

    spin_lock(&ks_vm_list.lock);
    list_for_each_entry(vm, &ks_vm_list.head, list) {
        if (strcmp(vmname, vm->vm_name) == 0) {
            macs = vm->macs;
            *count = vm->mac_num;
            break;
        }
    }
    spin_unlock(&ks_vm_list.lock);


    return macs;
}

int ks_filter_add(ks_mac_info_t *macs, int mac_num, unsigned int dir, struct ks_file *kfile)
{
    ks_filter_rule_t *rule;
    int i;

    for (i = 0; i < mac_num; i++) {
        rule = kmalloc(sizeof(*rule), GFP_KERNEL);
        if (rule == NULL) {
            return -1;
        }
        memset(rule, 0, sizeof(*rule));
        if (dir == KS_VM_DIR_IN) {
            memcpy(rule->dst_mac, macs[i].mac, sizeof(rule->dst_mac));
        } else {
            memcpy(rule->src_mac, macs[i].mac, sizeof(rule->dst_mac));
        }
        rule->receiver = kfile;
        ks_list_add_tail(&kfile->rule, &rule->kf_list);
        ks_list_add_tail(&ks_nf_rule_list, &rule->nf_list);
    }

    return 0;
}

long sf_cdev_ioctl(struct file *file, u32 cmd, ulong args)
{
	synflood_thread_info th_info;
    ks_filter_t *filter;
    ks_filter_t *filter_array;
    ks_vm_info *reg_vm;
    ks_cmd_macs_t cmd_mac;
    ks_mac_info_t *macs;
    ks_cmd_set_filter_t filters;
    struct ks_file *kfile = file->private_data;
    u32 count;
	int thread_num = 0;
	int err = 0;

	if (cmd < SF_CMD_START || cmd > SF_CMD_MAX){
		printk("cmd error! cmd = %u, start = %d ,max = %d\n",cmd, SF_CMD_START, SF_CMD_MAX);
		return -1;
	}

	printk("cmd = %d\n",cmd);
    switch (cmd) {
        case KS_SYSCALL_OPEN:
            printk("%s\n", (char *)args);
            if (kfile->macs) {
                return -1;
            }

            kfile->macs = ks_find_vm_macs((char *)args, &kfile->mac_num);
            if (kfile->macs == NULL) {
                return -1;
            }
            if (kfile->vm_name) {
                return -1;
            }

            kfile->vm_name = kmalloc(strlen((char *)args), GFP_KERNEL);
            if (!kfile->vm_name)
                err = -ENOMEM;
            strcpy(kfile->vm_name, (char *)args);
            break;
        case KS_SYSCALL_SET_FILTER:
            if (copy_from_user(&filters, (void *)args, sizeof(filters))){
                return -1;
            }

            filter_array = kmalloc(sizeof(*filters.filter) * filters.count, GFP_KERNEL);
            if (!filter_array) 
                return -ENOMEM;
            if (copy_from_user(filter_array, (void *)args, sizeof(*filters.filter) * filters.count)){
                kfree(filter_array);
                return -1;
            }
            filter = filter_array;
            while (filters.count > 0) {
                if (filter->dir != KS_VM_DIR_IN && filter->dir != KS_VM_DIR_OUT) {
                    return -1;
                }

                if (filter->vm_name == NULL || strcmp(filter->vm_name, kfile->vm_name) == 0) {
                    err = ks_filter_add(kfile->macs, kfile->mac_num, filter->dir, kfile);
                } else {
                    macs = ks_find_vm_macs(filter->vm_name, &count);
                    if (macs  == NULL) {
                        kfree(filter_array);
                        return -1;
                    }
                    err = ks_filter_add(macs, count, filter->dir, kfile);
                    kfree(macs);
                }
                if (err < 0) {
                    return -1;
                }
                filters.count--;
                filter++;
            }

            kfree(filter_array);
            break;
        case KS_SYSCALL_REGISTER_VM:
            if (copy_from_user(&cmd_mac, (void *)args, sizeof(cmd_mac))){
                return -1;
            }

            if (cmd_mac.macs == NULL) {
                return -1;
            }

            reg_vm = kmalloc(sizeof(*reg_vm), GFP_KERNEL);
            if (reg_vm == NULL) {
                return -1;
            }

            reg_vm->macs = kmalloc(sizeof(ks_mac_info_t) * cmd_mac.count, GFP_KERNEL);
            if (reg_vm->macs == NULL) 
                return -1;

            if (copy_from_user(reg_vm->macs, cmd_mac.macs, sizeof(ks_mac_info_t) * cmd_mac.count)){
                return -1;
            }

            kfile->reg_vm = reg_vm;

            break;
        case SF_CMD_REGISGER:
            if (copy_from_user(&th_info, (void *)args, sizeof(th_info))){
                return -1;
            }

            err = synflood_register_send_thread(&th_info);
            break;
        case SF_CMD_UNREGISGER:
            if (copy_from_user(&thread_num, (void *)args, sizeof(thread_num))){
                return -1;
            }

            synflood_unregister_send_thread(thread_num);
            break;
        default:
            err = -EINVAL;
            break;
    }

	return err;
}

static int sf_cdev_open(struct inode *inode, struct file *file)
{
    struct ks_file *kfile;

    printk("tunX: sf_chr_open\n");

    kfile = kmalloc(sizeof(*kfile), GFP_KERNEL);
    if (!kfile)
        return -ENOMEM;

    memset(kfile, 0, sizeof(*kfile));
    ks_list_init(&kfile->rule);
    init_waitqueue_head(&kfile->wq.wait);
    file->private_data = kfile;

	return 0;
}

static int sf_cdev_release(struct inode *inode, struct file *file)
{
    struct ks_file *kfile = file->private_data;
    ks_filter_rule_t *rule, *n;

    spin_lock_bh(&kfile->rule.lock);
    list_for_each_entry_safe(rule, n, &kfile->rule.head, kf_list) {
        list_del(&rule->kf_list);
        ks_list_unlink(&ks_nf_rule_list, &rule->nf_list);
        kfree(rule);
    }
    spin_unlock_bh(&kfile->rule.lock);

    if (kfile->vm_name)
        kfree(kfile->vm_name);

    if (kfile->macs)
        kfree(kfile->macs);

    if (kfile->reg_vm) {
        spin_lock_bh(&ks_vm_list.lock);
        list_del(&kfile->reg_vm->list);
        spin_unlock_bh(&ks_vm_list.lock);
        if (kfile->reg_vm->macs) {
            kfree(kfile->reg_vm->macs);
        }
    }

    kfree(kfile);

	return 0;
}

static unsigned int ks_cdev_poll(struct file *file, poll_table * wait)
{
    struct ks_file *kfile = file->private_data;
    unsigned int mask = 0;

    poll_wait(file, &kfile->wq.wait, wait);

    if (!skb_queue_empty(&kfile->receive_queue))
         mask |= POLLIN | POLLRDNORM;

    return mask;
}

struct file_operations sf_cdev_fops = {
	.owner = THIS_MODULE,
	.llseek = sf_cdev_llseek,
	.read = sf_cdev_read,
	.write = sf_cdev_write,
    .poll   = ks_cdev_poll,
	.unlocked_ioctl = sf_cdev_ioctl,
	.open = sf_cdev_open,
	.release = sf_cdev_release,
};

int sf_cdev_major = 0;
int sf_cdev_minor = 0;

int sf_cdev_get_dev_num(void)
{
	dev_t dev;
	int ret = alloc_chrdev_region(&dev, sf_cdev_minor, 1, "synflood_cdev");

	sf_cdev_major = MAJOR(dev);
	if(ret < 0){
		printk("Can't get major!\n");
	}

	printk("Scd_major = %d!\n",sf_cdev_major);
	return ret;
}

static void sf_cdev_setup_cdev(sf_cdev_dev *dev, int index)
{
	int err, devno = MKDEV(sf_cdev_major, sf_cdev_minor + index);

	cdev_init(&dev->cdev, &sf_cdev_fops);
	dev->cdev.owner = THIS_MODULE;
	err = cdev_add(&dev->cdev, devno, 1);
	if(err){
		printk("Error in adding sf_cdev_dev!\n");
	}
}

static void sf_cdev_exit_cdev(sf_cdev_dev *dev, int index)
{
	int devno = MKDEV(sf_cdev_major, sf_cdev_minor + index);

	cdev_del(&dev->cdev);
	unregister_chrdev_region(devno, 1);
}

sf_cdev_dev sf_cdev_cdev;

int sf_cdev_init(void)
{
    ks_list_init(&ks_nf_rule_list);
    ks_list_init(&ks_vm_list);
    if(sf_cdev_get_dev_num() < 0){
		return -1;
	}

	sf_cdev_setup_cdev(&sf_cdev_cdev ,0);
	return 0;
}

void sf_cdev_exit(void)
{
	sf_cdev_exit_cdev(&sf_cdev_cdev, 0);
}

