#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define HTTP_GET_REQUEST    "GET / HTTP/1.1\r\nHost: 61.147.70.212\r\nKeep-Alive: 300\r\nConnection: keep-alive\r\nUser-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2\r\nReferer: 56zx5tkgnx.com\r\n\r\n"

static unsigned char *file_content;
static unsigned int file_size;
static struct sockaddr_in daddr;
static const char *program_name;
static const char *program_version;

static const struct option long_opts[] = {
	{"help", 0, 0, 'H'},
	{"thread-num", 1, 0, 'n'},
	{"dip", 1, 0, 'j'},
	{"dport", 1, 0, 'q'},
	{"file", 1, 0, 'f'},
	{0, 0, 0, 0},
};

static const char *options[] = {
	"--thread-num    -n  the number of the thread\n",
	"--dip           -j  dest ip address\n",
	"--dport         -q  dest port number\n",
	"--file          -f  file to send\n",
	"--help          -H  Print help information\n",
};
	
static void help()
{
	int i;

	fprintf(stdout, "Version: %s\n", program_version);
	
	fprintf(stdout, "\nOptions:\n");
	for(i = 0; i < sizeof(options)/sizeof(char *); i ++) {
		fprintf(stdout, "  %s", options[i]);
	}
		
	return;
}

static void *send_package(void *arg)
{
    int             sockfd;
    int             buf_len;
    ssize_t         wlen;
    char            *buf;

    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd < 0) {
		fprintf(stderr, "create sockfd failed\n");
        return NULL;
    }

    if (connect(sockfd, (struct sockaddr *)&daddr, sizeof(daddr)) < 0) {
		fprintf(stderr, "connect failed\n");
        return NULL;
    }

    buf = HTTP_GET_REQUEST;
    buf_len = strlen(buf);
    while (1) {
         wlen = write(sockfd, buf, buf_len);
         if (wlen < 0) {
             goto out;
         }
         buf_len -= wlen;
         buf += wlen;
         if (buf_len == 0) {
             break;
         }
    }

    while (1) {
        buf = (char *)file_content;
        buf_len = file_size;
        while (1) {
            wlen = write(sockfd, buf, buf_len);
            if (wlen < 0) {
                goto out;
            }
            buf_len -= wlen;
            buf += wlen;
            if (buf_len == 0) {
                break;
            }
        }
    }

out:
    close(sockfd);
    return NULL;
}

int main(int argc, char *argv[]) 
{
	int             c = 0;
    int             i;
    int             thread_num = 1;
    int             fd;
    unsigned int    buf_len = 0;
    unsigned int    dip = 0;
    unsigned short  dport = 0;
    unsigned char   *buf;
    pthread_t       thread_id;
    struct stat     file_info;
    ssize_t         rlen;

	program_name = argv[0];
	program_version = "1.0";

	while((c = getopt_long(argc, argv,
					"Hj:n:q:f:",  long_opts, NULL)) != -1) {
		switch(c) {
			case 'H':
				help();
				goto out;
			case 'j':
				dip = inet_addr(optarg);
				break;
			case 'n':
				thread_num = atoi(optarg);
				break;
			case 'q':
				dport = atoi(optarg);
				break;
			case 'f':
                if (stat(optarg, &file_info) < 0) {
                    fprintf(stderr, "get %s info failed!\n", optarg);
                    return -1;
                }
                file_size = file_info.st_size;
                file_content = malloc(file_size);
                if (file_content == NULL) {
                    fprintf(stderr, "malloc %d memory failed!\n", 
                            (int)file_size);
                    return -1;
                }
                fd = open(optarg, O_RDONLY);
                if (fd < 0) {
                    fprintf(stderr, "open %s failed!\n", optarg);
                    return -1;
                }
                buf = file_content;
                buf_len = file_size;
                while (1) {
                    rlen = read(fd, buf, buf_len);
                    if (rlen <= 0) {
                        break;
                    }
                    buf += rlen;
                    buf_len -= rlen;
                }
                close(fd);
				break;
			default:
				break;
		}
	}

    if (dip == 0) {
        fprintf(stderr, "dip not configure\n");
        help();
        return -1;
    }
    if (dport == 0) {
        fprintf(stderr, "dport not configure\n");
        help();
        return -1;
    }
    if (file_content == NULL) {
        fprintf(stderr, "file not configure\n");
        help();
        return -1;
    }

    daddr.sin_family = AF_INET;
    daddr.sin_port = htons(dport);
    daddr.sin_addr.s_addr = dip;

    for (i = 0; i < thread_num; i++) {
        if (pthread_create(&thread_id, NULL,send_package, NULL) < 0) {
            fprintf(stderr, "create thread failed!\n");
            return -1;
        }
    }

    while (1) {
        sleep(100);
    }

out:
	return 0;
}

