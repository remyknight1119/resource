#ifndef __TPA_TYPES_H__
#define __TPA_TYPES_H__

//#include <linux/uio.h>

typedef unsigned short int tpa_sa_family_t;

#define __SOCKADDR_COMMON(sa_prefix) \
	    sa_family_t sa_prefix##family

/**
 * enum sock_type - Socket types
 * @SOCK_STREAM: stream (connection) socket
 * @SOCK_DGRAM: datagram (conn.less) socket
 * @SOCK_RAW: raw socket
 * @SOCK_RDM: reliably-delivered message
 * @SOCK_SEQPACKET: sequential packet socket
 * @SOCK_DCCP: Datagram Congestion Control Protocol socket
 * @SOCK_PACKET: linux specific way of getting packets at the dev level.
 *		  For writing rarp and other similar things on the user level.
 *
 * When adding some new socket type please
 * grep ARCH_HAS_SOCKET_TYPE include/asm-* /socket.h, at least MIPS
 * overrides this enum for binary compat reasons.
 */
enum tpa_sock_type {
	TPA_SOCK_STREAM	= 1,
	TPA_SOCK_DGRAM	= 2,
	TPA_SOCK_RAW	= 3,
	TPA_SOCK_PACKET	= 10,
};

enum{
	TPA_INET4 = 1,
	TPA_INET6,
	TPA_NPROTO,
};

/*
*  1003.1g requires sa_family_t and that sa_data is char.
*/

typedef struct _tpa_sockaddr {
	unsigned char   sa_len;     /* total length */
	tpa_sa_family_t sa_family;  /* address family, AF_xxx   */
	char        sa_data[14];    /* 14 bytes of protocol address */
}tpa_sockaddr;

#define TPA_SOCK_MAXADDRLEN 255

typedef struct _tpa_sockaddr_storage {
	unsigned char   sa_len;     /* total length */
	tpa_sa_family_t sa_family;  /* address family, AF_xxx   */
	char        sa_data[TPA_SOCK_MAXADDRLEN];    /* 14 bytes of protocol address */
}tpa_sockaddr_storage;


/* Internet address. */
typedef struct _tpa_in_addr {
	unsigned int	s_addr;
}tpa_in_addr ;

/* Socket address, internet style. */
typedef struct _tpa_sockaddr_in {
	unsigned char	sin_len;
	tpa_sa_family_t	sin_family;
	unsigned short	sin_port;
	tpa_in_addr sin_addr;
	char	sin_zero[8];
}tpa_sockaddr_in;

/*
 * IPv6 address
 */
typedef struct _tpa_in6_addr {
	union {
		unsigned char		__u6_addr8[16];
		unsigned short	__u6_addr16[8];
		unsigned int	__u6_addr32[4];
	} __u6_addr;			/* 128-bit IP6 address */
}tpa_in6_addr;

#define i6_addr   __u6_addr.__u6_addr8

#define i6_addr8  __u6_addr.__u6_addr8
#define i6_addr16 __u6_addr.__u6_addr16
#define i6_addr32 __u6_addr.__u6_addr32

typedef struct _tpa_sockaddr_in6 {
	unsigned char		sin6_len;	/* length of this struct */
	tpa_sa_family_t	sin6_family;	/* AF_INET6 */
	unsigned short	sin6_port;	/* Transport layer port # */
	unsigned int	sin6_flowinfo;	/* IP6 flow information */
	tpa_in6_addr	sin6_addr;	/* IP6 address */
	unsigned int	sin6_scope_id;	/* scope zone index */
}tpa_sockaddr_in6;


/*
 *	As we do 4.4BSD message passing we use a 4.4BSD message passing
 *	system, not 4.3. Thus msg_accrights(len) are now missing. They
 *	belong in an obscure libc emulation or the bin.
 */
 
struct iovec;

typedef struct _tpa_msghdr {
	void	*	msg_name;	/* Socket name			*/
	int		msg_namelen;	/* Length of name		*/
	struct iovec *	msg_iov;	/* Data blocks			*/
	unsigned long	msg_iovlen;	/* Number of blocks		*/
	void 	*	msg_control;	/* Per protocol magic (eg BSD file descriptor passing) */
	unsigned long	msg_controllen;	/* Length of cmsg list */
	unsigned	msg_flags;
}tpa_msghdr;

#endif
