#ifndef __TPA_API_H__
#define __TPA_API_H__

typedef unsigned int  tpa_socklen_t;

extern int tpa_api_init(void);
extern int tpa_api_exit(void);
extern int tpa_socket(int domain, int type, int protocol);
extern int tpa_bind(int sockfd, const tpa_sockaddr *myaddr, tpa_socklen_t addrlen);
extern int tpa_listen(int sockfd, int backlog);
extern int tpa_accept(int sockfd, const tpa_sockaddr *myaddr, tpa_socklen_t *addrlen);
extern int tpa_connect(int sockfd, const tpa_sockaddr *addr, tpa_socklen_t addrlen);
extern int tpa_getsockopt(int sockfd, int level, int optname,
		                      void *optval, tpa_socklen_t *optlen);
extern int tpa_setsockopt(int sockfd, int level,int  optname,
			                  const void *optval, tpa_socklen_t optlen);
extern ssize_t tpa_recv(int sockfd, void *buf, size_t len, int flags);
extern ssize_t tpa_recvmsg(int sockfd, tpa_msghdr *msg, int flags);
extern ssize_t tpa_send(int sockfd, const void *buf, size_t len, int flags);
extern ssize_t tpa_sendmsg(unsigned int sockfd, const tpa_msghdr *msg, unsigned int flags);
extern int tpa_shuntdown(unsigned int sockfd, unsigned int how);
extern int tpa_close(int sockfd);

#endif
