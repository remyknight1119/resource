#ifndef __TPA_QUEUE_H__
#define __TPA_QUEUE_H__

/*
 * Tail queue declarations.
 */
#define	TPA_TAILQ_HEAD(name, type)						\
struct name {								\
	struct type *tqh_first;	/* first element */			\
	struct type **tqh_last;	/* addr of last next element */		\
}

#define	TPA_TAILQ_HEAD_INITIALIZER(head)					\
	{ NULL, &(head).tqh_first }

#define	TPA_TAILQ_ENTRY(type)						\
struct {								\
	struct type *tqe_next;	/* next element */			\
	struct type **tqe_prev;	/* address of previous next element */	\
}

#define	TPA_TAILQ_EMPTY(head)	((head)->tqh_first == NULL)

#define	TPA_TAILQ_FIRST(head)	((head)->tqh_first)

#define	TPA_TAILQ_LAST(head, headname)					\
	(*(((struct headname *)((head)->tqh_last))->tqh_last))

#define	TPA_TAILQ_NEXT(elm, field) ((elm)->field.tqe_next)

#define	TPA_TAILQ_PREV(elm, headname, field)				\
	(*(((struct headname *)((elm)->field.tqe_prev))->tqh_last))


#define	TPA_TAILQ_FOREACH(var, head, field)					\
	for ((var) = TPA_TAILQ_FIRST((head));				\
	    (var);							\
	    (var) = TPA_TAILQ_NEXT((var), field))

#define	TPA_TAILQ_FOREACH_SAFE(var, head, field, tvar)			\
	for ((var) = TPA_TAILQ_FIRST((head));				\
	    (var) && ((tvar) = TPA_TAILQ_NEXT((var), field), 1);		\
	    (var) = (tvar))

#define	TPA_TAILQ_FOREACH_REVERSE(var, head, headname, field)		\
	for ((var) = TPA_TAILQ_LAST((head), headname);			\
	    (var);							\
	    (var) = TPA_TAILQ_PREV((var), headname, field))

#define	TPA_TAILQ_FOREACH_REVERSE_SAFE(var, head, headname, field, tvar)	\
	for ((var) = TPA_TAILQ_LAST((head), headname);			\
	    (var) && ((tvar) = TPA_TAILQ_PREV((var), headname, field), 1);	\
	    (var) = (tvar))

#define	TPA_TAILQ_INIT(head) do {						\
	TPA_TAILQ_FIRST((head)) = NULL;					\
	(head)->tqh_last = &TPA_TAILQ_FIRST((head));			\
} while (0)

#define	TPA_LIST_HEAD(name, type)						\
typedef struct _##name {								\
	struct type *lh_first;	/* first element */			\
}name

#define	TPA_LIST_HEAD_INITIALIZER(head)					\
	{ NULL }

#define	TPA_LIST_ENTRY(type)						\
struct {								\
	struct type *le_next;	/* next element */			\
	struct type **le_prev;	/* address of previous next element */	\
}

#define	TPA_LIST_EMPTY(head)	((head)->lh_first == NULL)
#define	TPA_LIST_FIRST(head)	((head)->lh_first)
#define	TPA_LIST_NEXT(elm, field)	((elm)->field.le_next)

#define TPA_LIST_INIT(head) do {                        \
	TPA_LIST_FIRST((head)) = NULL;                  \
} while (0)

#define	TPA_LIST_FOREACH(var, head, field)					\
	for ((var) = TPA_LIST_FIRST((head));				\
	    (var);							\
	    (var) = TPA_LIST_NEXT((var), field))


#define	QMD_LIST_CHECK_HEAD(head, field) do {				\
	if (TPA_LIST_FIRST((head)) != NULL &&				\
	    TPA_LIST_FIRST((head))->field.le_prev !=			\
	     &TPA_LIST_FIRST((head)))					\
		panic("Bad list head %p first->prev != head", (head));	\
} while (0)

#define	QMD_LIST_CHECK_NEXT(elm, field) do {				\
	if (TPA_LIST_NEXT((elm), field) != NULL &&				\
	    TPA_LIST_NEXT((elm), field)->field.le_prev !=			\
	     &((elm)->field.le_next))					\
	     	panic("Bad link elm %p next->prev != elm", (elm));	\
} while (0)

#define	QMD_LIST_CHECK_PREV(elm, field) do {				\
	if (*(elm)->field.le_prev != (elm))				\
		panic("Bad link elm %p prev->next != elm", (elm));	\
} while (0)

#define	TPA_LIST_NEXT(elm, field)	((elm)->field.le_next)

#define	TPA_LIST_INSERT_HEAD(head, elm, field) do {				\
	QMD_LIST_CHECK_HEAD((head), field);				\
	if ((TPA_LIST_NEXT((elm), field) = TPA_LIST_FIRST((head))) != NULL)	\
		TPA_LIST_FIRST((head))->field.le_prev = &TPA_LIST_NEXT((elm), field);\
	TPA_LIST_FIRST((head)) = (elm);					\
	(elm)->field.le_prev = &TPA_LIST_FIRST((head));			\
} while (0)

#define	TPA_LIST_NEXT(elm, field)	((elm)->field.le_next)

#define	TPA_LIST_REMOVE(elm, field) do {					\
	QMD_LIST_CHECK_NEXT(elm, field);				\
	QMD_LIST_CHECK_PREV(elm, field);				\
	if (TPA_LIST_NEXT((elm), field) != NULL)				\
		TPA_LIST_NEXT((elm), field)->field.le_prev = 		\
		    (elm)->field.le_prev;				\
	*(elm)->field.le_prev = TPA_LIST_NEXT((elm), field);		\
} while (0)

/*
 * Singly-linked List declarations.
 */
#define	TPA_SLIST_HEAD(name, type)						\
struct name {								\
	struct type *slh_first;	/* first element */			\
}

#define	TPA_SLIST_HEAD_INITIALIZER(head)					\
	{ NULL }

#define	TPA_SLIST_ENTRY(type)						\
struct {								\
	struct type *sle_next;	/* next element */			\
}

/*
 * Singly-linked List functions.
 */
#define	TPA_SLIST_EMPTY(head)	((head)->slh_first == NULL)

#define	TPA_SLIST_FIRST(head)	((head)->slh_first)

#define	TPA_SLIST_INIT(head) do {						\
	TPA_SLIST_FIRST((head)) = NULL;					\
} while (0)


#endif
