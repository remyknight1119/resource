#ifndef __TPA_COMM_H__
#define __TPA_COMM_H__

#define TPA_SYS_START 500
#define tpa_current_tick (ulong)(jiffies)

static inline int tpa_imax(int a, int b) { return (a > b ? a : b); }
static inline int tpa_imin(int a, int b) { return (a < b ? a : b); }
static inline long tpa_lmax(long a, long b) { return (a > b ? a : b); }
static inline long tpa_lmin(long a, long b) { return (a < b ? a : b); }

static inline void bcopy(const void *src0, void *dst0, size_t length)
{
	memcpy(dst0, src0, length);
}

enum {
	TPA_SYS_SOCKET = TPA_SYS_START,
	TPA_SYS_BIND,
	TPA_SYS_CONNECT,
	TPA_SYS_LISTEN,
	TPA_SYS_ACCEPT,
	TPA_SYS_SEND,
	TPA_SYS_RECV,
	TPA_SYS_SHUTDOWN,
	TPA_SYS_SETSOCKOPT,
	TPA_SYS_GETSOCKOPT,
	TPA_SYS_SENDMSG,
	TPA_SYS_RECVMSG,
	TPA_SYS_DEBUG,
	TPA_SYS_MAX, 
};

#endif
