#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/poll.h>
//#include <linux/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../include/tpa_types.h"
#include "../include/tpa_api.h"

#define TPA_LISTEN_BACKLOG	1000
#define CLIENT_MAX	100

static const char *program_name;
static const char *program_version;

static const struct option long_opts[] = {
	{"help", 0, 0, 'H'},
	{"debug", 1, 0, 'D'},
	{"lip", 1, 0, 'l'},
	{"port", 1, 0, 'p'},
	{"protocol", 1, 0, 'r'},
	{0, 0, 0, 0},
};

static const char *options[] = {
	"--debug		-D  for start debug print\n",
	"--lip			-l  ip address to be listen\n",
	"--port		-p  dest port to be listen\n",
	"--protocol		-r  network protocol(4 for IPv4, 6 for IPv6))\n",
	"--help		-H  Print help information\n",
};
	
static void help()
{
	int i;

	fprintf(stdout, "Version: %s\n", program_version);
	
	fprintf(stdout, "\nOptions:\n");
	for(i = 0; i < sizeof(options)/sizeof(char *); i ++) {
		fprintf(stdout, "  %s", options[i]);
	}
		
	return;
}

int main(int argc, char *argv[]) 
{
	int fd = 0;
	int c = 0;
	int nready = 0;
	int poll_index = 0;
	int net_proto = 0;
	int err = 0;
//	char saddr[128] = {};
//	char daddr[128] = {};
	char laddr[128] = {};
	unsigned int listen_addr = 0;
	unsigned short listen_port = 0;
//	unsigned int cmd = 0;
	tpa_sockaddr_in addr4;
	tpa_sockaddr_in6 addr6;
	struct pollfd client[CLIENT_MAX];

	program_name = argv[0];
	program_version = "1.0";

	while((c = getopt_long(argc, argv,
					"Hi:j:o:r:l:p:",  long_opts, NULL)) != -1) {
		switch(c) {
			case 'H':
				help();
				goto out;
			case 'i':
//				strncpy(saddr, optarg, 128);
//				dm.saddr = inet_addr(saddr);
				break;

			case 'j':
//				strncpy(daddr, optarg, 128);
//				dm.daddr = inet_addr(daddr);
				break;

			case 'o':
//				dm.sport = atoi(optarg);
				break;

			case 'r':
				net_proto = atoi(optarg);
				break;
			case 'l':
				strncpy(laddr, optarg, 128);
				listen_addr = inet_addr(laddr);
				break;
			case 'p':
				listen_port = atoi(optarg);
				break;
			default:
				break;
		}
	}

	printf("tpa_socket!\n");
	if (net_proto == 4){
		fd = tpa_socket(TPA_INET4,TPA_SOCK_STREAM,IPPROTO_TCP);
		if(fd < 0){
			printf("tpa socket failed!\n");
			goto out;
		}

		printf("fd = %d, listen port = %d!\n",fd,listen_port);

		addr4.sin_family = TPA_INET4;
		addr4.sin_port = htons(listen_port);
		addr4.sin_addr.s_addr = listen_addr;

		err = tpa_bind(fd, (tpa_sockaddr *)&addr4, sizeof(addr4));
		if(err < 0){
			printf("tpa socket bind failed!\n");
			goto err;
		}
	}else if (net_proto == 6){
		fd = tpa_socket(TPA_INET6,TPA_SOCK_STREAM,IPPROTO_TCP);
		if(fd < 0){
			printf("tpa socket4 failed!\n");
			goto err;
		}

		memset(&addr6, 0, sizeof(addr6));
		addr6.sin6_family = TPA_INET6;
		addr6.sin6_port = listen_port;

		err = tpa_bind(fd, (tpa_sockaddr *)&addr6, sizeof(addr6));
		if(err < 0){
			printf("tpa socket6 bind failed!\n");
			goto exit;
		}
	}

	err = tpa_listen(fd, TPA_LISTEN_BACKLOG);
	if(err < 0){
		printf("tpa socket listen failed!\n");
		goto err;
	}

	client[0].fd = fd;
	client[0].events = POLLIN;
	client[0].revents = 0;

	for (poll_index = 1; poll_index < CLIENT_MAX; poll_index++) {
		client[poll_index].fd = -1;
	}
	
	while(1){
		printf("Before poll!\n");
		nready = poll(client, CLIENT_MAX, -1);
		printf("After poll!\n");
		if(nready < 0){
			printf("Poll error!ret = %d\n",nready);
		}

		if (nready == 0) {
			printf("poll timeout !\n");
			goto exit;
		}
	}

exit:
err:
	close(fd);
out:
	return 0;
}

