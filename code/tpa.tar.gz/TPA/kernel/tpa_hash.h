#ifndef __TPA_HASH_H__
#define __TPA_HASH_H__


void *tpa_hashinit(int elements, gfp_t flags, ulong *hashmask);

#endif
