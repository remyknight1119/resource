/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_debug.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-03-21
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/
#include <linux/types.h>

u8 tpa_debug_on = 1;

