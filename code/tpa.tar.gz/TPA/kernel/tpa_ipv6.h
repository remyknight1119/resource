#ifndef __TPA_IPV6_H__
#define __TPA_IPV6_H__

#include <linux/ipv6.h>
#include "../include/tpa_types.h"


extern int tpa_ipv6_input(struct sk_buff *skb);
extern int tpa_ipv6_init(void);
extern void tpa_ipv6_exit(void);

#endif
