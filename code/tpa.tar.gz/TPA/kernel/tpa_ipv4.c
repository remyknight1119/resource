/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_ipv4.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-05
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/in.h>
#include <net/ip.h>

#include "tpa_protosw.h"
#include "tpa_domain.h"
#include "tpa_socket.h"
#include "tpa_ipv4.h"
#include "tcp.h"
#include "tpa_debug.h"

static tpa_protosw *tpa_ipv4_proto[IPPROTO_MAX] = {};
static tpa_domain tpa_inet4domain;

static tpa_protosw tpa_inet4sw[] = {
	{
		.pr_domain = 	&tpa_inet4domain,
		.pr_type =		TPA_SOCK_STREAM,
		.pr_protocol =		IPPROTO_TCP,
//		.pr_flags =		PR_CONNREQUIRED|PR_WANTRCVD|PR_LISTEN,
		.pr_input =		tcp4_input,
		.pr_ctlinput =		tcp_ctlinput,
		.pr_ctloutput =		tcp_ctloutput,
		.pr_init =		tcp_init,
		.pr_destroy =		tcp_destroy,
		.pr_drain =		tcp_drain,
		.pr_usrreqs =		&tcp_usrreqs,
	},
};

static tpa_domain tpa_inet4domain = {
	.dom_family =		TPA_INET4,
	.dom_protosw =		(tpa_protosw *)tpa_inet4sw,
	.dom_protosw_last =	(tpa_protosw *)
				&tpa_inet4sw[sizeof(tpa_inet4sw)/sizeof(tpa_inet4sw[0])],
};

int 
tpa_ipv4_input(struct sk_buff *skb)
{
	struct iphdr *iph = NULL;
	tpa_protosw *proto = NULL;
	int hlen = 0;
	int tlen = 0;
	int ret = 0;
	
	TPA_DEBUG("=======Enter=======\n");

	iph = ip_hdr(skb);
	proto = tpa_ipv4_proto[iph->protocol];
	if (proto == NULL){
		return -1;
	}

	hlen = ip_hdrlen(skb);
	__skb_pull(skb, hlen);
	skb_reset_transport_header(skb);
	
	tlen = ntohs(iph->tot_len);

	ret = proto->pr_input(skb, tlen);
	if (ret < 0){
		__skb_push(skb, hlen);
		skb_reset_transport_header(skb);
	}

	return ret;
}

int 
tpa_ipv4_init(void)
{
	tpa_protosw *pr;

	if(tpa_add_domain(&tpa_inet4domain)){
		return -1;
	}

	for (pr = tpa_inet4domain.dom_protosw; pr < tpa_inet4domain.dom_protosw_last; pr++) {
		if (pr->pr_protocol >= IPPROTO_MAX){
			continue;
		}

		tpa_ipv4_proto[pr->pr_protocol] = pr;
		if (pr->pr_init){
			if(pr->pr_init()){
				return -1;
			}
		}
	}

	return 0;
}

void 
tpa_ipv4_exit(void)
{
	tpa_protosw *pr;

	for (pr = tpa_inet4domain.dom_protosw; pr < tpa_inet4domain.dom_protosw_last; pr++) {
		if (pr->pr_protocol >= IPPROTO_MAX){
			continue;
		}

		if (pr->pr_destroy){
			pr->pr_destroy();
		}
	}

	tpa_del_domain(&tpa_inet4domain);
}

