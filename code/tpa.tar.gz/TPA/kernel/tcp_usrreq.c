/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_inet4.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-05
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include "tpa_protosw.h"
#include "tpa_socket.h"
#include "tpa_inpcb.h"
#include "tpa_in6_pcb.h"
#include "tpa_in.h"
#include "tpa_in6.h"
#include "tpa_debug.h"
#include "tcpcb.h"
#include "tcp.h"
#include "tcp_timer.h"
#include "tcp_fsm.h"
#include "tcp_seq.h"

ulong tpa_sb_max = 0;

/*
 * Attach TCP protocol to socket, allocating
 * internet protocol control block, tcp control block,
 * bufer space, and entering LISTEN state if to accept connections.
 */
static int
tcp_attach(tpa_socket *so)
{
	tpa_tcpcb *tp;
	tpa_inpcb *inp;
	int error;

	error = tpa_in_pcballoc(so, &tcbinfo);
	if (error) {
		return error;
	}

	inp = tpa_sotoinpcb(so);
	tp = tcp_newtcpcb(inp);
	if (tp == NULL) {
		tpa_in_pcbdetach(inp);
		tpa_in_pcbfree(inp);
		return -1;
	}

	tp->t_state = TCPS_CLOSED;
	tcp_init_timers(so);
	TPA_INP_WUNLOCK_BH(inp);

	return 0;
}

/*
 * Give the socket an address.
 */
static int
tcp_usr_bind(tpa_socket *so, tpa_sockaddr *nam)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;
	tpa_sockaddr_in *sinp;

	sinp = (tpa_sockaddr_in *)nam;
	if (nam->sa_len != sizeof (*sinp)){
		return -1;
	}
	/*
	 * Must check for multicast addresses and disallow binding
	 * to them.
	 */
	if (sinp->sin_family == TPA_INET4 &&
	    TPA_IN_MULTICAST(ntohl(sinp->sin_addr.s_addr))){
		return -1;
	}

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	TPA_INP_WLOCK_BH(inp);

	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}

	inp->inp_vflag |= TPA_INP_IPV4;
	tp = tpa_intotcpcb(inp);
	error = tpa_in_pcbbind(inp, nam);
out:
	TPA_INP_WUNLOCK_BH(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);

	return (error);
}

static int
tcp6_usr_bind(tpa_socket *so, tpa_sockaddr *nam)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;
	tpa_sockaddr_in6 *sin6p;

	sin6p = (tpa_sockaddr_in6 *)nam;
	if (nam->sa_len != sizeof (*sin6p)){
		TPA_DEBUG("Sa_len error!\n");
		return -1;
	}
	/*
	 * Must check for multicast addresses and disallow binding
	 * to them.
	 */
	if (sin6p->sin6_family == TPA_INET6 &&
	    TPA_IN6_IS_ADDR_MULTICAST(&sin6p->sin6_addr)){
		TPA_DEBUG("Family and addr error!\n");
		return -1;
	}

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	TPA_INP_WLOCK_BH(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		TPA_DEBUG("State error!\n");
		goto out;
	}
	tp = tpa_intotcpcb(inp);
	inp->inp_vflag &= ~TPA_INP_IPV4;
	inp->inp_vflag |= TPA_INP_IPV6;
	if ((inp->inp_flags & TPA_IN6P_IPV6_V6ONLY) == 0) {
		if (TPA_IN6_IS_ADDR_UNSPECIFIED(&sin6p->sin6_addr)){
			inp->inp_vflag |= TPA_INP_IPV4;
		}else if (TPA_IN6_IS_ADDR_V4MAPPED(&sin6p->sin6_addr)) {
			tpa_sockaddr_in sin;

			tpa_in6_sin6_2_sin(&sin, sin6p);
			inp->inp_vflag |= TPA_INP_IPV4;
			inp->inp_vflag &= ~TPA_INP_IPV6;
			error = tpa_in_pcbbind(inp, (tpa_sockaddr *)&sin);
			TPA_DEBUG("in pcbbind  error!\n");
			goto out;
		}
	}
	error = tpa_in6_pcbbind(inp, nam);
out:
	TPA_INP_WUNLOCK_BH(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return (error);
}

/*
 * Prepare to accept connections.
 */
static int
tcp_usr_listen(tpa_socket *so, int backlog)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;

	TPA_DEBUG("=======Enter=======\n");
	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	
	TPA_INP_WLOCK_BH(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}
	tp = tpa_intotcpcb(inp);
	TPA_SOCK_LOCK_BH(so);
	error = tpa_solisten_proto_check(so);
	if (error == 0 && inp->inp_lport == 0){
		error = tpa_in_pcbbind(inp, (tpa_sockaddr *)0);
	}
	if (error == 0) {
		tp->t_state = TCPS_LISTEN;
		tpa_solisten_proto(so, backlog);
	}
	TPA_SOCK_UNLOCK_BH(so);

out:
	TPA_INP_WUNLOCK_BH(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	TPA_DEBUG("=======Leave=======\n");
	return (error);
}

static int
tcp6_usr_listen(tpa_socket *so, int backlog)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);

	TPA_INP_WLOCK_BH(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}
	tp = tpa_intotcpcb(inp);

	TPA_SOCK_LOCK_BH(so);
	error = tpa_solisten_proto_check(so);
	if (error == 0 && inp->inp_lport == 0) {
		inp->inp_vflag &= ~TPA_INP_IPV4;
		if ((inp->inp_flags & TPA_IN6P_IPV6_V6ONLY) == 0){
			inp->inp_vflag |= TPA_INP_IPV4;
		}
		error = tpa_in6_pcbbind(inp, (tpa_sockaddr *)0);
	}
	if (error == 0) {
		tp->t_state = TCPS_LISTEN;
		tpa_solisten_proto(so, backlog);
	}
	TPA_SOCK_UNLOCK_BH(so);

out:
	TPA_INP_WUNLOCK_BH(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return (error);
}

/*
 *	Wait for a TCP event.
 *
 *	Note that we don't need to lock the socket, as the upper poll layers
 *	take care of normal races (between the test and the event) and we don't
 *	go look at any of the socket buffers directly.
 */
static u32 
tcp_poll(struct file *file, tpa_socket *so, poll_table *wait)
{
	u32 mask = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;

	TPA_DEBUG("=======Enter=======\n");

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);

	TPA_INP_WLOCK_BH(inp);
	tp = tpa_intotcpcb(inp);

	tpa_sock_poll_wait(file, &so->so_wait, wait);
	if(tp->t_state == TCPS_LISTEN){
		mask = tpa_sk_listen_poll(so);
		goto out;
	}

	/* Socket is not locked. We are protected from async events
	 * by poll logic and correct handling of state changes
	 * made by other threads is impossible in any case.
	 */

	mask = 0;
	if (so->so_error){
		mask = POLLERR;
	}

	if (tpa_soreadabledata(so)){
		mask |= (POLLIN | POLLRDNORM);
	}

	if (tpa_sowriteable(so)){
		mask |= (POLLOUT | POLLWRNORM);
	}

out:
	TPA_INP_WUNLOCK_BH(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return mask;
}

/*
 * TCP attaches to socket via pru_attach(), reserving space,
 * and an internet control block.
 */
static int
tcp_usr_attach(tpa_socket *so, int proto)
{
	tpa_inpcb *inp;

	inp = tpa_sotoinpcb(so);
	if(inp != NULL){
		return -1;
	}

	return tcp_attach(so);
}

/*
 * Common subroutine to open a TCP connection to remote host specified
 * by struct sockaddr_in in mbuf *nam.  Call in_pcbbind to assign a local
 * port number if needed.  Call in_pcbconnect_setup to do the routing and
 * to choose a local host address (interface).  If there is an existing
 * incarnation of the same connection in TIME-WAIT state and if the remote
 * host was sending CC options and if the connection duration was < MSL, then
 * truncate the previous TIME-WAIT state and proceed.
 * Initialize connection parameters and enter SYN-SENT state.
 */
static int
tcp_connect(tpa_tcpcb *tp, tpa_sockaddr *nam)
{
	tpa_inpcb *inp = tp->t_inpcb;
	tpa_inpcb *oinp;
	tpa_socket *so = inp->inp_socket;
	tpa_in_addr laddr;
	u16 lport;
	int error;

	if (inp->inp_lport == 0) {
		error = tpa_in_pcbbind(inp, (tpa_sockaddr *)0);
		if (error){
			return error;
		}
	}

	/*
	 * Cannot simply call in_pcbconnect, because there might be an
	 * earlier incarnation of this same connection still in
	 * TIME_WAIT state, creating an ADDRINUSE error.
	 */
	laddr = inp->inp_laddr;
	lport = inp->inp_lport;

	error = tpa_in_pcbconnect_setup(inp, nam, &laddr.s_addr, &lport,
	    &inp->inp_faddr.s_addr, &inp->inp_fport, &oinp);
	if (error && oinp == NULL){
		return error;
	}
	if (oinp){
		return -1;
	}
	inp->inp_laddr = laddr;
	tpa_in_pcbrehash(inp);

	/*
	 * Compute window scaling to request:
	 * Scale to fit into sweet spot.  See tcp_syncache.c.
	 * XXX: This should move to tcp_output().
	 */
	while (tp->request_r_scale < TCP_MAX_WINSHIFT &&
	    (TCP_MAXWIN << tp->request_r_scale) < tpa_sb_max){
		tp->request_r_scale++;
	}

	tpa_soisconnecting(so);
	tp->t_state = TCPS_SYN_SENT;
	tcp_timer_activate(tp, TT_KEEP, tcp_keepinit);
	tp->iss = tcp_new_isn(tp);
	tp->t_bw_rtseq = tp->iss;
	tcp_sendseqinit(tp);

	return 0;
}

static int
tcp6_connect(tpa_tcpcb *tp, tpa_sockaddr *nam)
{
	tpa_inpcb *inp = tp->t_inpcb, *oinp;
	tpa_socket *so = inp->inp_socket;
	tpa_sockaddr_in6 *sin6 = (tpa_sockaddr_in6 *)nam;
	tpa_in6_addr addr6;
	int error;

	if (inp->inp_lport == 0) {
		error = tpa_in6_pcbbind(inp, (tpa_sockaddr *)0);
		if (error){
			return error;
		}
	}

	oinp = tpa_in6_pcblookup_hash(inp->inp_pcbinfo,
				  &sin6->sin6_addr, sin6->sin6_port,
				  TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_laddr)
				  ? &addr6 : &inp->in6p_laddr,
				  inp->inp_lport, 0);
	if (oinp){
		return -1;
	}
	if (TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_laddr)){
		inp->in6p_laddr = addr6;
	}
	inp->in6p_faddr = sin6->sin6_addr;
	inp->inp_fport = sin6->sin6_port;
	/* update flowinfo - draft-itojun-ipv6-flowlabel-api-00 */
#if 0
	inp->inp_flow &= ~IPV6_FLOWLABEL_MASK;
	if (inp->inp_flags & IN6P_AUTOFLOWLABEL){
		inp->inp_flow |=
		    (htonl(ip6_randomflowlabel()) & IPV6_FLOWLABEL_MASK);
	}
#endif
	tpa_in_pcbrehash(inp);

	/* Compute window scaling to request.  */
	while (tp->request_r_scale < TCP_MAX_WINSHIFT &&
	    (TCP_MAXWIN << tp->request_r_scale) < tpa_sb_max){
		tp->request_r_scale++;
	}

	tpa_soisconnecting(so);
	tp->t_state = TCPS_SYN_SENT;
	tcp_timer_activate(tp, TT_KEEP, tcp_keepinit);
	tp->iss = tcp_new_isn(tp);
	tp->t_bw_rtseq = tp->iss;
	tcp_sendseqinit(tp);

	return 0;
}

/*
 * Initiate connection to peer.
 * Create a template for use in transmissions on this connection.
 * Enter SYN_SENT state, and mark socket as connecting.
 * Start keep-alive timer, and seed output sequence space.
 * Send initial segment on connection.
 */
static int
tcp_usr_connect(tpa_socket *so, tpa_sockaddr *nam)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;
	tpa_sockaddr_in *sinp;

	sinp = (tpa_sockaddr_in *)nam;
	if (nam->sa_len != sizeof (*sinp)){
		return -1;
	}
	/*
	 * Must disallow TCP ``connections'' to multicast addresses.
	 */
	if (sinp->sin_family == TPA_INET4
	    && TPA_IN_MULTICAST(ntohl(sinp->sin_addr.s_addr))){
		return -1;
	}

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	
	TPA_INP_WLOCK(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}
	tp = tpa_intotcpcb(inp);
	if ((error = tcp_connect(tp, nam)) != 0){
		goto out;
	}
	error = tcp_output_connect(so);
out:
	TPA_INP_WUNLOCK(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return (error);
}

static int
tcp6_usr_connect(tpa_socket *so, tpa_sockaddr *nam)
{
	int error = 0;
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;
	tpa_sockaddr_in6 *sin6p;

	sin6p = (tpa_sockaddr_in6 *)nam;
	if (nam->sa_len != sizeof (*sin6p)){
		return -1;
	}
	/*
	 * Must disallow TCP ``connections'' to multicast addresses.
	 */
	if (sin6p->sin6_family == TPA_INET6
	    && TPA_IN6_IS_ADDR_MULTICAST(&sin6p->sin6_addr)){
		return -1;
	}

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	
	TPA_INP_WLOCK(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}
	tp = tpa_intotcpcb(inp);
	
#if 0
	if (TPA_IN6_IS_ADDR_V4MAPPED(&sin6p->sin6_addr)) {
		tpa_sockaddr_in sin;

		if ((inp->inp_flags & TPA_IN6P_IPV6_V6ONLY) != 0) {
			error = -1;
			goto out;
		}

		in6_sin6_2_sin(&sin, sin6p);
		inp->inp_vflag |= INP_IPV4;
		inp->inp_vflag &= ~INP_IPV6;
		if ((error = prison_remote_ip4(td->td_ucred,
		    &sin.sin_addr)) != 0)
			goto out;
		if ((error = tcp_connect(tp, (tpa_sockaddr *)&sin, td)) != 0)
			goto out;
		error = tcp_output_connect(so);
		goto out;
	}
#endif
	inp->inp_vflag &= ~TPA_INP_IPV4;
	inp->inp_vflag |= TPA_INP_IPV6;
#if 0
	inp->inp_inc.inc_flags |= INC_ISIPV6;
	if ((error = prison_remote_ip6(td->td_ucred, &sin6p->sin6_addr)) != 0)
		goto out;
#endif
	if ((error = tcp6_connect(tp, nam)) != 0){
		goto out;
	}
	error = tcp_output_connect(so);

out:
	TPA_INP_WUNLOCK(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return (error);
}

/*
 * Initiate (or continue) disconnect.
 * If embryonic state, just send reset (once).
 * If in ``let data drain'' option and linger null, just drop.
 * Otherwise (hard), mark socket disconnecting and drop
 * current input data; switch states based on user close, and
 * send segment to peer (with FIN).
 */
static void
tcp_disconnect(tpa_tcpcb *tp)
{
#if 0
	tpa_inpcb *inp = tp->t_inpcb;
	tpa_socket *so = inp->inp_socket;

	/*
	 * Neither tcp_close() nor tcp_drop() should return NULL, as the
	 * socket is still open.
	 */
	if (tp->t_state < TCPS_ESTABLISHED) {
		tp = tcp_close(tp);
	} else if ((so->so_options & SO_LINGER) && so->so_linger == 0) {
		tp = tcp_drop(tp, 0);
	} else {
		soisdisconnecting(so);
		sbflush(&so->so_rcv);
		tcp_usrclosed(tp);
		if (!(inp->inp_flags & INP_DROPPED))
			tcp_output_disconnect(tp);
	}
#endif
}

/*
 * Initiate disconnect from peer.
 * If connection never passed embryonic stage, just drop;
 * else if don't need to let data drain, then can just drop anyways,
 * else have to begin TCP shutdown process: mark socket disconnecting,
 * drain unread data, state switch to reflect user close, and
 * send segment (e.g. FIN) to peer.  Socket will be really disconnected
 * when peer sends FIN and acks ours.
 *
 * SHOULD IMPLEMENT LATER PRU_CONNECT VIA REALLOC TCPCB.
 */
static int
tcp_usr_disconnect(tpa_socket *so)
{
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;
	int error = 0;

	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	inp = tpa_sotoinpcb(so);
	
	TPA_INP_WLOCK(inp);
	if (inp->inp_flags & (TPA_INP_TIMEWAIT | TPA_INP_DROPPED)) {
		error = -1;
		goto out;
	}
	tp = tpa_intotcpcb(inp);
	tcp_disconnect(tp);
out:
	TPA_INP_WUNLOCK(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	return (error);
}

/*
 * tcp_detach is called when the socket layer loses its final reference
 * to the socket, be it a file descriptor reference, a reference from TCP,
 * etc.  At this point, there is only one case in which we will keep around
 * inpcb state: time wait.
 *
 * This function can probably be re-absorbed back into tcp_usr_detach() now
 * that there is a single detach path.
 */
static void
tcp_detach(tpa_socket *so, tpa_inpcb *inp)
{
	tpa_tcpcb *tp;

	tp = tpa_intotcpcb(inp);

#if 0
	if (inp->inp_flags & INP_TIMEWAIT) {
		/*
		 * There are two cases to handle: one in which the time wait
		 * state is being discarded (INP_DROPPED), and one in which
		 * this connection will remain in timewait.  In the former,
		 * it is time to discard all state (except tcptw, which has
		 * already been discarded by the timewait close code, which
		 * should be further up the call stack somewhere).  In the
		 * latter case, we detach from the socket, but leave the pcb
		 * present until timewait ends.
		 *
		 * XXXRW: Would it be cleaner to free the tcptw here?
		 */
		if (inp->inp_flags & INP_DROPPED) {
			KASSERT(tp == NULL, ("tcp_detach: INP_TIMEWAIT && "
			    "INP_DROPPED && tp != NULL"));
			in_pcbdetach(inp);
			in_pcbfree(inp);
		} else {
			in_pcbdetach(inp);
			INP_WUNLOCK(inp);
		}
	} else {
		/*
		 * If the connection is not in timewait, we consider two
		 * two conditions: one in which no further processing is
		 * necessary (dropped || embryonic), and one in which TCP is
		 * not yet done, but no longer requires the socket, so the
		 * pcb will persist for the time being.
		 *
		 * XXXRW: Does the second case still occur?
		 */
		if (inp->inp_flags & INP_DROPPED ||
		    tp->t_state < TCPS_SYN_SENT) {
#endif
			tcp_discardcb(tp);
			tpa_in_pcbdetach(inp);
			tpa_in_pcbfree(inp);
#if 0
		} else
			in_pcbdetach(inp);
	}
#endif
}

/*
 * pru_detach() detaches the TCP protocol from the socket.
 * If the protocol state is non-embryonic, then can't
 * do this directly: have to initiate a pru_disconnect(),
 * which may finish later; embryonic TCB's can just
 * be discarded here.
 */
static void
tcp_usr_detach(tpa_socket *so)
{
	tpa_inpcb *inp;

	inp = tpa_sotoinpcb(so);
	TPA_INP_INFO_WLOCK_BH(&tcbinfo);
	TPA_INP_WLOCK(inp);
	tcp_detach(so, inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
}

/*
 * TCP socket is closed.  Start friendly disconnect.
 */
static void
tcp_usr_close(tpa_socket *so)
{
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;

	TPA_DEBUG("=======Enter=======\n");

	inp = tpa_sotoinpcb(so);

	/*
	 * If we still have full TCP state, and we're not dropped, initiate
	 * a disconnect.
	 */
#if 0
	if (!(inp->inp_flags & INP_TIMEWAIT) &&
	    !(inp->inp_flags & INP_DROPPED)) {
#endif
		tp = tpa_intotcpcb(inp);
#if 0
		tcp_disconnect(tp);
	}
	if (!(inp->inp_flags & INP_DROPPED)) {
		SOCK_LOCK(so);
		so->so_state |= SS_PROTOREF;
		SOCK_UNLOCK(so);
		inp->inp_flags |= INP_SOCKREF;
	}
#endif
	TPA_INP_WUNLOCK(inp);
	TPA_INP_INFO_WUNLOCK_BH(&tcbinfo);
	TPA_DEBUG("=======Leave=======\n");
}


int 
tcp_ctloutput(tpa_socket *so, struct _tpa_sockopt *sopt)
{
	return 0;
}

void
tcp_ctlinput(int cmd, tpa_sockaddr *sa, void *vip)
{
}

void
tcp6_ctlinput(int cmd, tpa_sockaddr *sa, void *vip)
{
}


tpa_pr_usrreqs tcp_usrreqs = {
//	.pru_abort =		tcp_usr_abort,
//	.pru_accept =		tcp_usr_accept,
	.pru_attach =		tcp_usr_attach,
	.pru_bind =		tcp_usr_bind,
	.pru_connect =		tcp_usr_connect,
//	.pru_control =		in_control,
	.pru_detach =		tcp_usr_detach,
	.pru_disconnect =	tcp_usr_disconnect,
	.pru_listen =		tcp_usr_listen,
	.pru_sopoll = 		tcp_poll,
//	.pru_rcvd =		tcp_usr_rcvd,
//	.pru_rcvoob =		tcp_usr_rcvoob,
//	.pru_send =		tcp_usr_send,
//	.pru_shutdown =		tcp_usr_shutdown,
//	.pru_sockaddr =		in_getsockaddr,
//	.pru_soreceive =	soreceive_stream,
	.pru_close =		tcp_usr_close,
};

tpa_pr_usrreqs tcp6_usrreqs = {
//	.pru_abort =		tcp_usr_abort,
//	.pru_accept =		tcp6_usr_accept,
	.pru_attach =		tcp_usr_attach,
	.pru_bind =		tcp6_usr_bind,
	.pru_connect =		tcp6_usr_connect,
//	.pru_control =		in6_control,
	.pru_detach =		tcp_usr_detach,
	.pru_disconnect =	tcp_usr_disconnect,
	.pru_listen =		tcp6_usr_listen,
	.pru_sopoll = 		tcp_poll,
//	.pru_rcvd =		tcp_usr_rcvd,
//	.pru_rcvoob =		tcp_usr_rcvoob,
//	.pru_send =		tcp_usr_send,
//	.pru_shutdown =		tcp_usr_shutdown,
//	.pru_sockaddr =		in6_mapped_sockaddr,
//	.pru_soreceive =	soreceive_stream,
	.pru_close =		tcp_usr_close,
};

