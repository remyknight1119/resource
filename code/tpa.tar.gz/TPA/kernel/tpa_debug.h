#ifndef __TPA_DEBUG_H
#define __TPA_DEBUG_H

extern u8 tpa_debug_on;

#include <linux/module.h>
#if 1
#define TPA_DEBUG(str,args...) \
	do {\
		if (tpa_debug_on) { \
			printk("[%s: %d]",__FUNCTION__,__LINE__);\
			printk(str,##args);\
		} \
	}while(0)
#else
#define TPA_DEBUG(str,args...) \
	do {\
		if (tpa_debug_on) { \
			unsigned int cpu = get_cpu();  \
			printk("[%s: %d]",__FUNCTION__,__LINE__);\
			printk("------------ref is %ld\n",local_read(__module_ref_addr(THIS_MODULE, cpu)));\
			printk(str,##args);\
		} \
	}while(0)
#endif

#endif
