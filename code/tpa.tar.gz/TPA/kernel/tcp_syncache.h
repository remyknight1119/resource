#ifndef __TCP_SYNCACHE__
#define __TCP_SYNCACHE__


extern int tpa_syncache_expand(tpa_in_conninfo *inc, tpa_tcpopt *to, tpa_tcphdr *th,
    tpa_socket **lsop, struct sk_buff *skb);
extern void tpa_syncache_chkrst(tpa_in_conninfo *inc, tpa_tcphdr *th);
extern void tpa_syncache_badack(tpa_in_conninfo *inc);
extern void tpa_syncache_add(tpa_in_conninfo *inc, tpa_tcpopt *to, tpa_tcphdr *th,
    tpa_inpcb *inp, tpa_socket **lsop, struct sk_buff *skb);

#endif
