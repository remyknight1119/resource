/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_in6.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-28
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/fs.h>
#include <linux/kernel.h>

#include "tpa_in6.h"
#include "tpa_in.h"

const tpa_in6_addr tpa_in6addr_any = TPA_IN6ADDR_ANY_INIT;

/*
 * Convert sockaddr_in6 to sockaddr_in.  Original sockaddr_in6 must be
 * v4 mapped addr or v4 compat addr
 */
void
tpa_in6_sin6_2_sin(tpa_sockaddr_in *sin, tpa_sockaddr_in6 *sin6)
{

	tpa_bzero(sin, sizeof(*sin));
	sin->sin_len = sizeof(tpa_sockaddr_in);
	sin->sin_family = TPA_INET4;
	sin->sin_port = sin6->sin6_port;
	sin->sin_addr.s_addr = sin6->sin6_addr.i6_addr32[3];
}


