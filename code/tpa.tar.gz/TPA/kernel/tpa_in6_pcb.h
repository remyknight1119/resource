#ifndef __TPA_IN6_PCB_H__
#define __TPA_IN6_PCB_H__

extern int tpa_in6_pcbbind(register tpa_inpcb *inp, tpa_sockaddr *nam);
extern tpa_inpcb *tpa_in6_pcblookup_hash(tpa_inpcbinfo *pcbinfo, tpa_in6_addr *faddr,
    		u32 fport_arg, tpa_in6_addr *laddr, u32 lport_arg, int find_listen);

#endif
