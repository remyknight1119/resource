#ifndef __TPA_IPV4_H__
#define __TPA_IPV4_H__

#include <linux/ip.h>
#include "../include/tpa_types.h"

/*
 * Definitions for internet protocol version 4.
 *
 * Per RFC 791, September 1981.
 */
#define	IPVERSION	4

/*
 * ECN (Explicit Congestion Notification) codepoints in RFC3168 mapped to the
 * lower 2 bits of the TOS field.
 */
#define	IPTOS_ECN_NOTECT	0x00	/* not-ECT */
#define	IPTOS_ECN_ECT1		0x01	/* ECN-capable transport (1) */
#define	IPTOS_ECN_ECT0		0x02	/* ECN-capable transport (0) */
#define	IPTOS_ECN_CE		0x03	/* congestion experienced */
#define	IPTOS_ECN_MASK		0x03	/* ECN field mask */

extern int tpa_ipv4_input(struct sk_buff *skb);
extern int tpa_ipv4_init(void);
extern void tpa_ipv4_exit(void);

#endif
