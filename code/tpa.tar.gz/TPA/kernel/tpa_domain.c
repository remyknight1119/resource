/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_domain.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-04
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/


#include "tpa_protosw.h"
#include "tpa_domain.h"
#include "tpa_debug.h"
#include "../include/tpa_types.h"

static tpa_domain *tpa_net_domains[TPA_NPROTO] = {};

int 
tpa_add_domain(tpa_domain *dom)
{
	if(dom->dom_family < 0 || dom->dom_family >= TPA_NPROTO){
		return -1;
	}

	if(tpa_net_domains[dom->dom_family] != NULL){
		return -1;
	}

	tpa_net_domains[dom->dom_family] = dom;

	return 0;
}

int 
tpa_del_domain(tpa_domain *dom)
{
	if(dom->dom_family < 0 || dom->dom_family >= TPA_NPROTO){
		return -1;
	}

	if(tpa_net_domains[dom->dom_family] != dom){
		return -1;
	}

	tpa_net_domains[dom->dom_family] = NULL;

	return 0;
}

tpa_domain *
tpa_find_domain(int family)
{
	if(family < 0 || family >= TPA_NPROTO){
		TPA_DEBUG("family is not exist!\n");
		return NULL;
	}

	return tpa_net_domains[family];
}

