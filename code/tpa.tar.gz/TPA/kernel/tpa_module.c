#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/syscalls.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <asm/uaccess.h>

#include <linux/netdevice.h>

#include "tpa_hook.h"
#include "tpa_ipv4.h"
#include "tpa_ipv6.h"
#include "tpa_socket.h"
#include "tpa_debug.h"
#include "../include/tpa_comm.h"

MODULE_LICENSE("Dual BSD/GPL");

static long tpa_nargs[TPA_SYS_MAX + 1] = {3, 3, 3, 2, 3, 5, 5, 5, 4, 4, 6, 6, 2, 5, 5, 3, 3};

extern int (*tpa_syscall)(u32 cmd, ulong args);

int tpa_syscalls(u32 cmd, ulong args) 
{
	ulong a[6];
	ulong a0, a1;
	int err = 0;

	TPA_DEBUG("CFA syscall!\n");
	if (cmd < 1 || cmd > TPA_SYS_MAX){
		TPA_DEBUG("cmd error!cmd = %u\n",cmd);
		return -1;
	}

	/* copy_from_user should be SMP safe. */
	if (copy_from_user(a, (void *)args, sizeof(ulong) * tpa_nargs[(cmd - TPA_SYS_START)])){
		TPA_DEBUG("copy from user error!\n");
		return -1;
	}

	a0 = a[0];
	a1 = a[1];

	switch (cmd) {
	case TPA_SYS_SOCKET:
		err = tpa_sys_socket(a0, a1, a[2]);
		break;
	case TPA_SYS_BIND:
		err = tpa_sys_bind(a0, (tpa_sockaddr __user *)a1, a[2]);
		break;
	case TPA_SYS_CONNECT:
		err = tpa_sys_connect(a0, (tpa_sockaddr __user *)a1, a[2]);
		break;
	case TPA_SYS_LISTEN:
		TPA_DEBUG("sys listen!\n");
		err = tpa_sys_listen(a0, a1);
		break;
	case TPA_SYS_ACCEPT:
		err = tpa_sys_accept(a0, (tpa_sockaddr __user *)a1,
				  (int __user *)a[2]);
		break;
	case TPA_SYS_SEND:
		err = tpa_sys_send(a0, (void __user *)a1, a[2], a[3]);
		break;
	case TPA_SYS_RECV:
		err = tpa_sys_recv(a0, (void __user *)a1, a[2], a[3]);
		break;
	case TPA_SYS_SHUTDOWN:
		err = tpa_sys_shutdown(a0, a1);
		break;
	case TPA_SYS_SETSOCKOPT:
		err = tpa_sys_setsockopt(a0, a1, a[2], (char __user *)a[3], a[4]);
		break;
	case TPA_SYS_GETSOCKOPT:
		err = tpa_sys_getsockopt(a0, a1, a[2], (char __user *)a[3],
				   (int __user *)a[4]);
		break;
	case TPA_SYS_SENDMSG:
		err = tpa_sys_sendmsg(a0, (tpa_msghdr __user *)a1, a[2]);
		break;
	case TPA_SYS_RECVMSG:
		err = tpa_sys_recvmsg(a0, (tpa_msghdr __user *)a1, a[2]);
		break;
	case TPA_SYS_DEBUG:
//		err = tpa_sys_debug((tpa_debug_ioctl_st *)args);
		break;
	default:
		err = -EINVAL;
		break;
	}
	return err;
}

static int __init tpa_init(void)
{
	if (tpa_ipfilter_init()){
		TPA_DEBUG("Ipfilter init failed!\n");
		return -1;
	}

	if (tpa_socket_init()){
		TPA_DEBUG("Socket init failed!\n");
		return -1;
	}

	if (tpa_ipv4_init()){
		TPA_DEBUG("IPv4 init failed!\n");
		return -1;
	}

	if (tpa_ipv6_init()){
		TPA_DEBUG("IPv6 init failed!\n");
		return -1;
	}

	tpa_syscall = tpa_syscalls;

	return 0;
}

static void __exit tpa_exit(void)
{
	tpa_syscall = NULL;
	tpa_ipv6_exit();
	tpa_ipv4_exit();
	tpa_socket_exit();
	tpa_ipfilter_exit();
}

module_init(tpa_init);
module_exit(tpa_exit);
