#ifndef __TPA_DOMAIN_H__
#define __TPA_DOMAIN_H__

struct _tpa_protosw;

typedef struct _tpa_domain {
	int	dom_family;		/* AF_xxx */
	struct _tpa_protosw *dom_protosw;
	struct _tpa_protosw *dom_protosw_last;
}tpa_domain;
	
extern int tpa_add_domain(tpa_domain *dom);
extern int tpa_del_domain(tpa_domain *dom);
extern tpa_domain *tpa_find_domain(int family);

#endif
