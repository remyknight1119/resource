/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_input.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-03-21
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include "tcpcb.h"
#include "tpa_ipv4.h"
#include "tpa_ipv6.h"

/*
 * Tcp output routine: figure out what should be sent and send it.
 */
int
tcp_output(tpa_tcpcb *tp)
{
	tpa_socket *so = tp->t_inpcb->inp_socket;
	long len, recwin, sendwin;
	int off, flags, error;
	struct iphdr *ip = NULL;
//	struct ipovly *ipov = NULL;
	tpa_tcphdr *th;
	u8 opt[TCP_MAXOLEN];
	unsigned ipoptlen, optlen, hdrlen;
	int idle;
	int sendalot;
	int sack_rxmit;
	int sack_bytes_rxmt;
	tpa_sackhole *p;
	int tso = 0;
	tpa_tcpopt to;
	struct ipv6hdr *ip6 = NULL;
	int isipv6;

	isipv6 = (tp->t_inpcb->inp_vflag & TPA_INP_IPV6) != 0;

	/*
	 * Determine length of data that should be transmitted,
	 * and flags that will be used.
	 * If there is some data or critical controls (SYN, RST)
	 * to send, then transmit; otherwise, investigate further.
	 */
#if 0
	idle = (tp->t_flags & TF_LASTIDLE) || (tp->snd_max == tp->snd_una);
	if (idle && ticks - tp->t_rcvtime >= tp->t_rxtcur) {
		/*
		 * We have been idle for "a while" and no acks are
		 * expected to clock out any data we send --
		 * slow start to get ack "clock" running again.
		 *
		 * Set the slow-start flight size depending on whether
		 * this is a local network or not.
		 */
		int ss = V_ss_fltsz;
		if (isipv6) {
			if (in6_localaddr(&tp->t_inpcb->in6p_faddr))
				ss = V_ss_fltsz_local;
		} else

		if (in_localaddr(tp->t_inpcb->inp_faddr))
			ss = V_ss_fltsz_local;
		tp->snd_cwnd = tp->t_maxseg * ss;
	}
	tp->t_flags &= ~TF_LASTIDLE;
	if (idle) {
		if (tp->t_flags & TF_MORETOCOME) {
			tp->t_flags |= TF_LASTIDLE;
			idle = 0;
		}
	}
again:
	/*
	 * If we've recently taken a timeout, snd_max will be greater than
	 * snd_nxt.  There may be SACK information that allows us to avoid
	 * resending already delivered data.  Adjust snd_nxt accordingly.
	 */
	if ((tp->t_flags & TF_SACK_PERMIT) &&
	    SEQ_LT(tp->snd_nxt, tp->snd_max))
		tcp_sack_adjust(tp);
	sendalot = 0;
	off = tp->snd_nxt - tp->snd_una;
	sendwin = min(tp->snd_wnd, tp->snd_cwnd);
	sendwin = min(sendwin, tp->snd_bwnd);
	flags = tcp_outflags[tp->t_state];
#endif
	
	return 0;
}
	
int
tcp_output_connect(tpa_socket *so)
{
	tpa_tcpcb *tp = tpa_sototcpcb(so);

	return tcp_output(tp);
}
	
