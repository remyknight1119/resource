#ifndef __TPA_SOCKET_H__
#define __TPA_SOCKET_H__

#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/skbuff.h>

#include "../include/tpa_queue.h"
#include "../include/tpa_types.h"

#define TPA_SOCK_MAX (TPA_SOCK_PACKET + 1)
/* Mask which covers at least up to SOCK_MASK-1.  The
 * remaining bits are used as flags. */
#define TPA_SOCK_TYPE_MASK 0xf

/* Flags for socket, socketpair, accept4 */
#define TPA_SOCK_CLOEXEC	O_CLOEXEC
#define TPA_SOCK_NONBLOCK	O_NONBLOCK

#define	TPA_SOMAXCONN	128

struct _tpa_protosw;	

typedef struct _tpa_socket{
	atomic_t	so_refcnt;	/* (b) reference count */
	short	so_type;		/* (a) generic type, see socket.h */
	short	so_options;		/* from socket call, see socket.h */
	short	so_state;		/* (b) internal state flags SS_* */
	struct file *so_file;
	struct module *owner;
	spinlock_t  so_lock;
	void	*so_pcb;		/* protocol control block */
	struct _tpa_protosw *so_proto;	/* (a) protocol handle */
	struct _tpa_socket *so_head;    /* (e) back pointer to listen socket */
	wait_queue_head_t	so_wait;
	TPA_TAILQ_HEAD(, socket) so_incomp;	/* (e) queue of partial unaccepted connections */
	TPA_TAILQ_HEAD(, socket) so_comp;	/* (e) queue of complete unaccepted connections */
	TPA_TAILQ_ENTRY(socket) so_list;	/* (e) list of unaccepted connections */
	u16 so_error;       /* (f) error affecting connection */
	u16	so_qlen;		/* (e) number of unaccepted connections */
	u16	so_qlimit;		/* (e) max number queued connections */
	u16	so_incqlen;		/* (e) number of unaccepted incomplete
					   connections */
	int	so_rcvbuf;
	int	so_sndbuf;
	struct sk_buff_head so_rcv;
	struct sk_buff_head so_snd;
}tpa_socket;

#define	TPA_SO_ACCEPTCONN	0x0002		/* socket has had listen() */
#define	TPA_SO_REUSEADDR	0x0004		/* allow local address reuse */
#define	TPA_SO_KEEPALIVE	0x0008		/* keep connections alive */
#define	TPA_SO_DONTROUTE	0x0010		/* just use interface addresses */
#define	TPA_SO_BROADCAST	0x0020		/* permit sending of broadcast msgs */
#define	TPA_SO_USELOOPBACK	0x0040		/* bypass hardware when possible */
#define	TPA_SO_LINGER	0x0080		/* linger on close if data present */
#define	TPA_SO_OOBINLINE	0x0100		/* leave received OOB data in line */
#define	TPA_SO_REUSEPORT	0x0200		/* allow local address & port reuse */
#define	TPA_SO_TIMESTAMP	0x0400		/* timestamp received dgram traffic */
#define	TPA_SO_NOSIGPIPE	0x0800		/* no SIGPIPE from EPIPE */
#define	TPA_SO_ACCEPTFILTER	0x1000		/* there is an accept filter */
#define	TPA_SO_BINTIME	0x2000		/* timestamp received dgram traffic */
#define	TPA_SO_NO_OFFLOAD	0x4000		/* socket cannot be offloaded */
#define	TPA_SO_NO_DDP	0x8000		/* disable direct data placement */

#define	TPA_SOCK_LOCK(_so)			spin_lock(&(_so)->so_lock)
#define	TPA_SOCK_UNLOCK(_so)		spin_unlock(&(_so)->so_lock)
#define	TPA_SOCK_LOCK_BH(_so)		spin_lock_bh(&(_so)->so_lock)
#define	TPA_SOCK_UNLOCK_BH(_so)		spin_unlock_bh(&(_so)->so_lock)

#define tpa_rbspace(so) (so->so_rcvbuf)
#define tpa_sbspace(so) (so->so_sndbuf)

 /* can we read something from so? */
#define tpa_soreadabledata(so) (!(skb_queue_empty(&so->so_rcv)))

/* can we write something to so? */
#define	tpa_sowriteable(so) \
    ((tpa_sbspace(&so) > 0 && \
	(((so)->so_state & TPA_SS_ISCONNECTED)))) 
	 
#if 0
	  ((so)->so_proto->pr_flags & TPA_PR_CONNREQUIRED)==0)) || \
     ((so)->so_snd.sb_state & SBS_CANTSENDMORE))
#endif


/*
 * LISTEN is a special case for poll..
 */
static inline unsigned int tpa_sk_listen_poll(const tpa_socket *so)
{
	return !TPA_TAILQ_EMPTY(&(so)->so_comp) ? (POLLIN | POLLRDNORM) : 0;
}


/*
 * Socket state bits.
 *
 * Historically, this bits were all kept in the so_state field.  For
 * locking reasons, they are now in multiple fields, as they are
 * locked differently.  so_state maintains basic socket state protected
 * by the socket lock.  so_qstate holds information about the socket
 * accept queues.  Each socket buffer also has a state field holding
 * information relevant to that socket buffer (can't send, rcv).  Many
 * fields will be read without locks to improve performance and avoid
 * lock order issues.  However, this approach must be used with caution.
 */
#define	TPA_SS_NOFDREF		0x0001	/* no file table ref any more */
#define	TPA_SS_ISCONNECTED		0x0002	/* socket connected to a peer */
#define	TPA_SS_ISCONNECTING		0x0004	/* in process of connecting to peer */
#define	TPA_SS_ISDISCONNECTING	0x0008	/* in process of disconnecting */
#define	TPA_SS_NBIO			0x0100	/* non-blocking ops */
#define	TPA_SS_ASYNC		0x0200	/* async i/o notify */
#define	TPA_SS_ISCONFIRMING		0x0400	/* deciding to accept connection req */
#define	TPA_SS_ISDISCONNECTED	0x2000	/* socket disconnected from peer */


typedef struct _tpa_socket_alloc {
	tpa_socket socket;
	struct inode vfs_inode;
}tpa_socket_alloc;      

static inline tpa_socket *TPA_SOCKET_I(struct inode *inode)
{   
	return &container_of(inode, struct _tpa_socket_alloc, vfs_inode)->socket;
}

static inline struct inode *TPA_SOCKET_INODE(tpa_socket *socket)
{
	return &container_of(socket, struct _tpa_socket_alloc, socket)->vfs_inode;
}

static inline int tpa_sock_has_sleeper(tpa_socket *so)
{
	return waitqueue_active(&so->so_wait);
}

/**
 * sock_poll_wait - place memory barrier behind the poll_wait call.
 * @filp:           file
 * @wait_address:   socket wait queue
 * @p:              poll_table
 *
 * See the comments in the sk_has_sleeper function.
 */
static inline void tpa_sock_poll_wait(struct file *filp,
		wait_queue_head_t *wait_address, poll_table *p)
{
	if (p && wait_address) {
		poll_wait(filp, wait_address, p);
		/*
		 * We need to be sure we are in sync with the
		 * socket flags modification.
		 *
		 * This memory barrier is paired in the sk_has_sleeper.
		*/
		smp_mb();
	}
}

extern void tpa_sowwakeup(tpa_socket *so);
extern int tpa_solisten_proto_check(tpa_socket *so);
extern void tpa_solisten_proto(tpa_socket *so, int backlog);
extern void tpa_soisconnecting(tpa_socket *so);
extern int tpa_sys_socket(int family, int type, int protocol);
extern int tpa_sys_bind(int fd, tpa_sockaddr __user *umyaddr, int addrlen);
extern int tpa_sys_connect(int fd, tpa_sockaddr __user *umyaddr, int addrlen);
extern int tpa_sys_listen(int fd, int backlog);
extern int tpa_sys_accept(int fd, tpa_sockaddr __user *upeer_sockaddr,
		         int __user *upeer_addrlen);
extern int tpa_sys_send(int fd, void __user *buff, size_t len, unsigned flags);
extern int tpa_sys_recv(int fd, void __user *ubuf, size_t size, unsigned flags);
extern int tpa_sys_shutdown(int fd, int how);
extern int tpa_sys_getsockopt(int fd, int level, int optname,
		         char __user *optval, int __user *optlen);
extern int tpa_sys_setsockopt(int fd, int level, int optname,
		         char __user *optval, int optlen);
extern int tpa_sys_sendmsg(int fd, tpa_msghdr __user *msg, unsigned flags);
extern int tpa_sys_recvmsg(int fd, tpa_msghdr __user *msg, unsigned flags);
extern int tpa_socket_init(void);
extern void tpa_socket_exit(void);

#endif
