/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_hash.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-27
 * DESCRIPTION:
 * 			manage the Protocol Control Blocks.
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/types.h>
#include <linux/slab.h>

#include "../include/tpa_queue.h"

/*
 * General routine to allocate a hash table with control of memory flags.
 */
void *
tpa_hashinit(int elements, gfp_t flags, ulong *hashmask)
{
	long hashsize;
	int i;
	TPA_LIST_HEAD(generic, _generic);
	generic *hashtbl;

	for (hashsize = 1; hashsize <= elements; hashsize <<= 1){
		continue;
	}
	hashsize >>= 1;

	hashtbl = kmalloc((ulong)hashsize * sizeof(*hashtbl), flags);

	if (hashtbl != NULL) {
		for (i = 0; i < hashsize; i++){
			TPA_LIST_INIT(&hashtbl[i]);
		}
		*hashmask = hashsize - 1;
	}
	return (hashtbl);
}


