/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tcp_input.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-03-21
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <net/ip.h>

#include "tpa_ipv4.h"
#include "tcp.h"
#include "tcp_fsm.h"
#include "tcp_seq.h"
#include "tcp_timer.h"
#include "tcp_syncache.h"
#include "tpa_inpcb.h"
#include "tpa_in6_pcb.h"
#include "tpa_debug.h"
#include "../include/tpa_comm.h"

static const int tcprexmtthresh = 3;

static int tcp_input(struct sk_buff *skb, int tlen, int isipv6);

/*
 * Calculate(/check) TCP checksum
 */
static inline __sum16 tcp_v4_check(int len, __be32 saddr,
				   __be32 daddr, __wsum base)
{
	return csum_tcpudp_magic(saddr,daddr,len,IPPROTO_TCP,base);
}

int tcp4_input(struct sk_buff *skb, int tlen)
{
	return tcp_input(skb, tlen, 0);
}

static inline __sum16 tcp_v6_check(int len,
				   struct in6_addr *saddr,
				   struct in6_addr *daddr,
				   __wsum base)
{
	return csum_ipv6_magic(saddr, daddr, len, IPPROTO_TCP, base);
}

int tcp6_input(struct sk_buff *skb, int tlen)
{
	return tcp_input(skb, tlen, 1);
}

/*
 * Parse TCP options and place in tcpopt.
 */
static void
tcp_dooptions(tpa_tcpopt *to, u8 *cp, int cnt, int flags)
{
	int opt, optlen;

	to->to_flags = 0;
	for (; cnt > 0; cnt -= optlen, cp += optlen) {
		opt = cp[0];
		if (opt == TCPOPT_EOL)
			break;
		if (opt == TCPOPT_NOP)
			optlen = 1;
		else {
			if (cnt < 2)
				break;
			optlen = cp[1];
			if (optlen < 2 || optlen > cnt)
				break;
		}
		switch (opt) {
		case TCPOPT_MAXSEG:
			if (optlen != TCPOLEN_MAXSEG)
				continue;
			if (!(flags & TO_SYN))
				continue;
			to->to_flags |= TOF_MSS;
			bcopy((char *)cp + 2,
			    (char *)&to->to_mss, sizeof(to->to_mss));
			to->to_mss = ntohs(to->to_mss);
			break;
		case TCPOPT_WINDOW:
			if (optlen != TCPOLEN_WINDOW)
				continue;
			if (!(flags & TO_SYN))
				continue;
			to->to_flags |= TOF_SCALE;
			to->to_wscale = tpa_imin(cp[2], TCP_MAX_WINSHIFT);
			break;
		case TCPOPT_TIMESTAMP:
			if (optlen != TCPOLEN_TIMESTAMP)
				continue;
			to->to_flags |= TOF_TS;
			bcopy((char *)cp + 2,
			    (char *)&to->to_tsval, sizeof(to->to_tsval));
			to->to_tsval = ntohl(to->to_tsval);
			bcopy((char *)cp + 6,
			    (char *)&to->to_tsecr, sizeof(to->to_tsecr));
			to->to_tsecr = ntohl(to->to_tsecr);
			break;
		/*
		 * XXX In order to reply to a host which has set the
		 * TCP_SIGNATURE option in its initial SYN, we have to
		 * record the fact that the option was observed here
		 * for the syncache code to perform the correct response.
		 */
		case TCPOPT_SIGNATURE:
			if (optlen != TCPOLEN_SIGNATURE)
				continue;
			to->to_flags |= TOF_SIGNATURE;
			to->to_signature = cp + 2;
			break;
		case TCPOPT_SACK_PERMITTED:
			if (optlen != TCPOLEN_SACK_PERMITTED)
				continue;
			if (!(flags & TO_SYN))
				continue;
			to->to_flags |= TOF_SACKPERM;
			break;
		case TCPOPT_SACK:
			if (optlen <= 2 || (optlen - 2) % TCPOLEN_SACK != 0)
				continue;
			if (flags & TO_SYN)
				continue;
			to->to_flags |= TOF_SACK;
			to->to_nsacks = (optlen - 2) / TCPOLEN_SACK;
			to->to_sacks = cp + 2;
			break;
		default:
			continue;
		}
	}
}

static void inline
tcp_congestion_exp(tpa_tcpcb *tp)
{
	u32 win;
	
	win = min(tp->snd_wnd, tp->snd_cwnd) /
	    2 / tp->t_maxseg;
	if (win < 2){
		win = 2;
	}

	tp->snd_ssthresh = win * tp->t_maxseg;
	ENTER_FASTRECOVERY(tp);
	tp->snd_recover = tp->snd_max;
	if (tp->t_flags & TF_ECN_PERMIT){
		tp->t_flags |= TF_ECN_SND_CWR;
	}
}

void
tcp_mss(tpa_tcpcb *tp, int offer)
{
#if 0
	int rtt, mss;
	u_long bufsize;
	struct inpcb *inp;
	struct socket *so;
	struct hc_metrics_lite metrics;
	int mtuflags = 0;
	int isipv6;
	
	tcp_mss_update(tp, offer, &metrics, &mtuflags);

	mss = tp->t_maxseg;
	inp = tp->t_inpcb;
	isipv6 = ((inp->inp_vflag & INP_IPV6) != 0) ? 1 : 0;

	/*
	 * If there's a pipesize, change the socket buffer to that size,
	 * don't change if sb_hiwat is different than default (then it
	 * has been changed on purpose with setsockopt).
	 * Make the socket buffers an integral number of mss units;
	 * if the mss is larger than the socket buffer, decrease the mss.
	 */
	so = inp->inp_socket;
	SOCKBUF_LOCK(&so->so_snd);
	if ((so->so_snd.sb_hiwat == tcp_sendspace) && metrics.rmx_sendpipe)
		bufsize = metrics.rmx_sendpipe;
	else
		bufsize = so->so_snd.sb_hiwat;
	if (bufsize < mss)
		mss = bufsize;
	else {
		bufsize = roundup(bufsize, mss);
		if (bufsize > sb_max)
			bufsize = sb_max;
		if (bufsize > so->so_snd.sb_hiwat)
			(void)sbreserve_locked(&so->so_snd, bufsize, so, NULL);
	}
	SOCKBUF_UNLOCK(&so->so_snd);
	tp->t_maxseg = mss;

	SOCKBUF_LOCK(&so->so_rcv);
	if ((so->so_rcv.sb_hiwat == tcp_recvspace) && metrics.rmx_recvpipe)
		bufsize = metrics.rmx_recvpipe;
	else
		bufsize = so->so_rcv.sb_hiwat;
	if (bufsize > mss) {
		bufsize = roundup(bufsize, mss);
		if (bufsize > sb_max)
			bufsize = sb_max;
		if (bufsize > so->so_rcv.sb_hiwat)
			(void)sbreserve_locked(&so->so_rcv, bufsize, so, NULL);
	}
	SOCKBUF_UNLOCK(&so->so_rcv);
	/*
	 * While we're here, check the others too.
	 */
	if (tp->t_srtt == 0 && (rtt = metrics.rmx_rtt)) {
		tp->t_srtt = rtt;
		tp->t_rttbest = tp->t_srtt + TCP_RTT_SCALE;
		TCPSTAT_INC(tcps_usedrtt);
		if (metrics.rmx_rttvar) {
			tp->t_rttvar = metrics.rmx_rttvar;
			TCPSTAT_INC(tcps_usedrttvar);
		} else {
			/* default variation is +- 1 rtt */
			tp->t_rttvar =
			    tp->t_srtt * TCP_RTTVAR_SCALE / TCP_RTT_SCALE;
		}
		TCPT_RANGESET(tp->t_rxtcur,
			      ((tp->t_srtt >> 2) + tp->t_rttvar) >> 1,
			      tp->t_rttmin, TCPTV_REXMTMAX);
	}
	if (metrics.rmx_ssthresh) {
		/*
		 * There's some sort of gateway or interface
		 * buffer limit on the path.  Use this to set
		 * the slow start threshhold, but set the
		 * threshold to no less than 2*mss.
		 */
		tp->snd_ssthresh = max(2 * mss, metrics.rmx_ssthresh);
		TCPSTAT_INC(tcps_usedssthresh);
	}
	if (metrics.rmx_bandwidth)
		tp->snd_bandwidth = metrics.rmx_bandwidth;
	/*
	 * Set the slow-start flight size depending on whether this
	 * is a local network or not.
	 *
	 * Extend this so we cache the cwnd too and retrieve it here.
	 * Make cwnd even bigger than RFC3390 suggests but only if we
	 * have previous experience with the remote host. Be careful
	 * not make cwnd bigger than remote receive window or our own
	 * send socket buffer. Maybe put some additional upper bound
	 * on the retrieved cwnd. Should do incremental updates to
	 * hostcache when cwnd collapses so next connection doesn't
	 * overloads the path again.
	 *
	 * RFC3390 says only do this if SYN or SYN/ACK didn't got lost.
	 * We currently check only in syncache_socket for that.
	 */
	if (metrics.rmx_cwnd)
		tp->snd_cwnd = max(mss,
				min(metrics.rmx_cwnd / 2,
				 min(tp->snd_wnd, so->so_snd.sb_hiwat)));
	else if (V_tcp_do_rfc3390)
		tp->snd_cwnd = min(4 * mss, max(2 * mss, 4380));
	else if ((isipv6 && in6_localaddr(&inp->in6p_faddr)) ||
		 (!isipv6 && in_localaddr(inp->inp_faddr)))
		tp->snd_cwnd = mss * V_ss_fltsz_local;
	else
		tp->snd_cwnd = mss * V_ss_fltsz;

	/* Check the interface for TSO capabilities. */
	if (mtuflags & CSUM_TSO)
		tp->t_flags |= TF_TSO;
#endif
}
	
/*
 * Collect new round-trip time estimate
 * and update averages and current timeout.
 */
static void
tcp_xmit_timer(tpa_tcpcb *tp, int rtt)
{
	int delta;

	tp->t_rttupdated++;
	if (tp->t_srtt != 0) {
		/*
		 * srtt is stored as fixed point with 5 bits after the
		 * binary point (i.e., scaled by 8).  The following magic
		 * is equivalent to the smoothing algorithm in rfc793 with
		 * an alpha of .875 (srtt = rtt/8 + srtt*7/8 in fixed
		 * point).  Adjust rtt to origin 0.
		 */
		delta = ((rtt - 1) << TCP_DELTA_SHIFT)
			- (tp->t_srtt >> (TCP_RTT_SHIFT - TCP_DELTA_SHIFT));

		if ((tp->t_srtt += delta) <= 0)
			tp->t_srtt = 1;

		/*
		 * We accumulate a smoothed rtt variance (actually, a
		 * smoothed mean difference), then set the retransmit
		 * timer to smoothed rtt + 4 times the smoothed variance.
		 * rttvar is stored as fixed point with 4 bits after the
		 * binary point (scaled by 16).  The following is
		 * equivalent to rfc793 smoothing with an alpha of .75
		 * (rttvar = rttvar*3/4 + |delta| / 4).  This replaces
		 * rfc793's wired-in beta.
		 */
		if (delta < 0)
			delta = -delta;
		delta -= tp->t_rttvar >> (TCP_RTTVAR_SHIFT - TCP_DELTA_SHIFT);
		if ((tp->t_rttvar += delta) <= 0)
			tp->t_rttvar = 1;
		if (tp->t_rttbest > tp->t_srtt + tp->t_rttvar)
		    tp->t_rttbest = tp->t_srtt + tp->t_rttvar;
	} else {
		/*
		 * No rtt measurement yet - use the unsmoothed rtt.
		 * Set the variance to half the rtt (so our first
		 * retransmit happens at 3*rtt).
		 */
		tp->t_srtt = rtt << TCP_RTT_SHIFT;
		tp->t_rttvar = rtt << (TCP_RTTVAR_SHIFT - 1);
		tp->t_rttbest = tp->t_srtt + tp->t_rttvar;
	}
	tp->t_rtttime = 0;
	tp->t_rxtshift = 0;

	/*
	 * the retransmit should happen at rtt + 4 * rttvar.
	 * Because of the way we do the smoothing, srtt and rttvar
	 * will each average +1/2 tick of bias.  When we compute
	 * the retransmit timer, we want 1/2 tick of rounding and
	 * 1 extra tick because of +-1/2 tick uncertainty in the
	 * firing of the timer.  The bias will give us exactly the
	 * 1.5 tick we need.  But, because the bias is
	 * statistical, we have to test that we don't drop below
	 * the minimum feasible timer (which is 2 ticks).
	 */
	TCPT_RANGESET(tp->t_rxtcur, TCP_REXMTVAL(tp),
		      tpa_imax(tp->t_rttmin, rtt + 2), TCPTV_REXMTMAX);


	/*
	 * We received an ack for a packet that wasn't retransmitted;
	 * it is probably safe to discard any error indications we've
	 * received recently.  This isn't quite right, but close enough
	 * for now (a route might have failed after we sent a segment,
	 * and the return path might not be symmetrical).
	 */
	tp->t_softerror = 0;
}

/*
 * @snd: the skb buffer for send
 * @acked: the bytes that is already be acknowledged by ACK segment
 * NOTE: 
 */
static int tpa_sbdrop(struct sk_buff_head *snd, int acked)
{
	struct sk_buff *skb = NULL;
	int free_len = 0;

	while ((skb = skb_peek(snd)) && skb->len <= acked){
		acked -= skb->len;
		free_len += skb->len;
		__skb_unlink(skb, snd);
		__kfree_skb(skb);
	}

	return free_len;
}

static void
tcp_do_segment(struct sk_buff *skb, tpa_tcphdr *th, tpa_socket *so,
    	tpa_tcpcb *tp, int tlen, u8 iptos)
{
	int thflags;
	int acked;
	int ourfinisacked;
	int needoutput = 0;
	int rstreason;
	int todrop;
	int win;
	ulong tiwin;
	tpa_tcpopt to;
	int free_space = 0;

	thflags = th->th_flags;

	/*
	 * Segment received on connection.
	 * Reset idle time and keep-alive timer.
	 * XXX: This should be done after segment
	 * validation to ignore broken/spoofed segs.
	 */
	tp->t_rcvtime = tpa_current_tick;
	if (TCPS_HAVEESTABLISHED(tp->t_state)){
		tcp_timer_activate(tp, TT_KEEP, tcp_keepidle);
	}

	/*
	 * Unscale the window into a 32-bit value.
	 * For the SYN_SENT state the scale is zero.
	 */
	tiwin = th->th_win << tp->snd_scale;

	/*
	 * TCP ECN processing.
	 */
	if (tp->t_flags & TF_ECN_PERMIT) {
		if (thflags & TH_CWR)
			tp->t_flags &= ~TF_ECN_SND_ECE;
		switch (iptos & IPTOS_ECN_MASK) {
		case IPTOS_ECN_CE:
			tp->t_flags |= TF_ECN_SND_ECE;
			break;
		case IPTOS_ECN_ECT0:
			break;
		case IPTOS_ECN_ECT1:
			break;
		}
		/*
		 * Congestion experienced.
		 * Ignore if we are already trying to recover.
		 */
		if ((thflags & TH_ECE) &&
		    SEQ_LEQ(th->th_ack, tp->snd_recover)) {
			tcp_congestion_exp(tp);
		}
	}

	/*
	 * Parse options on any incoming segment.
	 */
	tcp_dooptions(&to, (u8 *)(th + 1),
	    (th->th_off << 2) - sizeof(tpa_tcphdr),
	    (thflags & TH_SYN) ? TO_SYN : 0);

	/*
	 * If echoed timestamp is later than the current time,
	 * fall back to non RFC1323 RTT calculation.  Normalize
	 * timestamp if syncookies were used when this connection
	 * was established.
	 */
	if ((to.to_flags & TOF_TS) && (to.to_tsecr != 0)) {
		to.to_tsecr -= tp->ts_offset;
		if (TSTMP_GT(to.to_tsecr, tpa_current_tick))
			to.to_tsecr = 0;
	}

	/*
	 * Process options only when we get SYN/ACK back. The SYN case
	 * for incoming connections is handled in tcp_syncache.
	 * According to RFC1323 the window field in a SYN (i.e., a <SYN>
	 * or <SYN,ACK>) segment itself is never scaled.
	 * XXX this is traditional behavior, may need to be cleaned up.
	 */
	if (tp->t_state == TCPS_SYN_SENT && (thflags & TH_SYN)) {
		if ((to.to_flags & TOF_SCALE) &&
		    (tp->t_flags & TF_REQ_SCALE)) {
			tp->t_flags |= TF_RCVD_SCALE;
			tp->snd_scale = to.to_wscale;
		}
		/*
		 * Initial send window.  It will be updated with
		 * the next incoming segment to the scaled value.
		 */
		tp->snd_wnd = th->th_win;
		if (to.to_flags & TOF_TS) {
			tp->t_flags |= TF_RCVD_TSTMP;
			tp->ts_recent = to.to_tsval;
			tp->ts_recent_age = tpa_current_tick;
		}
		if (to.to_flags & TOF_MSS)
			tcp_mss(tp, to.to_mss);
		if ((tp->t_flags & TF_SACK_PERMIT) &&
		    (to.to_flags & TOF_SACKPERM) == 0)
			tp->t_flags &= ~TF_SACK_PERMIT;
	}

	/*
	 * Header prediction: check for the two common cases
	 * of a uni-directional data xfer.  If the packet has
	 * no control flags, is in-sequence, the window didn't
	 * change and we're not retransmitting, it's a
	 * candidate.  If the length is zero and the ack moved
	 * forward, we're the sender side of the xfer.  Just
	 * free the data acked & wake any higher level process
	 * that was blocked waiting for space.  If the length
	 * is non-zero and the ack didn't move, we're the
	 * receiver side.  If we're getting packets in-order
	 * (the reassembly queue is empty), add the data to
	 * the socket buffer and note that we need a delayed ack.
	 * Make sure that the hidden state-flags are also off.
	 * Since we check for TCPS_ESTABLISHED first, it can only
	 * be TH_NEEDSYN.
	 */
	if (tp->t_state == TCPS_ESTABLISHED &&
	    th->th_seq == tp->rcv_nxt &&
	    (thflags & (TH_SYN|TH_FIN|TH_RST|TH_URG|TH_ACK)) == TH_ACK &&
	    tp->snd_nxt == tp->snd_max &&
	    tiwin && tiwin == tp->snd_wnd && 
	    ((tp->t_flags & (TF_NEEDSYN|TF_NEEDFIN)) == 0) &&
	    TPA_LIST_EMPTY(&tp->t_segq) &&
	    ((to.to_flags & TOF_TS) == 0 ||
	     TSTMP_GEQ(to.to_tsval, tp->ts_recent)) ) {

		/*
		 * If last ACK falls within this segment's sequence numbers,
		 * record the timestamp.
		 * NOTE that the test is modified according to the latest
		 * proposal of the tcplw@cray.com list (Braden 1993/04/26).
		 */
		if ((to.to_flags & TOF_TS) != 0 &&
		    SEQ_LEQ(th->th_seq, tp->last_ack_sent)) {
			tp->ts_recent_age = tpa_current_tick;
			tp->ts_recent = to.to_tsval;
		}

		if (tlen == 0) {
			if (SEQ_GT(th->th_ack, tp->snd_una) &&
			    SEQ_LEQ(th->th_ack, tp->snd_max) &&
			    tp->snd_cwnd >= tp->snd_wnd &&
			    ((!(tp->t_flags & TF_SACK_PERMIT) &&
			      tp->t_dupacks < tcprexmtthresh) ||
			     (((tp->t_flags & TF_SACK_PERMIT)) &&
			      !IN_FASTRECOVERY(tp) &&
			      (to.to_flags & TOF_SACK) == 0 &&
			      TPA_TAILQ_EMPTY(&tp->snd_holes)))) {
				
				TPA_INP_INFO_WUNLOCK(&tcbinfo);

				/*
				 * "bad retransmit" recovery.
				 */
				if (tp->t_rxtshift == 1 &&
				    (int)(tpa_current_tick - tp->t_badrxtwin) < 0) {
					tp->snd_cwnd = tp->snd_cwnd_prev;
					tp->snd_ssthresh = tp->snd_ssthresh_prev;
					tp->snd_recover = tp->snd_recover_prev;
					if (tp->t_flags & TF_WASFRECOVERY){
					    ENTER_FASTRECOVERY(tp);
					}
					tp->snd_nxt = tp->snd_max;
					tp->t_badrxtwin = 0;
				}
		
				/*
				 * Recalculate the transmit timer / rtt.
				 *
				 * Some boxes send broken timestamp replies
				 * during the SYN+ACK phase, ignore
				 * timestamps of 0 or we could calculate a
				 * huge RTT and blow up the retransmit timer.
				 */
				if ((to.to_flags & TOF_TS) != 0 &&
				    to.to_tsecr) {
					if (!tp->t_rttlow ||
					    tp->t_rttlow > tpa_current_tick - to.to_tsecr){
						tp->t_rttlow = tpa_current_tick - to.to_tsecr;
					}
					tcp_xmit_timer(tp, tpa_current_tick - to.to_tsecr + 1);
				} else if (tp->t_rtttime &&
				    SEQ_GT(th->th_ack, tp->t_rtseq)) {
					if (!tp->t_rttlow ||
					    tp->t_rttlow > tpa_current_tick - tp->t_rtttime)
						tp->t_rttlow = tpa_current_tick - tp->t_rtttime;
					tcp_xmit_timer(tp, tpa_current_tick - tp->t_rtttime);
				}
				tcp_xmit_bandwidth_limit(tp, th->th_ack);
				acked = th->th_ack - tp->snd_una;
				free_space = tpa_sbdrop(&so->so_snd, acked);
				if (SEQ_GT(tp->snd_una, tp->snd_recover) &&
				    SEQ_LEQ(th->th_ack, tp->snd_recover)){
					tp->snd_recover = th->th_ack - 1;
				}
				tp->snd_una = th->th_ack;
				/*
				 * Pull snd_wl2 up to prevent seq wrap relative
				 * to th_ack.
				 */
				tp->snd_wl2 = th->th_ack;
				tp->t_dupacks = 0;
				__kfree_skb(skb);
//				ND6_HINT(tp); /* Some progress has been made. */

				/*
				 * If all outstanding data are acked, stop
				 * retransmit timer, otherwise restart timer
				 * using current (possibly backed-off) value.
				 * If process is waiting for space,
				 * wakeup/selwakeup/signal.  If data
				 * are ready to send, let tcp_output
				 * decide between more output or persist.
				 */
				if (tp->snd_una == tp->snd_max)
					tcp_timer_activate(tp, TT_REXMT, 0);
				else if (!tcp_timer_active(tp, TT_PERSIST))
					tcp_timer_activate(tp, TT_REXMT,
						      tp->t_rxtcur);
				if (free_space){
					tpa_sowwakeup(so);
				}

				tcp_output(tp);
				goto check_delack;
			}
		} else if (th->th_ack == tp->snd_una &&
		    tlen <= tpa_rbspace(so)) {
			int newsize = 0;	/* automatic sockbuf scaling */
		}

	}

check_delack:
	if (tp->t_flags & TF_DELACK) {
		tp->t_flags &= ~TF_DELACK;
		tcp_timer_activate(tp, TT_DELACK, tcp_delacktime);
	}
	TPA_INP_WUNLOCK(tp->t_inpcb);
	return;

}

/*
 * @skb: Linux socket buffer
 * @tlen: then length of the entire transport segment
 * @isipv6: then label of the TCP use IP network protocol version 6
 */
static int tcp_input(struct sk_buff *skb, int tlen, int isipv6)
{
	struct iphdr *iph = NULL;
	struct ipv6hdr *hdr = NULL;
	tpa_tcphdr *th = tpa_tcp_hdr(skb);
	int off = 0;
	int optlen = 0;
	u8 iptos;
	u8 *optp = NULL;
	tpa_tcpopt to;
	int thflags = 0;
#define	TI_UNLOCKED	1
#define	TI_RLOCKED	2
#define	TI_WLOCKED	3
	int ti_locked = TI_UNLOCKED;
	tpa_inpcb *inp = NULL;
	tpa_tcpcb *tp = NULL;
	tpa_socket *so = NULL;
	int ret = 0;

	TPA_DEBUG("=======Enter=======\n");

	/*
	 * Check the TCP checksum
	 */
	if (isipv6) {
		hdr = ipv6_hdr(skb);
		if (!tcp_v6_check(skb->len, &hdr->saddr,
					&hdr->daddr, skb->csum)) {
			TPA_DEBUG("Check sum error!\n");
			goto drop;
		}
	} else {
		iph = ip_hdr(skb);
		if (!tcp_v4_check(skb->len, iph->saddr,
					iph->daddr, skb->csum)) {
			TPA_DEBUG("Check sum error!\n");
			goto drop;
		}
	}

	if (isipv6){
//		iptos = (ntohl(ip6->ip6_flow) >> 20) & 0xff;
	} else {
		iptos = iph->tos;
	}


	/*
	 * Check that TCP offset makes sense,
	 * pull out TCP options and adjust length.		XXX
	 */
	off = th->th_off << 2;
	if (off < sizeof (tpa_tcphdr) || off > tlen) {
		goto drop;
	}

	tlen -= off;	/* tlen is used instead of ti->ti_len */
	if (off > sizeof (tpa_tcphdr)) {
		optlen = off - sizeof (tpa_tcphdr);
		optp = (u8 *)(th + 1);
	}

	thflags = th->th_flags;
	/*
	 * Locate pcb for segment, which requires a lock on tcbinfo.
	 * Optimisticaly acquire a global read lock rather than a write lock
	 * unless header flags necessarily imply a state change.  There are
	 * two cases where we might discover later we need a write lock
	 * despite the flags: ACKs moving a connection out of the syncache,
	 * and ACKs for a connection in TIMEWAIT.
	 */
	TPA_INP_INFO_WLOCK(&tcbinfo);
	ti_locked = TI_WLOCKED;

findpcb:
	if (isipv6) {
		inp = tpa_in6_pcblookup_hash(&tcbinfo,
				(tpa_in6_addr *)&hdr->saddr, th->th_sport,
				(tpa_in6_addr *)&hdr->daddr, th->th_dport,
				1);
	}else{
		inp = tpa_in_pcblookup_hash(&tcbinfo,
				*((tpa_in_addr *)&iph->saddr), th->th_sport,
				*((tpa_in_addr *)&iph->daddr), th->th_dport,
				1);
	}

	/*
	 * If the INPCB does not exist then all data in the incoming
	 * segment is discarded and an appropriate RST is sent back.
	 * XXX MRT Send RST using which routing table?
	 */
	if (inp == NULL) {
		TPA_DEBUG("Cannot find TCP connection, forward it!\n");
		goto forward;
	}
	TPA_INP_WLOCK(inp);

	/*
	 * A previous connection in TIMEWAIT state is supposed to catch stray
	 * or duplicate segments arriving late.  If this segment was a
	 * legitimate new connection attempt the old INPCB gets removed and
	 * we can try again to find a listening socket.
	 *
	 * At this point, due to earlier optimism, we may hold a read lock on
	 * the inpcbinfo, rather than a write lock.  If so, we need to
	 * upgrade, or if that fails, acquire a reference on the inpcb, drop
	 * all locks, acquire a global write lock, and then re-acquire the
	 * inpcb lock.  We may at that point discover that another thread has
	 * tried to free the inpcb, in which case we need to loop back and
	 * try to find a new inpcb to deliver to.
	 */
	if (inp->inp_flags & TPA_INP_TIMEWAIT) {
		if (thflags & TH_SYN){
			tcp_dooptions(&to, optp, optlen, TO_SYN);
		}
		/*
		 * NB: tcp_twcheck unlocks the INP and frees the mbuf.
		 */
		if (tcp_twcheck(inp, &to, th, skb, tlen)){
			goto findpcb;
		}
		TPA_INP_WUNLOCK(inp);
		TPA_INP_INFO_WUNLOCK(&tcbinfo);
		TPA_DEBUG("TCP timewait, out!\n");
		goto out;
	}
		
	/*
	 * The TCPCB may no longer exist if the connection is winding
	 * down or it is in the CLOSED state.  Either way we drop the
	 * segment and send an appropriate response.
	 */
	tp = tpa_intotcpcb(inp);
	if (tp == NULL || tp->t_state == TCPS_CLOSED) {
//		rstreason = BANDLIM_RST_CLOSEDPORT;
		TPA_DEBUG("tp is NULL or state is closed! drop with reset! tp = %p\n",tp);
		goto dropwithreset;
	}

	so = inp->inp_socket;

	/*
	 * When the socket is accepting connections (the INPCB is in LISTEN
	 * state) we look into the SYN cache if this is a new connection
	 * attempt or the completion of a previous one.
	 */
	if (so->so_options & SO_ACCEPTCONN) {
		tpa_in_conninfo inc;
		tpa_bzero(&inc, sizeof(inc));
		if (isipv6) {
//			inc.inc_flags |= INC_ISIPV6;
			inc.inc6_faddr = *((tpa_in6_addr *)&hdr->saddr);
			inc.inc6_laddr = *((tpa_in6_addr *)&hdr->daddr);
		} else {
			inc.inc_faddr = *((tpa_in_addr *)&iph->saddr);
			inc.inc_laddr = *((tpa_in_addr *)&iph->daddr);
		}
		inc.inc_fport = th->th_sport;
		inc.inc_lport = th->th_dport;
//		inc.inc_fibnum = so->so_fibnum;

		/*
		 * Check for an existing connection attempt in syncache if
		 * the flag is only ACK.  A successful lookup creates a new
		 * socket appended to the listen queue in SYN_RECEIVED state.
		 */
		if ((thflags & (TH_RST|TH_ACK|TH_SYN)) == TH_ACK) {
			/*
			 * Parse the TCP options here because
			 * syncookies need access to the reflected
			 * timestamp.
			 */
			tcp_dooptions(&to, optp, optlen, 0);
			/*
			 * NB: syncache_expand() doesn't unlock
			 * inp and tcpinfo locks.
			 */
			if (!tpa_syncache_expand(&inc, &to, th, &so, skb)) {
				/*
				 * No syncache entry or ACK was not
				 * for our SYN/ACK.  Send a RST.
				 * NB: syncache did its own logging
				 * of the failure cause.
				 */
				//				rstreason = BANDLIM_RST_OPENPORT;
				TPA_DEBUG("Syncache expand failed! dropwithreset!\n");
				goto dropwithreset;
			}

			if (so == NULL) {
				/*
				 * We completed the 3-way handshake
				 * but could not allocate a socket
				 * either due to memory shortage,
				 * listen queue length limits or
				 * global socket limits.  Send RST
				 * or wait and have the remote end
				 * retransmit the ACK for another
				 * try.
				 */
//				rstreason = BANDLIM_UNLIMITED;
				TPA_DEBUG("Create socekt failed! dropwithreset!\n");
				goto dropwithreset;
			}
			/*
			 * Socket is created in state SYN_RECEIVED.
			 * Unlock the listen socket, lock the newly
			 * created socket and update the tp variable.
			 */
			TPA_INP_WUNLOCK(inp);	/* listen socket */
			inp = tpa_sotoinpcb(so);
			TPA_INP_WLOCK(inp);		/* new connection */
			tp = tpa_intotcpcb(inp);
			/*
			 * Process the segment and the data it
			 * contains.  tcp_do_segment() consumes
			 * the mbuf chain and unlocks the inpcb.
			 */
			tcp_do_segment(skb, th, so, tp, tlen, iptos);

			TPA_INP_WUNLOCK(inp);
			TPA_INP_INFO_WUNLOCK(&tcbinfo);
			TPA_DEBUG("After proccess ACK! out!\n");
			goto out;
		}

		/*
		 * Segment flag validation for new connection attempts:
		 *
		 * Our (SYN|ACK) response was rejected.
		 * Check with syncache and remove entry to prevent
		 * retransmits.
		 *
		 * NB: syncache_chkrst does its own logging of failure
		 * causes.
		 */
		if (thflags & TH_RST) {
			tpa_syncache_chkrst(&inc, th);
			goto drop;
		}
		/*
		 * We can't do anything without SYN.
		 */
		if ((thflags & TH_SYN) == 0) {
			goto drop;
		}
		/*
		 * (SYN|ACK) is bogus on a listen socket.
		 */
		if (thflags & TH_ACK) {
			tpa_syncache_badack(&inc);	/* XXX: Not needed! */
//			rstreason = BANDLIM_RST_OPENPORT;
			goto dropwithreset;
		}

		/*
		 * If the drop_synfin option is enabled, drop all
		 * segments with both the SYN and FIN bits set.
		 * This prevents e.g. nmap from identifying the
		 * TCP/IP stack.
		 * XXX: Poor reasoning.  nmap has other methods
		 * and is constantly refining its stack detection
		 * strategies.
		 * XXX: This is a violation of the TCP specification
		 * and was used by RFC1644.
		 */
		if (thflags & TH_FIN) {
			goto drop;
		}
		if (isipv6) {
			if (th->th_dport == th->th_sport &&
			    TPA_IN6_ARE_ADDR_EQUAL((tpa_in6_addr *)&hdr->daddr, (tpa_in6_addr *)&hdr->saddr)) {
				goto drop;
			}
		} else {
			if (th->th_dport == th->th_sport &&
			    iph->daddr == iph->saddr) {
				goto drop;
			}
		}
		
		tcp_dooptions(&to, optp, optlen, TO_SYN);
		tpa_syncache_add(&inc, &to, th, inp, &so, skb);
		TPA_DEBUG("After proccess! out!\n");
		goto out;
	}

	/*
	 * Segment belongs to a connection in SYN_SENT, ESTABLISHED or later
	 * state.  tcp_do_segment() always consumes the mbuf chain, unlocks
	 * the inpcb, and unlocks pcbinfo.
	 */
	tcp_do_segment(skb, th, so, tp, tlen, iptos);

out:
	if (ti_locked == TI_WLOCKED){
		TPA_INP_INFO_WUNLOCK(&tcbinfo);
	}
	ti_locked = TI_UNLOCKED;

	if (inp != NULL) {
		TPA_INP_WUNLOCK(inp);
	}

	return ret;

forward:
	ret = -1;
	goto out;
dropwithreset:
//	tcp_dropwithreset(m, th, tp, tlen);
drop:
	kfree_skb(skb);
	ret = 0;
	goto out;
}


