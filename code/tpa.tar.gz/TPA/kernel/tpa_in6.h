#ifndef __TPA_IN6_H__
#define __TPA_IN6_H__

#include "../include/tpa_types.h"

/*
 * Unspecified
 */
#define TPA_IN6_IS_ADDR_UNSPECIFIED(a)	\
	((*(const u32 *)(const void *)(&(a)->i6_addr[0]) == 0) &&	\
	 (*(const u32 *)(const void *)(&(a)->i6_addr[4]) == 0) &&	\
	 (*(const u32 *)(const void *)(&(a)->i6_addr[8]) == 0) &&	\
	 (*(const u32 *)(const void *)(&(a)->i6_addr[12]) == 0))

/*
 * Mapped
 */
#define TPA_IN6_IS_ADDR_V4MAPPED(a)		      \
	((*(const u32 *)(const void *)(&(a)->i6_addr[0]) == 0) &&	\
	 (*(const u32 *)(const void *)(&(a)->i6_addr[4]) == 0) &&	\
	 (*(const u32 *)(const void *)(&(a)->i6_addr[8]) == ntohl(0x0000ffff)))

/*
 * Multicast
 */
#define TPA_IN6_IS_ADDR_MULTICAST(a)	((a)->i6_addr[0] == 0xff)

#define TPA_IN6ADDR_ANY_INIT \
	{{{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }}}

#define TPA_IN6_ARE_ADDR_EQUAL(a, b)			\
    (memcmp(&(a)->i6_addr[0], &(b)->i6_addr[0], sizeof(tpa_in6_addr)) == 0)

extern const tpa_in6_addr tpa_in6addr_any;

extern void tpa_in6_sin6_2_sin(tpa_sockaddr_in *sin, tpa_sockaddr_in6 *sin6);

#endif

