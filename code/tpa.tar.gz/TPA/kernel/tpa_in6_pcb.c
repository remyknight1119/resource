/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_in6_pcb.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-28
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/gfp.h>
#include <linux/slab.h>
#include <linux/net.h>

#include "tpa_socket.h"
#include "tpa_inpcb.h"
#include "tpa_in6.h"
#include "tpa_in.h"
#include "tpa_domain.h"
#include "tpa_debug.h"
#include "tcpcb.h"

/*
 * Lookup a PCB based on the local address and port.
 */
tpa_inpcb *
tpa_in6_pcblookup_local(tpa_inpcbinfo *pcbinfo, tpa_in6_addr *laddr,
    u16 lport, int wild_okay)
{
	register tpa_inpcb *inp;
	int matchwild = 3, wildcard;

	if (!wild_okay) {
		tpa_inpcbhead *head;
		/*
		 * Look for an unconnected (wildcard foreign addr) PCB that
		 * matches the local address and port we're looking for.
		 */
		head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(TPA_INADDR_ANY, lport,
		    0, pcbinfo->ipi_hashmask)];
		TPA_LIST_FOREACH(inp, head, inp_hash) {
			/* XXX inp locking */
			if ((inp->inp_vflag & TPA_INP_IPV6) == 0){
				continue;
			}
			if (TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_faddr) &&
			    TPA_IN6_ARE_ADDR_EQUAL(&inp->in6p_laddr, laddr) &&
			    inp->inp_lport == lport) {
				/* Found. */
				return (inp);
			}
		}
		/*
		 * Not found.
		 */
		return (NULL);
	} else {
		tpa_inpcbporthead *porthash;
		tpa_inpcbport *phd;
		tpa_inpcb *match = NULL;
		/*
		 * Best fit PCB lookup.
		 *
		 * First see if this local port is in use by looking on the
		 * port hash list.
		 */
		porthash = &pcbinfo->ipi_porthashbase[TPA_INP_PCBPORTHASH(lport,
		    pcbinfo->ipi_porthashmask)];
		TPA_LIST_FOREACH(phd, porthash, phd_hash) {
			if (phd->phd_port == lport){
				break;
			}
		}
		if (phd != NULL) {
			/*
			 * Port is in use by one or more PCBs. Look for best
			 * fit.
			 */
			TPA_LIST_FOREACH(inp, &phd->phd_pcblist, inp_portlist) {
				wildcard = 0;
				/* XXX inp locking */
				if ((inp->inp_vflag & TPA_INP_IPV6) == 0){
					continue;
				}
				if (!TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_faddr)){
					wildcard++;
				}
				if (!TPA_IN6_IS_ADDR_UNSPECIFIED(
					&inp->in6p_laddr)) {
					if (TPA_IN6_IS_ADDR_UNSPECIFIED(laddr)){
						wildcard++;
					}else if (!TPA_IN6_ARE_ADDR_EQUAL(
					    &inp->in6p_laddr, laddr)){
						continue;
					}
				} else {
					if (!TPA_IN6_IS_ADDR_UNSPECIFIED(laddr)){
						wildcard++;
					}
				}
				if (wildcard < matchwild) {
					match = inp;
					matchwild = wildcard;
					if (matchwild == 0)
						break;
				}
			}
		}
		return (match);
	}
}


/*
 * XXX: this is borrowed from in6_pcbbind(). If possible, we should
 * share this function by all *bsd*...
 */
static int
tpa_in6_pcbsetport(tpa_in6_addr *laddr, tpa_inpcb *inp)
{
	tpa_socket *so = inp->inp_socket;
	u16 lport = 0;
	u16 first;
	u16 last;
	u16 *lastport;
	int count;
	int wild;
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;


	/* XXX: this is redundant when called from in6_pcbbind */
	if ((so->so_options & (TPA_SO_REUSEADDR|TPA_SO_REUSEPORT)) == 0){
		wild = TPA_INPLOOKUP_WILDCARD;
	}

	inp->inp_flags |= TPA_INP_ANONPORT;

	first = tpa_ipport_first;	/* sysctl */
	last  = tpa_ipport_last;
	lastport = &pcbinfo->ipi_lastport;

	/*
	 * Instead of having two loops further down counting up or down
	 * make sure that first is always <= last and go with only one
	 * code path implementing all logic.
	 */
	if (first > last) {
		u16 aux;

		aux = first;
		first = last;
		last = aux;
	}

	*lastport = first + (net_random() % (last - first + 1));

	count = last - first;

	do {
		if (count-- < 0) {	/* completely used? */
			/* Undo an address bind that may have occurred. */
			inp->in6p_laddr = tpa_in6addr_any;
			return -1;
		}
		++*lastport;
		if (*lastport < first || *lastport > last)
			*lastport = first;
		lport = htons(*lastport);
	} while (tpa_in6_pcblookup_local(pcbinfo, &inp->in6p_laddr,
	    lport, wild));

	inp->inp_lport = lport;
	if (tpa_in_pcbinshash(inp) != 0) {
		inp->in6p_laddr = tpa_in6addr_any;
		inp->inp_lport = 0;
		TPA_DEBUG("Hash error!\n");
		return -1;
	}
	return (0);
}

int
tpa_in6_pcbbind(register tpa_inpcb *inp, tpa_sockaddr *nam)
{
	tpa_socket *so = inp->inp_socket;
	tpa_sockaddr_in6 *sin6 = (tpa_sockaddr_in6 *)NULL;
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;
	u_short	lport = 0;
	int error, wild = 0, reuseport = (so->so_options & TPA_SO_REUSEPORT);

#if 0
	if (TPA_TAILQ_EMPTY(&V_in6_ifaddrhead)){	/* XXX broken! */
		return -1;
	}
#endif
	if (inp->inp_lport || !TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_laddr)){
		TPA_DEBUG("Lport  error!\n");
		return -1;
	}
	if ((so->so_options & (TPA_SO_REUSEADDR|TPA_SO_REUSEPORT)) == 0){
		wild = TPA_INPLOOKUP_WILDCARD;
	}
	if (nam != NULL) {
		sin6 = (tpa_sockaddr_in6 *)nam;
		if (nam->sa_len != sizeof(*sin6)){
			TPA_DEBUG("Sa_len  error!\n");
			return -1;
		}
		/*
		 * family check.
		 */
		if (nam->sa_family != TPA_INET6){
			TPA_DEBUG("Family  error!\n");
			return -1;
		}

		lport = sin6->sin6_port;
		if (TPA_IN6_IS_ADDR_MULTICAST(&sin6->sin6_addr)) {
			/*
			 * Treat SO_REUSEADDR as SO_REUSEPORT for multicast;
			 * allow compepte duplication of binding if
			 * SO_REUSEPORT is set, or if SO_REUSEADDR is set
			 * and a multicast address is bound on both
			 * new and duplicated sockets.
			 */
			if (so->so_options & TPA_SO_REUSEADDR){
				reuseport = TPA_SO_REUSEADDR|TPA_SO_REUSEPORT;
			}
		} else if (!TPA_IN6_IS_ADDR_UNSPECIFIED(&sin6->sin6_addr)) {
#if 0
			struct ifaddr *ifa;

			sin6->sin6_port = 0;		/* yech... */
			if ((ifa = ifa_ifwithaddr((struct sockaddr *)sin6)) ==
			    NULL &&
			    (inp->inp_flags & INP_BINDANY) == 0) {
				return (EADDRNOTAVAIL);
			}

			/*
			 * XXX: bind to an anycast address might accidentally
			 * cause sending a packet with anycast source address.
			 * We should allow to bind to a deprecated address, since
			 * the application dares to use it.
			 */
			if (ifa != NULL &&
			    ((struct in6_ifaddr *)ifa)->ia6_flags &
			    (IN6_IFF_ANYCAST|IN6_IFF_NOTREADY|IN6_IFF_DETACHED)) {
				ifa_free(ifa);
				return (EADDRNOTAVAIL);
			}
			if (ifa != NULL)
				ifa_free(ifa);
#endif
		}
		if (lport) {
			tpa_inpcb *t;

			if (!TPA_IN6_IS_ADDR_MULTICAST(&sin6->sin6_addr)) {
				t = tpa_in6_pcblookup_local(pcbinfo,
				    &sin6->sin6_addr, lport,
				    TPA_INPLOOKUP_WILDCARD);
				if (t &&
				    ((t->inp_flags & TPA_INP_TIMEWAIT) == 0) &&
				    (so->so_type != TPA_SOCK_STREAM ||
				     TPA_IN6_IS_ADDR_UNSPECIFIED(&t->in6p_faddr)) &&
				    (!TPA_IN6_IS_ADDR_UNSPECIFIED(&sin6->sin6_addr) ||
				     !TPA_IN6_IS_ADDR_UNSPECIFIED(&t->in6p_laddr) ||
				     (t->inp_socket->so_options & TPA_SO_REUSEPORT)
				      == 0)){
					TPA_DEBUG("Addr error!\n");
					return -1;
				}
				if ((inp->inp_flags & TPA_IN6P_IPV6_V6ONLY) == 0 &&
				    TPA_IN6_IS_ADDR_UNSPECIFIED(&sin6->sin6_addr)) {
					tpa_sockaddr_in sin;

					tpa_in6_sin6_2_sin(&sin, sin6);
					t = tpa_in_pcblookup_local(pcbinfo,
					    sin.sin_addr, lport,
					    TPA_INPLOOKUP_WILDCARD);
					if (t &&
					    ((t->inp_flags &
					      TPA_INP_TIMEWAIT) == 0) &&
					    (so->so_type != TPA_SOCK_STREAM ||
					     ntohl(t->inp_faddr.s_addr) ==
					      TPA_INADDR_ANY))
						TPA_DEBUG("Addr error!\n");
						return -1;
				}
			}
			t = tpa_in6_pcblookup_local(pcbinfo, &sin6->sin6_addr,
			    lport, wild);
			if (t && (reuseport & ((t->inp_flags & TPA_INP_TIMEWAIT) ?
			    tpa_intotw(t)->tw_so_options :
			    t->inp_socket->so_options)) == 0){
				TPA_DEBUG("State error!\n");
				return -1;
			}
			if ((inp->inp_flags & TPA_IN6P_IPV6_V6ONLY) == 0 &&
			    TPA_IN6_IS_ADDR_UNSPECIFIED(&sin6->sin6_addr)) {
				tpa_sockaddr_in sin;

				tpa_in6_sin6_2_sin(&sin, sin6);
				t = tpa_in_pcblookup_local(pcbinfo, sin.sin_addr,
				    lport, wild);
				if (t && t->inp_flags & TPA_INP_TIMEWAIT) {
					if ((reuseport &
					    tpa_intotw(t)->tw_so_options) == 0 &&
					    (ntohl(t->inp_laddr.s_addr) !=
					     TPA_INADDR_ANY || ((inp->inp_vflag &
					     TPA_INP_IPV6PROTO) ==
					     (t->inp_vflag & TPA_INP_IPV6PROTO))))
						TPA_DEBUG("State error!\n");
						return -1;
				}
				else if (t &&
				    (reuseport & t->inp_socket->so_options)
				    == 0 && (ntohl(t->inp_laddr.s_addr) !=
				    TPA_INADDR_ANY || TPA_INP_SOCKAF(so) ==
				     TPA_INP_SOCKAF(t->inp_socket)))
					TPA_DEBUG("State error!\n");
					return -1;
			}
		}
		inp->in6p_laddr = sin6->sin6_addr;
	}
	if (lport == 0) {
		if ((error = tpa_in6_pcbsetport(&inp->in6p_laddr, inp)) != 0){
			return (error);
		}
	} else {
		inp->inp_lport = lport;
		if (tpa_in_pcbinshash(inp) != 0) {
			inp->in6p_laddr = tpa_in6addr_any;
			inp->inp_lport = 0;
			TPA_DEBUG("Lport error!\n");
			return -1;
		}
	}
	return (0);
}

/*
 * Lookup PCB in hash list.
 */
tpa_inpcb *
tpa_in6_pcblookup_hash(tpa_inpcbinfo *pcbinfo, tpa_in6_addr *faddr,
    u32 fport_arg, tpa_in6_addr *laddr, u32 lport_arg, int find_listen)
{
	tpa_inpcbhead *head;
	tpa_inpcb *inp;
	tpa_inpcb *tmpinp;
	u16 fport = fport_arg;
	u16 lport = lport_arg;

	/*
	 * First look for an exact match.
	 */
	head = &pcbinfo->ipi_hashbase[
	    TPA_INP_PCBHASH(faddr->i6_addr32[3] /* XXX */, lport, fport,
	    pcbinfo->ipi_hashmask)];
	TPA_LIST_FOREACH(inp, head, inp_hash) {
		/* XXX inp locking */
		if ((inp->inp_vflag & TPA_INP_IPV6) == 0){
			continue;
		}
		if (TPA_IN6_ARE_ADDR_EQUAL(&inp->in6p_faddr, faddr) &&
		    TPA_IN6_ARE_ADDR_EQUAL(&inp->in6p_laddr, laddr) &&
		    inp->inp_fport == fport &&
		    inp->inp_lport == lport) {
			/*
			 * XXX We should be able to directly return
			 * the inp here, without any checks.
			 * Well unless both bound with SO_REUSEPORT?
			 */
			return (inp);
		}
	}

	if (find_listen){
		head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(TPA_INADDR_ANY, lport,
		    0, pcbinfo->ipi_hashmask)];
		TPA_LIST_FOREACH(inp, head, inp_hash) {
			/* XXX inp locking */
			if ((inp->inp_vflag & TPA_INP_IPV6) == 0){
				continue;
			}
			if (!TPA_IN6_IS_ADDR_UNSPECIFIED(&inp->in6p_faddr) ||
			    inp->inp_lport != lport) {
				continue;
			}

			if (TPA_IN6_ARE_ADDR_EQUAL(&inp->in6p_laddr, laddr)){
				return (inp);
			}
		} /* LIST_FOREACH */
	}


	/*
	 * Not found.
	 */
	return (NULL);
}


