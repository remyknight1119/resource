/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_protosw.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-04
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/


#include "tpa_protosw.h"
#include "tpa_domain.h"
#include "tpa_debug.h"

tpa_protosw *
tpa_pffindproto(int family, int protocol, int type)
{
	tpa_protosw *pr;
	tpa_domain *dp;

	if (family == 0){
		TPA_DEBUG("family error!\n");
		return NULL;
	}

	dp = tpa_find_domain(family);
	if(dp == NULL){
		TPA_DEBUG("find domain error!\n");
		return NULL;
	}

	for (pr = dp->dom_protosw; pr < dp->dom_protosw_last; pr++) {
		TPA_DEBUG("pr_protocol = %d,protocol = %d\n",pr->pr_protocol, protocol);
		TPA_DEBUG("pr_type = %d,type = %d\n",pr->pr_type, type);
		if ((pr->pr_protocol == protocol) && (pr->pr_type == type)){
			return pr;
		}
	}
	return NULL;
}


