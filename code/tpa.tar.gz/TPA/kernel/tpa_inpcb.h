#ifndef __TPA_INPCB_H__
#define __TPA_INPCB_H__

#include <linux/spinlock_types.h>
#include <linux/spinlock.h>
#include <linux/slab.h>

#include "tpa_socket.h"
#include "tpa_in.h"
#include "tpa_in6.h"
#include "../include/tpa_queue.h"
#include "../include/tpa_types.h"

/*
 * struct inpcb is the common protocol control block structure used in most
 * IP transport protocols.
 *
 * Pointers to local and foreign host table entries, local and foreign socket
 * numbers, and pointers up (to a socket structure) and down (to a
 * protocol-specific control block) are stored here.
 */
TPA_LIST_HEAD(tpa_inpcbhead, _tpa_inpcb);

typedef struct _tpa_inpcbport {
	TPA_LIST_ENTRY(_tpa_inpcbport) phd_hash;
	tpa_inpcbhead phd_pcblist;
	u16 phd_port;
}tpa_inpcbport;

TPA_LIST_HEAD(tpa_inpcbporthead, _tpa_inpcbport);

struct _tpa_inpcbinfo;

typedef struct _tpa_in_addr_4in6 {
	u32	ia46_pad32[3];
	tpa_in_addr	ia46_addr4;
}tpa_in_addr_4in6 ;

/*
 * NOTE: ipv6 addrs should be 64-bit aligned, per RFC 2553.  in_conninfo has
 * some extra padding to accomplish this.
 */
typedef struct _tpa_in_endpoints {
	u16	ie_fport;		/* foreign port */
	u16	ie_lport;		/* local port */
	/* protocol dependent part, local and foreign addr */
	union {
		/* foreign host table entry */
		tpa_in_addr_4in6 ie46_foreign;
		tpa_in6_addr ie6_foreign;
	} ie_dependfaddr;
	union {
		/* local host table entry */
		tpa_in_addr_4in6 ie46_local;
		tpa_in6_addr ie6_local;
	} ie_dependladdr;
}tpa_in_endpoints;

#define	ie_faddr	ie_dependfaddr.ie46_foreign.ia46_addr4
#define	ie_laddr	ie_dependladdr.ie46_local.ia46_addr4
#define	ie6_faddr	ie_dependfaddr.ie6_foreign
#define	ie6_laddr	ie_dependladdr.ie6_local

/*
 * XXX The defines for inc_* are hacks and should be changed to direct
 * references.
 */
typedef struct _tpa_in_conninfo {
	u_int8_t	inc_flags;
	u_int8_t	inc_len;
	u_int16_t	inc_fibnum;	/* XXX was pad, 16 bits is plenty */
	/* protocol dependent part */
	tpa_in_endpoints inc_ie;
}tpa_in_conninfo;

#define	inc_fport	inc_ie.ie_fport
#define	inc_lport	inc_ie.ie_lport
#define	inc_faddr	inc_ie.ie_faddr
#define	inc_laddr	inc_ie.ie_laddr
#define	inc6_faddr	inc_ie.ie6_faddr
#define	inc6_laddr	inc_ie.ie6_laddr


typedef struct _tpa_inpcb {
	TPA_LIST_ENTRY(_tpa_inpcb) inp_hash;	/* (i/p) hash list */
	TPA_LIST_ENTRY(_tpa_inpcb) inp_list;	/* (i/p) list for all PCBs for proto */
	void	*inp_ppcb;		/* (i) pointer to per-protocol pcb */
	struct _tpa_inpcbinfo *inp_pcbinfo;
	struct _tpa_socket *inp_socket;	/* (i) back pointer to socket */
	tpa_in_conninfo inp_inc;	/* (i/p) list for PCB's local port */
	u32	inp_flags;		/* (i) generic IP/datagram flags */
	u8	inp_vflag;		/* (i) IP version flag (v4/v6) */
	u8	inp_ip_ttl;		/* (i) time to live proto */
	u8	inp_ip_p;		/* (c) protocol proto */
	u8	inp_ip_minttl;		/* (i) minimum TTL or drop */
	TPA_LIST_ENTRY(_tpa_inpcb) inp_portlist;	/* (i/p) */
	tpa_inpcbport *inp_phd;	/* (i/p) head of this list */
	u32	inp_refcount;       /* (i) refcount */
	rwlock_t inp_lock;
}tpa_inpcb;

#define	inp_fport	inp_inc.inc_fport
#define	inp_lport	inp_inc.inc_lport
#define	inp_faddr	inp_inc.inc_faddr
#define	inp_laddr	inp_inc.inc_laddr

#define	in6p_faddr	inp_inc.inc6_faddr
#define	in6p_laddr	inp_inc.inc6_laddr

#define	tpa_sotoinpcb(so)	((tpa_inpcb *)(so)->so_pcb)
#define	tpa_sotoin6pcb(so)	tpa_sotoinpcb(so) /* for KAME src sync over BSD*'s */

#define TPA_INP_LOCK_INIT(inp) rwlock_init(&(inp)->inp_lock)
#define TPA_INP_RLOCK(inp)		read_lock(&(inp)->inp_lock)
#define TPA_INP_RUNLOCK(inp)	read_unlock(&(inp)->inp_lock)
#define TPA_INP_RLOCK_BH(inp)		read_lock_bh(&(inp)->inp_lock)
#define TPA_INP_RUNLOCK_BH(inp)	read_unlock_bh(&(inp)->inp_lock)
#define TPA_INP_WLOCK(inp)		write_lock(&(inp)->inp_lock)
#define TPA_INP_WUNLOCK(inp)	write_unlock(&(inp)->inp_lock)
#define TPA_INP_WLOCK_BH(inp)		write_lock_bh(&(inp)->inp_lock)
#define TPA_INP_WUNLOCK_BH(inp)	write_unlock_bh(&(inp)->inp_lock)

#define TPA_INP_PCBHASH(faddr, lport, fport, mask) \
	(((faddr) ^ ((faddr) >> 16) ^ ntohs((lport) ^ (fport))) & (mask))
#define TPA_INP_PCBPORTHASH(lport, mask) \
	(ntohs((lport)) & (mask))

/*
 * Flags for inp_vflags -- historically version flags only
 */
#define	TPA_INP_IPV4	0x1
#define	TPA_INP_IPV6	0x2
#define	TPA_INP_IPV6PROTO	0x4		/* opened under IPv6 protocol */

/*
 * Flags for inp_flags.
 */
#define	TPA_INP_RECVOPTS		0x00000001 /* receive incoming IP options */
#define	TPA_INP_RECVRETOPTS		0x00000002 /* receive IP options for reply */
#define	TPA_INP_RECVDSTADDR		0x00000004 /* receive IP dst address */
#define	TPA_INP_HDRINCL		0x00000008 /* user supplies entire IP header */
#define	TPA_INP_HIGHPORT		0x00000010 /* user wants "high" port binding */
#define	TPA_INP_LOWPORT		0x00000020 /* user wants "low" port binding */
#define	TPA_INP_ANONPORT		0x00000040 /* port chosen for user */
#define	TPA_INP_RECVIF		0x00000080 /* receive incoming interface */
#define	TPA_INP_MTUDISC		0x00000100 /* user can do MTU discovery */
#define	TPA_INP_FAITH		0x00000200 /* accept FAITH'ed connections */
#define	TPA_INP_RECVTTL		0x00000400 /* receive incoming IP TTL */
#define	TPA_INP_DONTFRAG		0x00000800 /* don't fragment packet */
#define	TPA_INP_BINDANY		0x00001000 /* allow bind to any address */
#define	TPA_INP_INHASHLIST		0x00002000 /* in_pcbinshash() has been called */
#define	TPA_IN6P_IPV6_V6ONLY	0x00008000 /* restrict AF_INET6 socket for v6 */
#define	TPA_IN6P_PKTINFO		0x00010000 /* receive IP6 dst and I/F */
#define	TPA_IN6P_HOPLIMIT		0x00020000 /* receive hoplimit */
#define	TPA_IN6P_HOPOPTS		0x00040000 /* receive hop-by-hop options */
#define	TPA_IN6P_DSTOPTS		0x00080000 /* receive dst options after rthdr */
#define	TPA_IN6P_RTHDR		0x00100000 /* receive routing header */
#define	TPA_IN6P_RTHDRDSTOPTS	0x00200000 /* receive dstoptions before rthdr */
#define	TPA_IN6P_TCLASS		0x00400000 /* receive traffic class value */
#define	TPA_IN6P_AUTOFLOWLABEL	0x00800000 /* attach flowlabel automatically */
#define	TPA_INP_TIMEWAIT		0x01000000 /* in TIMEWAIT, ppcb is tcptw */
#define	TPA_INP_ONESBCAST		0x02000000 /* send all-ones broadcast */
#define	TPA_INP_DROPPED		0x04000000 /* protocol drop flag */
#define	TPA_INP_SOCKREF		0x08000000 /* strong socket reference */
#define	TPA_INP_SW_FLOWID           0x10000000 /* software generated flow id */
#define	TPA_INP_HW_FLOWID           0x20000000 /* hardware generated flow id */
#define	TPA_IN6P_RFC2292		0x40000000 /* used RFC2292 API on the socket */
#define	TPA_IN6P_MTU		0x80000000 /* receive path MTU */

#define	TPA_INP_CONTROLOPTS		(TPA_INP_RECVOPTS|TPA_INP_RECVRETOPTS|TPA_INP_RECVDSTADDR|\
				 TPA_INP_RECVIF|TPA_INP_RECVTTL|\
				 TPA_IN6P_PKTINFO|TPA_IN6P_HOPLIMIT|TPA_IN6P_HOPOPTS|\
				 TPA_IN6P_DSTOPTS|TPA_IN6P_RTHDR|TPA_IN6P_RTHDRDSTOPTS|\
				 TPA_IN6P_TCLASS|TPA_IN6P_AUTOFLOWLABEL|TPA_IN6P_RFC2292|\
				 TPA_IN6P_MTU)

#define tpa_sotoinpcb(so)   ((tpa_inpcb *)(so)->so_pcb)

/*
 * Global data structure for each high-level protocol (UDP, TCP, ...) in both
 * IPv4 and IPv6.  Holds inpcb lists and information for managing them.
 */
typedef struct _tpa_inpcbinfo {
	/*
	 * Global list of inpcbs on the protocol.
	 */
	tpa_inpcbhead	*ipi_listhead;
	u32			 ipi_count;

	/*
	 * Global hash of inpcbs, hashed by local and foreign addresses and
	 * port numbers.
	 */
	tpa_inpcbhead	*ipi_hashbase;
	ulong			 ipi_hashmask;

	/*
	 * Global hash of inpcbs, hashed by only local port number.
	 */
	tpa_inpcbporthead	*ipi_porthashbase;
	ulong			 ipi_porthashmask;

	/*
	 * Fields associated with port lookup and allocation.
	 */
	u16			 ipi_lastport;

	/*
	 * Cache pool from which inpcbs are allocated for this protocol.
	 */
	struct kmem_cache *ipi_cache;
	rwlock_t		 ipi_lock;
}tpa_inpcbinfo;

#define TPA_INP_INFO_LOCK_INIT(ipi) rwlock_init(&(ipi)->ipi_lock)
#define TPA_INP_INFO_RLOCK(ipi)	read_lock(&(ipi)->ipi_lock)
#define TPA_INP_INFO_RUNLOCK(ipi)	read_unlock(&(ipi)->ipi_lock)
#define TPA_INP_INFO_RLOCK_BH(ipi)	read_lock_bh(&(ipi)->ipi_lock)
#define TPA_INP_INFO_RUNLOCK_BH(ipi)	read_unlock_bh(&(ipi)->ipi_lock)
#define TPA_INP_INFO_WLOCK(ipi)	write_lock(&(ipi)->ipi_lock)
#define TPA_INP_INFO_WUNLOCK(ipi)	write_unlock(&(ipi)->ipi_lock)
#define TPA_INP_INFO_WLOCK_BH(ipi)	write_lock_bh(&((ipi)->ipi_lock));
#define TPA_INP_INFO_WUNLOCK_BH(ipi)	write_unlock_bh(&((ipi)->ipi_lock));

#define	TPA_INPLOOKUP_WILDCARD	1
#define	TPA_INP_SOCKAF(so) so->so_proto->pr_domain->dom_family

extern u16 tpa_ipport_first;
extern u16 tpa_ipport_last;

extern int tpa_in_pcballoc(tpa_socket *so, tpa_inpcbinfo *pcbinfo);
extern void tpa_in_pcbfree(tpa_inpcb *inp);
extern void tpa_in_pcbdetach(tpa_inpcb *inp);
extern int tpa_in_pcbbind(tpa_inpcb *inp, tpa_sockaddr *nam);
extern int tpa_in_pcbinshash(tpa_inpcb *inp);
extern tpa_inpcb *tpa_in_pcblookup_hash(tpa_inpcbinfo *pcbinfo, tpa_in_addr faddr,
    		u32 fport_arg, tpa_in_addr laddr, u32 lport_arg, int find_listen);
extern tpa_inpcb *tpa_in_pcblookup_local(tpa_inpcbinfo *pcbinfo, tpa_in_addr laddr,
    		u16 lport, int wild_okay);
extern int tpa_in_pcbconnect_setup(tpa_inpcb *inp, tpa_sockaddr *nam,
    		tpa_in_addr_t *laddrp, u16 *lportp, tpa_in_addr_t *faddrp, u16 *fportp,
    		tpa_inpcb **oinpp);
extern void tpa_in_pcbrehash(tpa_inpcb *inp);

#endif
