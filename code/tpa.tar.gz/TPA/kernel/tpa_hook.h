#ifndef __TPA_HOOK_H__
#define __TPA_HOOK_H__


extern int tpa_ipfilter_init(void);
extern void tpa_ipfilter_exit(void);

#endif
