#ifndef __TCP_TIMER_H__
#define __TCP_TIMER_H__

#include <linux/timer.h>

/*
 * The TCPT_REXMT timer is used to force retransmissions.
 * The TCP has the TCPT_REXMT timer set whenever segments
 * have been sent for which ACKs are expected but not yet
 * received.  If an ACK is received which advances tp->snd_una,
 * then the retransmit timer is cleared (if there are no more
 * outstanding segments) or reset to the base value (if there
 * are more ACKs expected).  Whenever the retransmit timer goes off,
 * we retransmit one unacknowledged segment, and do a backoff
 * on the retransmit timer.
 *
 * The TCPT_PERSIST timer is used to keep window size information
 * flowing even if the window goes shut.  If all previous transmissions
 * have been acknowledged (so that there are no retransmissions in progress),
 * and the window is too small to bother sending anything, then we start
 * the TCPT_PERSIST timer.  When it expires, if the window is nonzero,
 * we go to transmit state.  Otherwise, at intervals send a single byte
 * into the peer's window to force him to update our window information.
 * We do this at most as often as TCPT_PERSMIN time intervals,
 * but no more frequently than the current estimate of round-trip
 * packet time.  The TCPT_PERSIST timer is cleared whenever we receive
 * a window update from the peer.
 *
 * The TCPT_KEEP timer is used to keep connections alive.  If an
 * connection is idle (no segments received) for TCPTV_KEEP_INIT amount of time,
 * but not yet established, then we drop the connection.  Once the connection
 * is established, if the connection is idle for TCPTV_KEEP_IDLE time
 * (and keepalives have been enabled on the socket), we begin to probe
 * the connection.  We force the peer to send us a segment by sending:
 *	<SEQ=SND.UNA-1><ACK=RCV.NXT><CTL=ACK>
 * This segment is (deliberately) outside the window, and should elicit
 * an ack segment in response from the peer.  If, despite the TCPT_KEEP
 * initiated segments we cannot elicit a response from a peer in TCPT_MAXIDLE
 * amount of time probing, then we drop the connection.
 */

/*
 * Time constants.
 */

#define	TCPTV_MSL	( 30*HZ)		/* max seg lifetime (hah!) */
#define	TCPTV_SRTTBASE	0			/* base roundtrip time;
						   if 0, no idea yet */
#define	TCPTV_RTOBASE	(  3*HZ)		/* assumed RTO if no info */
#define	TCPTV_SRTTDFLT	(  3*HZ)		/* assumed RTT if no info */

#define	TCPTV_PERSMIN	(  5*HZ)		/* retransmit persistence */
#define	TCPTV_PERSMAX	( 60*HZ)		/* maximum persist interval */

#define	TCPTV_KEEP_INIT	( 75*HZ)		/* initial connect keepalive */
#define	TCPTV_KEEP_IDLE	(120*60*HZ)		/* dflt time before probing */
#define	TCPTV_KEEPINTVL	( 75*HZ)		/* default probe interval */
#define	TCPTV_KEEPCNT	8			/* max probes before drop */

#define	TCPTV_INFLIGHT_RTTTHRESH (10*HZ/1000)	/* below which inflight
						   disengages, in msec */

#define TCPTV_FINWAIT2_TIMEOUT (60*HZ)         /* FIN_WAIT_2 timeout if no receiver */

/*
 * Minimum retransmit timer is 3 ticks, for algorithmic stability.
 * TCPT_RANGESET() will add another TCPTV_CPU_VAR to deal with
 * the expected worst-case processing variances by the kernels
 * representing the end points.  Such variances do not always show
 * up in the srtt because the timestamp is often calculated at
 * the interface rather then at the TCP layer.  This value is
 * typically 50ms.  However, it is also possible that delayed
 * acks (typically 100ms) could create issues so we set the slop
 * to 200ms to try to cover it.  Note that, properly speaking,
 * delayed-acks should not create a major issue for interactive
 * environments which 'P'ush the last segment, at least as
 * long as implementations do the required 'at least one ack
 * for every two packets' for the non-interactive streaming case.
 * (maybe the RTO calculation should use 2*RTT instead of RTT
 * to handle the ack-every-other-packet case).
 *
 * The prior minimum of 1*hz (1 second) badly breaks throughput on any
 * networks faster then a modem that has minor (e.g. 1%) packet loss.
 */
#define	TCPTV_MIN	(HZ/33 )		/* minimum allowable value */
#define TCPTV_CPU_VAR	( HZ/5 )		/* cpu variance allowed (200ms) */
#define	TCPTV_REXMTMAX	( 64*HZ)		/* max allowable REXMT value */
#define TCPTV_TWTRUNC	8			/* RTO factor to truncate TW */
#define	TCP_LINGERTIME	120			/* linger at most 2 minutes */
#define	TCP_MAXRXTSHIFT	12			/* maximum retransmits */
#define	TCPTV_DELACK	(HZ / TPA_PR_FASTHZ / 2)	/* 100ms timeout */

/*
 * Force a time value to be in a certain range.
 */
#define	TCPT_RANGESET(tv, value, tvmin, tvmax) do { \
	(tv) = (value) + tcp_rexmit_slop; \
	if ((ulong)(tv) < (ulong)(tvmin)) \
		(tv) = (tvmin); \
	if ((ulong)(tv) > (ulong)(tvmax)) \
		(tv) = (tvmax); \
} while(0)


typedef struct _tcp_timer {
	struct	timer_list tt_rexmt;	/* retransmit timer */
	struct	timer_list tt_persist;	/* retransmit persistence */
	struct	timer_list tt_keep;	/* keepalive */
	struct	timer_list tt_2msl;	/* 2*msl TIME_WAIT timer */
	struct	timer_list tt_delack;	/* delayed ACK timer */
}tcp_timer;

#define TT_DELACK	0x01
#define TT_REXMT	0x02
#define TT_PERSIST	0x04
#define TT_KEEP		0x08
#define TT_2MSL		0x10

struct _tpa_tcpcb;
struct _tpa_socket;

extern int	tcp_keepinit;
extern int	tcp_keepidle;
extern int	tcp_keepintvl;
extern int	tcp_delacktime;
extern int	tcp_maxpersistidle;
extern int	tcp_msl;
extern int	tcp_rexmit_min;
extern int	tcp_rexmit_slop;
extern int	tcp_finwait2_timeout;
	
extern void tcp_timer_activate(struct _tpa_tcpcb *tp, int timer_type, u32 delta);
extern int tcp_timer_active(struct _tpa_tcpcb *tp, int timer_type);
extern void tcp_init_timers(struct _tpa_socket *so);

#endif

