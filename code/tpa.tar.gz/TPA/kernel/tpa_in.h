#ifndef __TPA_IN_H__
#define __TPA_IN_H__

#define	TPA_INADDR_ANY				(u32)0x00000000
#define TPA_IN_MULTICAST(i)        (((u32)(i) & 0xf0000000) == 0xe0000000)

typedef	u32		tpa_in_addr_t;

#define tpa_bzero(s, len) memset(s, 0, len)

#endif
