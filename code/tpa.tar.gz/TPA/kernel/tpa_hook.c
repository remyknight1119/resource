/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_hook.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-09-12
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/netfilter.h>
#include <linux/netfilter_ipv4/ip_tables.h>
#include <linux/netfilter_ipv6/ip6_tables.h>

#include "tpa_ipv4.h"
#include "tpa_ipv6.h"
#include "tpa_debug.h"

static u32
tpa_ipv4_in_hook(u32 hook,
		  struct sk_buff *skb,
		  const struct net_device *in,
		  const struct net_device *out,
		  int (*okfn)(struct sk_buff *))
{
	int ret = 0;
	
	TPA_DEBUG("=======Enter=======\n");

	ret = tpa_ipv4_input(skb);
	if (ret < 0){
		TPA_DEBUG("Continue to forward!\n");
		return 1;
	}

	return 0;
}

static u32
tpa_ipv6_in_hook(u32 hook,
		  struct sk_buff *skb,
		  const struct net_device *in,
		  const struct net_device *out,
		  int (*okfn)(struct sk_buff *))
{
	int ret = 0;
	
	ret = tpa_ipv6_input(skb);
	if (ret < 0){
		return 1;
	}

	return 0;
}

static struct nf_hook_ops tpa_ipt_ops[] = {
	{
		.hook = tpa_ipv4_in_hook,
		.owner = THIS_MODULE,
		.pf		= NFPROTO_IPV4,
		.hooknum	= NF_INET_FORWARD,
		.priority	= NF_IP_PRI_FILTER,
	},
	{
		.hook		= tpa_ipv6_in_hook,
		.owner		= THIS_MODULE,
		.pf		= NFPROTO_IPV6,
		.hooknum	= NF_INET_FORWARD,
		.priority	= NF_IP_PRI_FILTER,
	},
};

int tpa_ipfilter_init(void)
{
	int ret = 0;

	ret = nf_register_hooks(tpa_ipt_ops, ARRAY_SIZE(tpa_ipt_ops));
	if (ret < 0){
		printk("TPA register ipfilter failed!\n");
		return -1;
	}
	return 0;
}

void tpa_ipfilter_exit(void)
{
	nf_unregister_hooks(tpa_ipt_ops, ARRAY_SIZE(tpa_ipt_ops));
}

