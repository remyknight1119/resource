/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_socket.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-03-21
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/mount.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/file.h>
#include <linux/poll.h>
#include <linux/audit.h>
#include <linux/fdtable.h>

#include "tpa_socket.h"
#include "tpa_protosw.h"
#include "tpa_debug.h"

#define TPA_DEF_RCVBUF_SIZE	65535
#define TPA_DEF_SNDBUF_SIZE 65535

static struct vfsmount *tpa_sock_mnt __read_mostly;
static struct kmem_cache *tpa_sock_inode_cache __read_mostly;
static int tpa_soclose(tpa_socket *so);
static int somaxconn = TPA_SOMAXCONN;

static ssize_t 
tpa_sock_aio_read(struct kiocb *iocb, const struct iovec *iov,
		 		ulong nr_segs, loff_t pos)

{
	return 0;
}

static ssize_t 
tpa_sock_aio_write(struct kiocb *iocb, const struct iovec *iov,
		 		ulong nr_segs, loff_t pos)
{
	return 0;
}

/* No kernel lock held - perfect */
static u32 
tpa_sock_poll(struct file *file, poll_table *wait)
{
	tpa_socket *so;

	TPA_DEBUG("=======Enter=======\n");
	/*
	 *      We can't return errors to poll, so it's either yes or no.
	 */
	so = file->private_data;
	return so->so_proto->pr_usrreqs->pru_sopoll(file, so, wait);
}

static int 
tpa_sock_no_open(struct inode *irrelevant, struct file *dontcare)
{
	return -ENXIO;
}

static int 
tpa_sock_close(struct inode *inode, struct file *filp)
{
	tpa_socket *so = NULL;
	int err = 0;

	/*
	 *      It was possible the inode is NULL we were
	 *      closing an unfinished socket.
	 */

	TPA_DEBUG("=======Enter=======\n");
	if (!inode) {
		printk(KERN_DEBUG "sock_close: NULL inode\n");
		return err;
	}
	so = TPA_SOCKET_I(inode);
	if(so){
		err = tpa_soclose(so);
	}
	TPA_DEBUG("=======Leave=======\n");
	return err;
}


/*
 *	Update the socket async list
 *
 *	Fasync_list locking strategy.
 *
 *	1. fasync_list is modified only under process context socket lock
 *	   i.e. under semaphore.
 *	2. fasync_list is used under read_lock(&sk->sk_callback_lock)
 *	   or under socket lock.
 *	3. fasync_list can be used from softirq context, so that
 *	   modification under socket lock have to be enhanced with
 *	   write_lock_bh(&sk->sk_callback_lock).
 *							--ANK (990710)
 */

static int 
tpa_sock_fasync(int fd, struct file *filp, int on)
{
	return 0;
}

static ssize_t 
tpa_sock_sendpage(struct file *file, struct page *page,
			     int offset, size_t size, loff_t *ppos, int more)
{
	return 0;
}

static ssize_t 
tpa_sock_splice_read(struct file *file, loff_t *ppos,
			        struct pipe_inode_info *pipe, size_t len,
				u32 flags)
{
	return 0;
}

static const struct file_operations tpa_socket_file_ops = {
	.owner =	THIS_MODULE,
	.llseek =	no_llseek,
	.aio_read =	tpa_sock_aio_read,
	.aio_write = tpa_sock_aio_write,
	.poll =		tpa_sock_poll,
	.open =		tpa_sock_no_open,	/* special open code to disallow open via /proc */
	.release =	tpa_sock_close,
	.fasync =	tpa_sock_fasync,
	.sendpage =	tpa_sock_sendpage,
	.splice_write = generic_splice_sendpage,
	.splice_read =	tpa_sock_splice_read,
};

static tpa_socket *
tpa_soalloc(void)
{
	struct inode *inode;
	tpa_socket *sock;
	
	TPA_DEBUG("=======Enter=======\n");

	inode = new_inode(tpa_sock_mnt->mnt_sb);
	if (!inode){
		TPA_DEBUG("Alloc inode failed!\n");
		return NULL;
	}
	sock = TPA_SOCKET_I(inode);
	
	inode->i_mode = S_IFSOCK | S_IRWXUGO;
	inode->i_uid = current_fsuid();
	inode->i_gid = current_fsgid();
	TPA_DEBUG("=======Leave=======\n");

	return sock;
}   

static void
tpa_sodealloc(tpa_socket *so)
{
	TPA_DEBUG("=======Enter=======\n");
//	module_put(THIS_MODULE);
	if (!so->so_file) {
		iput(TPA_SOCKET_INODE(so));
		return;
	}
	so->so_file = NULL;
	TPA_DEBUG("=======Leave=======\n");
}

static struct inode *
tpa_soalloc_inode(struct super_block *sb)
{
	tpa_socket_alloc *ei;

	TPA_DEBUG("=======Enter=======\n");
	ei = kmem_cache_alloc(tpa_sock_inode_cache, GFP_KERNEL|__GFP_ZERO);
	if (!ei){
		return NULL;
	}
	init_waitqueue_head(&ei->socket.so_wait);

//	ei->socket.state = TPA_SS_UNCONNECTED;
//	ei->socket.flags = 0;
	ei->socket.so_proto = NULL;
	ei->socket.so_pcb = NULL;
	ei->socket.so_file = NULL;

	inode_init_once(&ei->vfs_inode);
	return &ei->vfs_inode;
}

static void 
tpa_sock_destroy_inode(struct inode *inode)
{
	TPA_DEBUG("=======Enter=======\n");

	kmem_cache_free(tpa_sock_inode_cache,
	container_of(inode, tpa_socket_alloc, vfs_inode));
	TPA_DEBUG("=======Leave=======\n");
}

static struct super_operations tpa_sockfs_ops = {
	.alloc_inode = tpa_soalloc_inode,
	.destroy_inode = tpa_sock_destroy_inode,
	.statfs =	simple_statfs,
};

#define TPA_SOCKFS_MAGIC 0x534F434B

static int 
tpa_sockfs_get_sb(struct file_system_type *fs_type,
					 int flags, const char *dev_name, void *data,
					 			 struct vfsmount *mnt)
{
	return get_sb_pseudo(fs_type, "tpa_socket:", &tpa_sockfs_ops, TPA_SOCKFS_MAGIC,
					     mnt);
}

static struct file_system_type tpa_sock_fs_type = {
	.name =		"tpa_sockfs",
	.get_sb =	tpa_sockfs_get_sb,
	.kill_sb =	kill_anon_super,
};

static int 
tpa_sockfs_delete_dentry(struct dentry *dentry)
{
	dentry->d_flags |= DCACHE_UNHASHED;
	return 0;
}

#if 0
/*
 * sockfs_dname() is called from d_path().
 */
static char *tpa_sockfs_dname(struct dentry *dentry, char *buffer, int buflen)
{
	return dynamic_dname(dentry, buffer, buflen, "tpa_socket:[%lu]",
				dentry->d_inode->i_ino);
}
#endif

static struct dentry_operations tpa_sockfs_dentry_operations = {
	.d_delete = tpa_sockfs_delete_dentry,
//	.d_dname  = tpa_sockfs_dname,
};

static int tpa_sock_alloc_fd(struct file **filep, int flags)
{
	int fd;

	fd = get_unused_fd();
//	fd = get_unused_fd_flags(flags);
	if (likely(fd >= 0)) {
		struct file *file = get_empty_filp();

		*filep = file;
		if (unlikely(!file)) {
			put_unused_fd(fd);
			return -ENFILE;
		}
	} else{
		*filep = NULL;
	}
	return fd;
}

static int 
tpa_sock_attach_fd(tpa_socket *so, struct file *file, int flags)
{
	struct dentry *dentry;
	struct qstr name = { .name = "" };

	dentry = d_alloc(tpa_sock_mnt->mnt_sb->s_root, &name);
	if (unlikely(!dentry)){
		return -ENOMEM;
	}

	dentry->d_op = &tpa_sockfs_dentry_operations;
	dentry->d_flags &= ~DCACHE_UNHASHED;
	d_instantiate(dentry, TPA_SOCKET_INODE(so));

	so->so_file = file;
	init_file(file, tpa_sock_mnt, dentry, FMODE_READ | FMODE_WRITE,
		  &tpa_socket_file_ops);
	TPA_SOCKET_INODE(so)->i_fop = &tpa_socket_file_ops;
	file->f_flags = O_RDWR | (flags & O_NONBLOCK);
	file->f_pos = 0;
	file->private_data = so;

	return 0;
}

static int 
tpa_sock_map_fd(tpa_socket *sock, int flags)
{
	struct file *newfile;
	int fd = tpa_sock_alloc_fd(&newfile, flags);

	TPA_DEBUG("=======Enter=======\n");
	if (likely(fd >= 0)) {
		int err = tpa_sock_attach_fd(sock, newfile, flags);

		if (unlikely(err < 0)) {
//			put_filp(newfile);
			put_unused_fd(fd);
			return err;
		}
		fd_install(fd, newfile);
	}
	return fd;
}

static tpa_socket *
tpa_sock_from_file(struct file *file, int *err)
{
	if (file->f_op == &tpa_socket_file_ops){
		return file->private_data;	/* set in sock_map_fd */
	}

	*err = -ENOTSOCK;
	return NULL;
}

tpa_socket *
tpa_sockfd_lookup(int fd, int *err)
{
	struct file *file;
	tpa_socket *sock;

	file = fget(fd);
	if (!file) {
		*err = -EBADF;
		return NULL;
	}

	sock = tpa_sock_from_file(file, err);
	if (!sock)
		fput(file);
	return sock;
}

/*
 * Lightweight file lookup - no refcnt increment if fd table isn't shared. 
 * You can use this only if it is guranteed that the current task already 
 * holds a refcnt to that file. That check has to be done at fget() only
 * and a flag is returned to be passed to the corresponding fput_light().
 * There must not be a cloning between an fget_light/fput_light pair.
 */
struct file *
tpa_fget_light(unsigned int fd, int *fput_needed)
{
	struct file *file;
	struct files_struct *files = current->files;

	*fput_needed = 0;
	if (likely((atomic_read(&files->count) == 1))) {
		file = fcheck_files(files, fd);
	} else {
		rcu_read_lock();
		file = fcheck_files(files, fd);
		if (file) {
			if (atomic_long_inc_not_zero(&file->f_count)){
				*fput_needed = 1;
			}else{
				/* Didn't get the reference, someone's freed */
				file = NULL;
			}
		}
		rcu_read_unlock();
	}

	return file;
}

static tpa_socket *
tpa_sockfd_lookup_light(int fd, int *err, int *fput_needed)
{
	struct file *file;
	tpa_socket *sock;

	*err = -EBADF;
	file = tpa_fget_light(fd, fput_needed);
	if (file) {
		sock = tpa_sock_from_file(file, err);
		if (sock){
			return sock;
		}
		fput_light(file, *fput_needed);
	}

	return NULL;
}

const struct file_operations tpa_bad_sock_fops = {
	.owner = THIS_MODULE,
	.open = tpa_sock_no_open,
};

static void tpa_init_once(void *foo)
{
	tpa_socket_alloc *ei = (tpa_socket_alloc *)foo;

	inode_init_once(&ei->vfs_inode);
}
 
static int 
tpa_init_inodecache(void)
{
	tpa_sock_inode_cache = kmem_cache_create("tpa_sock_inode",
			sizeof(tpa_socket_alloc), 
			0, (SLAB_HWCACHE_ALIGN|SLAB_RECLAIM_ACCOUNT|
				SLAB_MEM_SPREAD),
			tpa_init_once);

	if(!tpa_sock_inode_cache){
		return -ENOMEM;
	}

	return 0;
}

static void 
tpa_destroy_inodecache(void)
{
}

static int
tpa_socreate(int family, tpa_socket **aso, int type, int proto)
{
	tpa_protosw *prp;
	tpa_socket *so;
	int error;

	TPA_DEBUG("=======Enter=======\n");
	if (!proto){
		TPA_DEBUG("proto error!\n");
		return -1;
	}

	prp = tpa_pffindproto(family, proto, type);
	if (prp == NULL || prp->pr_usrreqs->pru_attach == NULL){
		TPA_DEBUG("pf find proto error!prp = %p\n",prp);
		return -1;
	}

	if (prp->pr_type != type){
		TPA_DEBUG("type error!prp->pr_type = %d, type = %d\n",prp->pr_type, type);
		return -1;
	}

	so = tpa_soalloc();
	if (so == NULL){
		TPA_DEBUG("soalloc error!\n");
		return -1;
	}

	TPA_TAILQ_INIT(&so->so_incomp);
	TPA_TAILQ_INIT(&so->so_comp);
	so->so_type = type;
	so->so_proto = prp;
	so->so_rcvbuf = TPA_DEF_RCVBUF_SIZE;
	so->so_sndbuf = TPA_DEF_SNDBUF_SIZE;
	skb_queue_head_init(&so->so_rcv);
	skb_queue_head_init(&so->so_snd);
	atomic_set(&so->so_refcnt, 1);
	spin_lock_init(&so->so_lock);
	so->owner = THIS_MODULE;
/*
 * Add __module_get(THIS_MODULE) here, for in close syscall THIS_MODULE will be put, 
 * so that the ref of THIS_MODULE is decrease to -1, and the initail value of ref
 * is 0
 */
	__module_get(so->owner);

	error = (*prp->pr_usrreqs->pru_attach)(so, proto);
	if (error) {
		atomic_set(&so->so_refcnt, 0);
		tpa_sodealloc(so);
		TPA_DEBUG("pru_attach error!\n");
		return (error);
	}

	*aso = so;
	return 0;
}

static int 
tpa_sobind(tpa_socket *so, tpa_sockaddr *sa)
{
	return (*so->so_proto->pr_usrreqs->pru_bind)(so, sa);
}

/*
 * solisten() transitions a socket from a non-listening state to a listening
 * state, but can also be used to update the listen queue depth on an
 * existing listen socket.  The protocol will call back into the sockets
 * layer using solisten_proto_check() and solisten_proto() to check and set
 * socket-layer listen state.  Call backs are used so that the protocol can
 * acquire both protocol and socket layer locks in whatever order is required
 * by the protocol.
 *
 * Protocol implementors are advised to hold the socket lock across the
 * socket-layer test and set to avoid races at the socket layer.
 */
static int
tpa_solisten(tpa_socket *so, int backlog)
{
	return ((*so->so_proto->pr_usrreqs->pru_listen)(so, backlog));
}

int
tpa_solisten_proto_check(tpa_socket *so)
{

	if (so->so_state & (TPA_SS_ISCONNECTED | TPA_SS_ISCONNECTING |
	    TPA_SS_ISDISCONNECTING)){
		return -1;
	}
	return (0);
}

void
tpa_solisten_proto(tpa_socket *so, int backlog)
{

	if (backlog < 0 || backlog > somaxconn){
		backlog = somaxconn;
	}
	so->so_qlimit = backlog;
	so->so_options |= TPA_SO_ACCEPTCONN;
}

/*
 * Procedures to manipulate state flags of socket and do appropriate wakeups.
 *
 * Normal sequence from the active (originating) side is that
 * soisconnecting() is called during processing of connect() call, resulting
 * in an eventual call to soisconnected() if/when the connection is
 * established.  When the connection is torn down soisdisconnecting() is
 * called during processing of disconnect() call, and soisdisconnected() is
 * called when the connection to the peer is totally severed.  The semantics
 * of these routines are such that connectionless protocols can call
 * soisconnected() and soisdisconnected() only, bypassing the in-progress
 * calls when setting up a ``connection'' takes no time.
 *
 * From the passive side, a socket is created with two queues of sockets:
 * so_incomp for connections in progress and so_comp for connections already
 * made and awaiting user acceptance.  As a protocol is preparing incoming
 * connections, it creates a socket structure queued on so_incomp by calling
 * sonewconn().  When the connection is established, soisconnected() is
 * called, and transfers the socket structure to so_comp, making it available
 * to accept().
 *
 * If a socket is closed with sockets on either so_incomp or so_comp, these
 * sockets are dropped.
 *
 * If higher-level protocols are implemented in the kernel, the wakeups done
 * here will sometimes cause software-interrupt process scheduling.
 */
void
tpa_soisconnecting(tpa_socket *so)
{
	TPA_SOCK_LOCK(so);
	so->so_state &= ~(TPA_SS_ISCONNECTED|TPA_SS_ISDISCONNECTING);
	so->so_state |= TPA_SS_ISCONNECTING;
	TPA_SOCK_UNLOCK(so);
}



/*
 * Attempt to free a socket.  This should really be sotryfree().
 *
 * sofree() will succeed if:
 *
 * - There are no outstanding file descriptor references or related consumers
 *   (so_count == 0).
 *
 * - The socket has been closed by user space, if ever open (SS_NOFDREF).
 *
 * - The protocol does not have an outstanding strong reference on the socket
 *   (SS_PROTOREF).
 *
 * - The socket is not in a completed connection queue, so a process has been
 *   notified that it is present.  If it is removed, the user process may
 *   block in accept() despite select() saying the socket was ready.
 *
 * Otherwise, it will quietly abort so that a future call to sofree(), when
 * conditions are right, can succeed.
 */
static void
tpa_sofree(tpa_socket *so)
{
	tpa_protosw *pr = so->so_proto;
#if 0
	tpa_socket *head;

	ACCEPT_LOCK_ASSERT();
	SOCK_LOCK_ASSERT(so);

	if ((so->so_state & SS_NOFDREF) == 0 || so->so_count != 0 ||
	    (so->so_state & SS_PROTOREF) || (so->so_qstate & SQ_COMP)) {
		SOCK_UNLOCK(so);
		ACCEPT_UNLOCK();
		return;
	}

	head = so->so_head;
	if (head != NULL) {
		TAILQ_REMOVE(&head->so_incomp, so, so_list);
		head->so_incqlen--;
		so->so_qstate &= ~SQ_INCOMP;
		so->so_head = NULL;
	}
	if (so->so_options & SO_ACCEPTCONN) {
		KASSERT((TAILQ_EMPTY(&so->so_comp)), ("sofree: so_comp populated"));
		KASSERT((TAILQ_EMPTY(&so->so_incomp)), ("sofree: so_comp populated"));
	}
	SOCK_UNLOCK(so);
	ACCEPT_UNLOCK();

	if (pr->pr_flags & PR_RIGHTS && pr->pr_domain->dom_dispose != NULL)
		(*pr->pr_domain->dom_dispose)(so->so_rcv.sb_mb);
#endif
	if (pr->pr_usrreqs->pru_detach != NULL)
		(*pr->pr_usrreqs->pru_detach)(so);

	/*
	 * From this point on, we assume that no other references to this
	 * socket exist anywhere else in the stack.  Therefore, no locks need
	 * to be acquired or held.
	 *
	 * We used to do a lot of socket buffer and socket locking here, as
	 * well as invoke sorflush() and perform wakeups.  The direct call to
	 * dom_dispose() and sbrelease_internal() are an inlining of what was
	 * necessary from sorflush().
	 *
	 * Notice that the socket buffer and kqueue state are torn down
	 * before calling pru_detach.  This means that protocols shold not
	 * assume they can perform socket wakeups, etc, in their detach code.
	 */
#if 0
	sbdestroy(&so->so_snd, so);
	sbdestroy(&so->so_rcv, so);
	knlist_destroy(&so->so_rcv.sb_sel.si_note);
	knlist_destroy(&so->so_snd.sb_sel.si_note);
#endif
	tpa_sodealloc(so);
}

static void tpa_sorele(tpa_socket *so)
{
	if (atomic_dec_and_test(&(so)->so_refcnt)){
		tpa_sofree(so);                   
	}else {                       
//		sock_unlock(so);            
//		accept_unlock();           
	}                         
}

/*
 * Close a socket on last file table reference removal.  Initiate disconnect
 * if connected.  Free socket when disconnect complete.
 *
 * This function will sorele() the socket.  Note that soclose() may be called
 * prior to the ref count reaching zero.  The actual socket structure will
 * not be freed until the ref count reaches zero.
 */
static int 
tpa_soclose(tpa_socket *so)
{
	int error = 0;

#if 0
	funsetown(&so->so_sigio);
	if (so->so_state & SS_ISCONNECTED) {
		if ((so->so_state & SS_ISDISCONNECTING) == 0) {
			error = sodisconnect(so);
			if (error) {
				if (error == ENOTCONN)
					error = 0;
				goto drop;
			}
		}
		if (so->so_options & SO_LINGER) {
			if ((so->so_state & SS_ISDISCONNECTING) &&
			    (so->so_state & SS_NBIO))
				goto drop;
			while (so->so_state & SS_ISCONNECTED) {
				error = tsleep(&so->so_timeo,
				    PSOCK | PCATCH, "soclos", so->so_linger * hz);
				if (error)
					break;
			}
		}
	}

drop:
	if (so->so_proto->pr_usrreqs->pru_close != NULL)
		(*so->so_proto->pr_usrreqs->pru_close)(so);
	if (so->so_options & SO_ACCEPTCONN) {
		struct socket *sp;
		ACCEPT_LOCK();
		while ((sp = TAILQ_FIRST(&so->so_incomp)) != NULL) {
			TAILQ_REMOVE(&so->so_incomp, sp, so_list);
			so->so_incqlen--;
			sp->so_qstate &= ~SQ_INCOMP;
			sp->so_head = NULL;
			ACCEPT_UNLOCK();
			soabort(sp);
			ACCEPT_LOCK();
		}
		while ((sp = TAILQ_FIRST(&so->so_comp)) != NULL) {
			TAILQ_REMOVE(&so->so_comp, sp, so_list);
			so->so_qlen--;
			sp->so_qstate &= ~SQ_COMP;
			sp->so_head = NULL;
			ACCEPT_UNLOCK();
			soabort(sp);
			ACCEPT_LOCK();
		}
		ACCEPT_UNLOCK();
	}
	ACCEPT_LOCK();
	SOCK_LOCK(so);
	so->so_state |= SS_NOFDREF;
#endif
	tpa_sorele(so);
	return (error);
}

static int 
tpa_getsockaddr(void __user *uaddr, int ulen, tpa_sockaddr *kaddr)
{
	tpa_sockaddr *sa = (tpa_sockaddr *)kaddr;

	if (ulen < 0 || ulen > TPA_SOCK_MAXADDRLEN){
		TPA_DEBUG("Error!ulen = %d\n",ulen);
		return -1;
	}

	if (ulen == 0){
		return 0;
	}

	if (copy_from_user(sa, uaddr, ulen)){
		TPA_DEBUG("Copy from user error!sa = %p, uaddr = %p, ulen = %d\n",sa, uaddr, ulen);
		return -1;
	}

	sa->sa_len = ulen;

	return 0;
}

int 
tpa_sys_socket(int family, int type, int protocol)
{
	tpa_socket *so;
	int flags;
	int error;

	TPA_DEBUG("=======Enter=======\n");
	flags = type & ~TPA_SOCK_TYPE_MASK;
//	if (flags & ~(TPA_SOCK_CLOEXEC | TPA_SOCK_NONBLOCK)){
//		TPA_DEBUG("Flags error!\n");
//		return -1;
//	}

	type &= TPA_SOCK_TYPE_MASK;

	if (TPA_SOCK_NONBLOCK != O_NONBLOCK && (flags & TPA_SOCK_NONBLOCK)){
		flags = (flags & ~TPA_SOCK_NONBLOCK) | O_NONBLOCK;
	}

	error = tpa_socreate(family, &so, type, protocol);
	if(error){
		TPA_DEBUG("socreate error!\n");
		return error;
	}

	error = tpa_sock_map_fd(so, flags & (O_CLOEXEC | O_NONBLOCK));
	if(error < 0){
		TPA_DEBUG("sock map fd error!\n");
		goto out_release;
	}

	return error;
out_release:
	return error;
}

int 
tpa_sys_bind(int fd, tpa_sockaddr __user *umyaddr, int addrlen)
{
	tpa_sockaddr_storage address;
	tpa_sockaddr *sa = (tpa_sockaddr *)&address;
	tpa_socket *so;
	int fput_needed;
	int error;

	TPA_DEBUG("=======Enter=======\n");

	so = tpa_sockfd_lookup_light(fd, &error, &fput_needed);
	if (so == NULL){
		TPA_DEBUG("sock lookup fd failed!\n");
		return error;
	}

	so = tpa_sockfd_lookup_light(fd, &error, &fput_needed);
	if (so) {
		error = tpa_getsockaddr(umyaddr, addrlen, sa);
		if (error >= 0) {
			error = tpa_sobind(so, sa);
		}
		fput_light(so->so_file, fput_needed);
	}

	TPA_DEBUG("=======Leave=======\n");
	return error;
}

int 
tpa_sys_listen(int fd, int backlog)
{
	tpa_socket *so;
	int error;
	int fput_needed;

	so = tpa_sockfd_lookup_light(fd, &error, &fput_needed);
	if (so) {
		error = tpa_solisten(so, backlog);
		fput_light(so->so_file, fput_needed);
	}
	
	return(error);
}

static int
tpa_sodisconnect(tpa_socket *so)
{
	if ((so->so_state & TPA_SS_ISCONNECTED) == 0){
		return -1;
	}
	if (so->so_state & TPA_SS_ISDISCONNECTING){
		return -1;
	}

	return (*so->so_proto->pr_usrreqs->pru_disconnect)(so);
}

static int
tpa_soconnect(tpa_socket *so, tpa_sockaddr *nam)
{
	int error = 0;

	if (so->so_options & TPA_SO_ACCEPTCONN){
		return -1;
	}

	/*
	 * If protocol is connection-based, can only connect once.
	 * Otherwise, if connected, try to disconnect first.  This allows
	 * user to disconnect by connecting to, e.g., a null address.
	 */
	if (so->so_state & (TPA_SS_ISCONNECTED|TPA_SS_ISCONNECTING) &&
	    ((so->so_proto->pr_flags & TPA_PR_CONNREQUIRED) ||
	    (error = tpa_sodisconnect(so)))) {
		return -1;
	} 

	/*
	 * Prevent accumulated error from previous connection from
	 * biting us.
	 */
	so->so_error = 0;

	return (*so->so_proto->pr_usrreqs->pru_connect)(so, nam);
}

static int
tpa_kern_connect(tpa_socket *so, tpa_sockaddr *sa)
{
	int error;
	int interrupted = 0;

	if (so->so_state & TPA_SS_ISCONNECTING) {
		error = -1;
		goto done1;
	}

	error = tpa_soconnect(so, sa);
	if (error){
		goto bad;
	}
#if 0
	if ((so->so_state & SS_NBIO) && (so->so_state & SS_ISCONNECTING)) {
		error = EINPROGRESS;
		goto done1;
	}
	TPA_SOCK_LOCK(so);
	while ((so->so_state & SS_ISCONNECTING) && so->so_error == 0) {
		error = msleep(&so->so_timeo, SOCK_MTX(so), PSOCK | PCATCH,
		    "connec", 0);
		if (error) {
			if (error == EINTR || error == ERESTART)
				interrupted = 1;
			break;
		}
	}
	if (error == 0) {
		error = so->so_error;
		so->so_error = 0;
	}
	TPA_SOCK_UNLOCK(so);
#endif
bad:
	if (!interrupted){
		so->so_state &= ~TPA_SS_ISCONNECTING;
	}

done1:
	return (error);
}

/*
 *	Attempt to connect to a socket with the server address.  The address
 *	is in user space so we verify it is OK and move it to kernel space.
 *
 *	For 1003.1g we need to add clean support for a bind to AF_UNSPEC to
 *	break bindings
 *
 *	NOTE: 1003.1g draft 6.3 is broken with respect to AX.25/NetROM and
 *	other SEQPACKET protocols that take time to connect() as it doesn't
 *	include the -EINPROGRESS status for such sockets.
 */
int 
tpa_sys_connect(int fd, tpa_sockaddr __user *umyaddr, int addrlen)
{
	tpa_socket *so;
	tpa_sockaddr_storage address;
	tpa_sockaddr *sa = (tpa_sockaddr *)&address;
	int error;
	int fput_needed;

	so = tpa_sockfd_lookup_light(fd, &error, &fput_needed);
	if (!so){
		goto out;
	}
	error = tpa_getsockaddr(umyaddr, addrlen, sa);
	if (error < 0){
		goto out_put;
	}

	error = tpa_kern_connect(so, sa);

out_put:
	fput_light(so->so_file, fput_needed);
out:
	return error;
}

int 
tpa_sys_accept(int fd, tpa_sockaddr __user *upeer_sockaddr,
		         int __user *upeer_addrlen)
{
//	__module_get(so->owner);
	return 0;
}

int 
tpa_sys_send(int fd, void __user *buff, size_t len, unsigned flags)
{
	return 0;
}

int 
tpa_sys_recv(int fd, void __user *ubuf, size_t size, unsigned flags)
{
	return 0;
}

int 
tpa_sys_shutdown(int fd, int how)
{
	return 0;
}

int 
tpa_sys_getsockopt(int fd, int level, int optname,
		         char __user *optval, int __user *optlen)
{
	return 0;
}

int 
tpa_sys_setsockopt(int fd, int level, int optname,
		         char __user *optval, int optlen)
{
	return 0;
}

int 
tpa_sys_sendmsg(int fd, tpa_msghdr __user *msg, unsigned flags)
{
	return 0;
}

int 
tpa_sys_recvmsg(int fd, tpa_msghdr __user *msg, unsigned flags)
{
	return 0;
}

void tpa_sowwakeup(tpa_socket *so)
{
	if (tpa_sock_has_sleeper(so)){
//		wake_up_interruptible_sync_poll(&so->so_wait, POLLIN |
//				POLLRDNORM | POLLRDBAND);
		wake_up_interruptible_sync_poll(&so->so_wait, POLLOUT |
				 POLLWRNORM | POLLWRBAND);
	}
}

int 
tpa_socket_init(void)
{
	tpa_init_inodecache();
	register_filesystem(&tpa_sock_fs_type);
	tpa_sock_mnt = kern_mount(&tpa_sock_fs_type);
	return 0;
}

void 
tpa_socket_exit(void)
{
	tpa_destroy_inodecache();
	unregister_filesystem(&tpa_sock_fs_type);
}

