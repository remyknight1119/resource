#ifndef __TCP_H__
#define __TCP_H__

//#include <linux/tcp.h>

#include "tpa_protosw.h"
#include "tpa_inpcb.h"
#include "tcpcb.h"

struct sk_buff;
struct _tpa_socket;
struct _tpa_sockopt;
struct _tpa_tcpcb;

extern tpa_pr_usrreqs tcp_usrreqs;
extern tpa_pr_usrreqs tcp6_usrreqs;
extern tpa_inpcbinfo tcbinfo;

/*
 * TCP header.
 * Per RFC 793, September, 1981.
 */
typedef struct _tpa_tcphdr {
	u16	th_sport;		/* source port */
	u16	th_dport;		/* destination port */
	tcp_seq	th_seq;			/* sequence number */
	tcp_seq	th_ack;			/* acknowledgement number */
#if defined(__LITTLE_ENDIAN_BITFIELD)
	u8	th_x2:4,		/* (unused) */
		th_off:4;		/* data offset */
#endif
#if defined(__BIG_ENDIAN_BITFIELD)
	u8	th_off:4,		/* data offset */
		th_x2:4;		/* (unused) */
#endif
	u8	th_flags;
#define	TH_FIN	0x01
#define	TH_SYN	0x02
#define	TH_RST	0x04
#define	TH_PUSH	0x08
#define	TH_ACK	0x10
#define	TH_URG	0x20
#define	TH_ECE	0x40
#define	TH_CWR	0x80
#define	TH_FLAGS	(TH_FIN|TH_SYN|TH_RST|TH_PUSH|TH_ACK|TH_URG|TH_ECE|TH_CWR)
#define	PRINT_TH_FLAGS	"\20\1FIN\2SYN\3RST\4PUSH\5ACK\6URG\7ECE\10CWR"

	u16	th_win;			/* window */
	u16	th_sum;			/* checksum */
	u16	th_urp;			/* urgent pointer */
}tpa_tcphdr;

#define	TCPOPT_EOL		0
#define	   TCPOLEN_EOL			1
#define	TCPOPT_PAD		0		/* padding after EOL */
#define	   TCPOLEN_PAD			1
#define	TCPOPT_NOP		1
#define	   TCPOLEN_NOP			1
#define	TCPOPT_MAXSEG		2
#define    TCPOLEN_MAXSEG		4
#define TCPOPT_WINDOW		3
#define    TCPOLEN_WINDOW		3
#define TCPOPT_SACK_PERMITTED	4
#define    TCPOLEN_SACK_PERMITTED	2
#define TCPOPT_SACK		5
#define	   TCPOLEN_SACKHDR		2
#define    TCPOLEN_SACK			8	/* 2*sizeof(tcp_seq) */
#define TCPOPT_TIMESTAMP	8
#define    TCPOLEN_TIMESTAMP		10
#define    TCPOLEN_TSTAMP_APPA		(TCPOLEN_TIMESTAMP+2) /* appendix A */
#define	TCPOPT_SIGNATURE	19		/* Keyed MD5: RFC 2385 */
#define	   TCPOLEN_SIGNATURE		18

/* Miscellaneous constants */
#define	MAX_SACK_BLKS	6	/* Max # SACK blocks stored at receiver side */
#define	TCP_MAX_SACK	4	/* MAX # SACKs sent in any segment */


/*
 * Default maximum segment size for TCP.
 * With an IP MTU of 576, this is 536,
 * but 512 is probably more convenient.
 * This should be defined as MIN(512, IP_MSS - sizeof (struct tcpiphdr)).
 */
#define	TCP_MSS	512
/*
 * TCP_MINMSS is defined to be 216 which is fine for the smallest
 * link MTU (256 bytes, AX.25 packet radio) in the Internet.
 * However it is very unlikely to come across such low MTU interfaces
 * these days (anno dato 2003).
 * See tcp_subr.c tcp_minmss SYSCTL declaration for more comments.
 * Setting this to "0" disables the minmss check.
 */
#define	TCP_MINMSS 216

/*
 * Default maximum segment size for TCP6.
 * With an IP6 MSS of 1280, this is 1220,
 * but 1024 is probably more convenient. (xxx kazu in doubt)
 * This should be defined as MIN(1024, IP6_MSS - sizeof (struct tcpip6hdr))
 */
#define	TCP6_MSS	1024

#define	TCP_MAXWIN	65535	/* largest value for (unscaled) window */
#define	TTCP_CLIENT_SND_WND	4096	/* dflt send window for T/TCP client */

#define TCP_MAX_WINSHIFT	14	/* maximum window shift */

#define TCP_MAXBURST		4	/* maximum segments in a burst */

#define TCP_MAXHLEN	(0xf<<2)	/* max length of header in bytes */
#define TCP_MAXOLEN	(TCP_MAXHLEN - sizeof(tpa_tcphdr))
					/* max space left for options */

/*
 * Structure to hold TCP options that are only used during segment
 * processing (in tcp_input), but not held in the tcpcb.
 * It's basically used to reduce the number of parameters
 * to tcp_dooptions and tcp_addoptions.
 * The binary order of the to_flags is relevant for packing of the
 * options in tcp_addoptions.
 */
typedef struct _tpa_tcpopt {
	u64	to_flags;	/* which options are present */
#define	TOF_MSS		0x0001		/* maximum segment size */
#define	TOF_SCALE	0x0002		/* window scaling */
#define	TOF_SACKPERM	0x0004		/* SACK permitted */
#define	TOF_TS		0x0010		/* timestamp */
#define	TOF_SIGNATURE	0x0040		/* TCP-MD5 signature option (RFC2385) */
#define	TOF_SACK	0x0080		/* Peer sent SACK option */
#define	TOF_MAXOPT	0x0100
	u32	to_tsval;	/* new timestamp */
	u32	to_tsecr;	/* reflected timestamp */
	u8	*to_sacks;	/* pointer to the first SACK blocks */
	u8	*to_signature;	/* pointer to the TCP-MD5 signature */
	u16	to_mss;		/* maximum segment size */
	u8	to_wscale;	/* window scaling */
	u8	to_nsacks;	/* number of SACK blocks */
}tpa_tcpopt;

/*
 * Flags for tcp_dooptions.
 */
#define	TO_SYN		0x01		/* parse SYN-only options */

static inline tpa_tcphdr *tpa_tcp_hdr(const struct sk_buff *skb)
{
	return (tpa_tcphdr *)skb_transport_header(skb);
}

static inline u32 tpa_tcp_hdrlen(const struct sk_buff *skb)
{
	return tpa_tcp_hdr(skb)->th_off * 4;
}

static inline u32 tpa_tcp_optlen(const struct sk_buff *skb)
{
	return (tpa_tcp_hdr(skb)->th_off - 5) * 4;
}

extern int tcp4_input(struct sk_buff *, int);
extern int tcp6_input(struct sk_buff *, int);
extern int tcp_output(struct _tpa_tcpcb *tp);
extern int tcp_output_connect(struct _tpa_socket *so);
extern void tcp_ctlinput(int cmd, struct _tpa_sockaddr *sa, void *vip);
extern void tcp6_ctlinput(int cmd, struct _tpa_sockaddr *sa, void *vip);
extern int tcp_ctloutput(struct _tpa_socket *so, struct _tpa_sockopt *sopt);
extern int tcp_twcheck(struct _tpa_inpcb *, struct _tpa_tcpopt *, tpa_tcphdr *,
	    struct sk_buff *, int);
extern struct _tpa_tcpcb *tcp_newtcpcb(tpa_inpcb *inp);
extern tcp_seq tcp_new_isn(struct _tpa_tcpcb *tp);
extern void tcp_discardcb(struct _tpa_tcpcb *tp);
extern void tcp_xmit_bandwidth_limit(struct _tpa_tcpcb *tp, tcp_seq ack_seq);
extern int tcp_init(void);
extern void tcp_destroy(void);
extern void tcp_drain(void);

#endif
