/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_ipv6.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-05
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/in.h>

#include "tpa_protosw.h"
#include "tpa_domain.h"
#include "tpa_socket.h"
#include "tpa_ipv6.h"
#include "tcp.h"

static tpa_protosw *tpa_ipv6_proto[IPPROTO_MAX] = {};
static tpa_domain tpa_inet6domain;

static tpa_protosw tpa_inet6sw[] = {
	{
		.pr_domain = 	&tpa_inet6domain,
		.pr_type =		TPA_SOCK_STREAM,
		.pr_protocol =		IPPROTO_TCP,
//		.pr_flags =		PR_CONNREQUIRED|PR_WANTRCVD|PR_LISTEN,
		.pr_input =		tcp6_input,
		.pr_ctlinput =		tcp6_ctlinput,
		.pr_ctloutput =		tcp_ctloutput,
//		.pr_init =		tcp_init,
//		.pr_destroy =		tcp_destroy,
		.pr_drain =		tcp_drain,
		.pr_usrreqs =		&tcp6_usrreqs,
	},
};

static tpa_domain tpa_inet6domain = {
	.dom_family =		TPA_INET6,
	.dom_protosw =		(tpa_protosw *)tpa_inet6sw,
	.dom_protosw_last =	(tpa_protosw *)
				&tpa_inet6sw[sizeof(tpa_inet6sw)/sizeof(tpa_inet6sw[0])],
};

int 
tpa_ipv6_input(struct sk_buff *skb)
{
	struct ipv6hdr *hdr = NULL;
	tpa_protosw *proto = NULL;
	int hlen = 0;
	int tlen = 0;
	int ret = 0;

	hdr = ipv6_hdr(skb);
	proto = tpa_ipv6_proto[hdr->nexthdr];
	if (proto == NULL){
		return -1;
	}
	
	hlen = sizeof(struct ipv6hdr);
	__skb_pull(skb, hlen);
	skb_reset_transport_header(skb);

	tlen = htons(hdr->payload_len);

	ret = proto->pr_input(skb, tlen);

	if (ret < 0){
		__skb_push(skb, hlen);
		skb_reset_transport_header(skb);
	}

	return ret;
}

int tpa_ipv6_init(void)
{
	tpa_protosw *pr;

	if(tpa_add_domain(&tpa_inet6domain)){
		return -1;
	}

	for (pr = tpa_inet6domain.dom_protosw; pr < tpa_inet6domain.dom_protosw_last; pr++) {
		if (pr->pr_protocol >= IPPROTO_MAX){
			continue;
		}

		tpa_ipv6_proto[pr->pr_protocol] = pr;
		if (pr->pr_init){
			pr->pr_init();
		}
	}

	return 0;
}

void tpa_ipv6_exit(void)
{
	tpa_del_domain(&tpa_inet6domain);
}

