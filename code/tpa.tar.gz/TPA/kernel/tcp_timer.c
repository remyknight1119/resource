/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tcp_timer.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-05-13
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include "tcpcb.h"
#include "tcp_timer.h"

int tcp_keepinit;
int tcp_keepidle;
int tcp_keepintvl;
int tcp_maxpersistidle;
int tcp_msl;
int tcp_rexmit_min;
int	tcp_rexmit_slop;
int tcp_finwait2_timeout;
	
void
tcp_timer_activate(tpa_tcpcb *tp, int timer_type, u32 delta)
{
	struct	timer_list *timer;

	switch (timer_type) {
		case TT_DELACK:
			timer = &tp->t_timers.tt_delack;
			break;
		case TT_REXMT:
			timer = &tp->t_timers.tt_rexmt;
			break;
		case TT_PERSIST:
			timer = &tp->t_timers.tt_persist;
			break;
		case TT_KEEP:
			timer = &tp->t_timers.tt_keep;
			break;
		case TT_2MSL:
			timer = &tp->t_timers.tt_2msl;
			break;
		default:
			panic("bad timer_type");
		}
	if (delta == 0) {
		del_timer(timer);
	} else {
		mod_timer(timer, jiffies + delta);
	}
}

int
tcp_timer_active(tpa_tcpcb *tp, int timer_type)
{
	struct	timer_list *timer;

	switch (timer_type) {
		case TT_DELACK:
			timer = &tp->t_timers.tt_delack;
			break;
		case TT_REXMT:
			timer = &tp->t_timers.tt_rexmt;
			break;
		case TT_PERSIST:
			timer = &tp->t_timers.tt_persist;
			break;
		case TT_KEEP:
			timer = &tp->t_timers.tt_keep;
			break;
		case TT_2MSL:
			timer = &tp->t_timers.tt_2msl;
			break;
		default:
			panic("bad timer_type");
		}
	return timer_pending(timer);
}

static void 
tcp_delack_timer(ulong data)
{
}

static void 
tcp_retransmit_timer(ulong data)
{
}

static void 
tcp_persist_timer(ulong data)
{
}

static void 
tcp_keepalive_timer(ulong data)
{
}

static void 
tcp_2msl_timer(ulong data)
{
}

void 
tcp_init_timers(tpa_socket *so)
{
	tpa_inpcb *inp;
	tpa_tcpcb *tp = NULL;

	inp = tpa_sotoinpcb(so);
	tp = tpa_intotcpcb(inp);

	setup_timer(&tp->t_timers.tt_delack, tcp_delack_timer,
			(ulong)so);
	setup_timer(&tp->t_timers.tt_rexmt, tcp_retransmit_timer,
			(ulong)so);
	setup_timer(&tp->t_timers.tt_persist, tcp_persist_timer, 
			(ulong)so);
	setup_timer(&tp->t_timers.tt_keep, tcp_keepalive_timer, 
			(ulong)so);
	setup_timer(&tp->t_timers.tt_2msl, tcp_2msl_timer, 
			(ulong)so);
}

