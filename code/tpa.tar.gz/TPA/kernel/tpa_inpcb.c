/**
 * ===========================================================================
 * COPYRIGHT:   Neusoft 2011-2012
 * FILENAME:   	tpa_inpcb.c 
 * VERSION:     1.0
 * AUTHOR:      liu_yt
 * DATE:        2011-04-06
 * DESCRIPTION:
 * 			manage the Protocol Control Blocks.
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <linux/gfp.h>
#include <linux/slab.h>
#include <linux/net.h>

#include "tpa_socket.h"
#include "tpa_inpcb.h"
#include "tpa_domain.h"
#include "tpa_in.h"
#include "tcp.h"
#include "tpa_debug.h"

u16 tpa_ipport_first = 1;	/* sysctl */
u16 tpa_ipport_last = 65535;
/*
 * Allocate a PCB and associate it with the socket.
 * On success return with the PCB locked.
 */
int
tpa_in_pcballoc(tpa_socket *so, tpa_inpcbinfo *pcbinfo)
{
	tpa_inpcb *inp;
	int error = 0;

	TPA_DEBUG("=======Enter=======\n");
	inp = kmem_cache_alloc(pcbinfo->ipi_cache, GFP_KERNEL|__GFP_ZERO);
	if (inp == NULL){
		return -1;
	}

	TPA_INP_LOCK_INIT(inp);

	TPA_DEBUG("=======Enter=======\n");
	TPA_INP_INFO_WLOCK_BH(pcbinfo);

	inp->inp_pcbinfo = pcbinfo;
	inp->inp_socket = so;
	TPA_DEBUG("=======Enter=======\n");
	TPA_LIST_INSERT_HEAD(pcbinfo->ipi_listhead, inp, inp_list);
	pcbinfo->ipi_count++;
	so->so_pcb = (void *)inp;
	TPA_DEBUG("=======Enter=======inp=%p\n",inp);
	TPA_INP_WLOCK_BH(inp);
	TPA_DEBUG("=======Enter=======\n");
	inp->inp_refcount = 1;	/* Reference from the inpcbinfo */

	TPA_INP_INFO_WUNLOCK_BH(pcbinfo);

	return (error);
}

/*
 * tpa_in_pcbdetach() is responsibe for disassociating a socket from an inpcb.
 * For most protocols, this will be invoked immediately prior to calling
 * in_pcbfree().  However, with TCP the inpcb may significantly outlive the
 * socket, in which case in_pcbfree() is deferred.
 */
void
tpa_in_pcbdetach(tpa_inpcb *inp)
{

	inp->inp_socket->so_pcb = NULL;
	inp->inp_socket = NULL;
}

/*
 * Remove PCB from various lists.
 */
static void
tpa_in_pcbremlists(tpa_inpcb *inp)
{
#if 0
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;

	INP_INFO_WLOCK_ASSERT(pcbinfo);
	INP_WLOCK_ASSERT(inp);

	inp->inp_gencnt = ++pcbinfo->ipi_gencnt;
#endif
	if (inp->inp_flags & TPA_INP_INHASHLIST) {
		tpa_inpcbport *phd = inp->inp_phd;

		TPA_LIST_REMOVE(inp, inp_hash);    
		TPA_LIST_REMOVE(inp, inp_portlist);
		if (TPA_LIST_FIRST(&phd->phd_pcblist) == NULL) {
			TPA_LIST_REMOVE(phd, phd_hash);    
			kfree(phd);
		}
		inp->inp_flags &= ~TPA_INP_INHASHLIST;
	}
	TPA_LIST_REMOVE(inp, inp_list);    
//	pcbinfo->ipi_count--;
}


/*
 * in_pcbfree_internal() frees an inpcb that has been detached from its
 * socket, and whose reference count has reached 0.  It will also remove the
 * inpcb from any global lists it might remain on.
 */
static void
tpa_in_pcbfree_internal(tpa_inpcb *inp)
{
	TPA_DEBUG("=======Enter=======\n");
	tpa_in_pcbremlists(inp);
	kmem_cache_free(inp->inp_pcbinfo->ipi_cache,inp);
}

/*
 * Drop a refcount on an inpcb elevated using in_pcbref(); because a call to
 * in_pcbfree() may have been made between in_pcbref() and in_pcbrele(), we
 * return a flag indicating whether or not the inpcb remains valid.  If it is
 * valid, we return with the inpcb lock held.
 */
static int
tpa_in_pcbrele(tpa_inpcb *inp)
{
	inp->inp_refcount--;
	if (inp->inp_refcount > 0){
		return (0);
	}
	tpa_in_pcbfree_internal(inp);
	return (1);
}


/*
 * Unconditionally schedule an inpcb to be freed by decrementing its
 * reference count, which should occur only after the inpcb has been detached
 * from its socket.  If another thread holds a temporary reference (acquired
 * using in_pcbref()) then the free is deferred until that reference is
 * released using in_pcbrele(), but the inpcb is still unlocked.
 */
void
tpa_in_pcbfree(tpa_inpcb *inp)
{
	if (!tpa_in_pcbrele(inp)){
		TPA_INP_WUNLOCK_BH(inp);
	}
}

#define TPA_INP_LOOKUP_MAPPED_PCB_COST	3

tpa_inpcb *
tpa_in_pcblookup_local(tpa_inpcbinfo *pcbinfo, tpa_in_addr laddr,
    u16 lport, int wild_okay)
{
	tpa_inpcb *inp;
	int matchwild = 3 + TPA_INP_LOOKUP_MAPPED_PCB_COST;
	int wildcard;

	if (!wild_okay) {
		tpa_inpcbhead *head;
		/*
		 * Look for an unconnected (wildcard foreign addr) PCB that
		 * matches the local address and port we're looking for.
		 */
		head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(TPA_INADDR_ANY, lport,
		    0, pcbinfo->ipi_hashmask)];
		TPA_LIST_FOREACH(inp, head, inp_hash) {
			/* XXX inp locking */
			if ((inp->inp_vflag & TPA_INP_IPV4) == 0){
				continue;
			}
			if (inp->inp_faddr.s_addr == TPA_INADDR_ANY &&
			    inp->inp_laddr.s_addr == laddr.s_addr &&
			    inp->inp_lport == lport) {
				/*
				 * Found?
				 */
				return (inp);
			}
		}
		/*
		 * Not found.
		 */
		return (NULL);
	} else {
		tpa_inpcbporthead *porthash;
		tpa_inpcbport *phd;
		tpa_inpcb *match = NULL;
		/*
		 * Best fit PCB lookup.
		 *
		 * First see if this local port is in use by looking on the
		 * port hash list.
		 */
		porthash = &pcbinfo->ipi_porthashbase[TPA_INP_PCBPORTHASH(lport,
		    pcbinfo->ipi_porthashmask)];
		TPA_LIST_FOREACH(phd, porthash, phd_hash) {
			if (phd->phd_port == lport){
				break;
			}
		}
		if (phd != NULL) {
			/*
			 * Port is in use by one or more PCBs. Look for best
			 * fit.
			 */
			TPA_LIST_FOREACH(inp, &phd->phd_pcblist, inp_portlist) {
				wildcard = 0;
				if ((inp->inp_vflag & TPA_INP_IPV4) == 0)
					continue;
				/*
				 * We never select the PCB that has
				 * INP_IPV6 flag and is bound to :: if
				 * we have another PCB which is bound
				 * to 0.0.0.0.  If a PCB has the
				 * INP_IPV6 flag, then we set its cost
				 * higher than IPv4 only PCBs.
				 *
				 * Note that the case only happens
				 * when a socket is bound to ::, under
				 * the condition that the use of the
				 * mapped address is allowed.
				 */
				if ((inp->inp_vflag & TPA_INP_IPV6) != 0){
					wildcard += TPA_INP_LOOKUP_MAPPED_PCB_COST;
				}
				if (inp->inp_faddr.s_addr != TPA_INADDR_ANY){
					wildcard++;
				}
				if (inp->inp_laddr.s_addr != TPA_INADDR_ANY) {
					if (laddr.s_addr == TPA_INADDR_ANY){
						wildcard++;
					}else if (inp->inp_laddr.s_addr != laddr.s_addr){
						continue;
					}
				} else {
					if (laddr.s_addr != TPA_INADDR_ANY){
						wildcard++;
					}
				}
				if (wildcard < matchwild) {
					match = inp;
					matchwild = wildcard;
					if (matchwild == 0){
						break;
					}
				}
			}
		}
		return (match);
	}
}
	
/*
 * Set up a bind operation on a PCB, performing port allocation
 * as required, but do not actually modify the PCB. Callers can
 * either complete the bind by setting inp_laddr/inp_lport and
 * calling in_pcbinshash(), or they can just use the resulting
 * port and address to authorise the sending of a once-off packet.
 *
 * On error, the values of *laddrp and *lportp are not changed.
 */
int
tpa_in_pcbbind_setup(tpa_inpcb *inp, tpa_sockaddr *nam, tpa_in_addr_t *laddrp,
    u16 *lportp)
{
	tpa_socket *so = inp->inp_socket;
	u16 *lastport;
	tpa_sockaddr_in *sin;
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;
	tpa_in_addr laddr;
	u16 lport = 0;
	int wild = 0, reuseport = (so->so_options & TPA_SO_REUSEPORT);

	laddr.s_addr = *laddrp;
	if (nam != NULL && laddr.s_addr != TPA_INADDR_ANY){
		return -1;
	}
//	if ((so->so_options & (SO_REUSEADDR|SO_REUSEPORT)) == 0)
//		wild = INPLOOKUP_WILDCARD;
	if (nam != NULL) {
		sin = (tpa_sockaddr_in *)nam;
		if (nam->sa_len != sizeof (*sin)){
			return -1;
		}
		/*
		 * We should check the family, but old programs
		 * incorrectly fail to initialize it.
		 */
		if (sin->sin_family != TPA_INET4){
			return -1;
		}
		if (sin->sin_port != *lportp) {
			/* Don't allow the port to change. */
			if (*lportp != 0){
				return -1;
			}
			lport = sin->sin_port;
		}
		/* NB: lport is left as 0 if the port isn't being changed. */
		if (TPA_IN_MULTICAST(ntohl(sin->sin_addr.s_addr))) {
			/*
			 * Treat SO_REUSEADDR as SO_REUSEPORT for multicast;
			 * allow complete duplication of binding if
			 * SO_REUSEPORT is set, or if SO_REUSEADDR is set
			 * and a multicast address is bound on both
			 * new and duplicated sockets.
			 */
//			if (so->so_options & SO_REUSEADDR)
//				reuseport = SO_REUSEADDR|SO_REUSEPORT;
		} else if (sin->sin_addr.s_addr != TPA_INADDR_ANY) {
			sin->sin_port = 0;		/* yech... */
			tpa_bzero(&sin->sin_zero, sizeof(sin->sin_zero));
			/*
			 * Is the address a local IP address? 
			 * If INP_BINDANY is set, then the socket may be bound
			 * to any endpoint address, local or not.
			 */
//			if ((inp->inp_flags & INP_BINDANY) == 0 &&
//			    ifa_ifwithaddr_check((tpa_sockaddr *)sin) == 0) 
//				return -1;
		}
		laddr = sin->sin_addr;
		if (lport) {
			tpa_inpcb *t;
			tpa_tcptw *tw;

			if (!TPA_IN_MULTICAST(ntohl(sin->sin_addr.s_addr))){
				t = tpa_in_pcblookup_local(pcbinfo, sin->sin_addr,
				    lport, TPA_INPLOOKUP_WILDCARD);
	/*
	 * XXX
	 * This entire block sorely needs a rewrite.
	 */
				if (t &&
				    ((t->inp_flags & TPA_INP_TIMEWAIT) == 0) &&
				    (so->so_type != TPA_SOCK_STREAM ||
				     ntohl(t->inp_faddr.s_addr) == TPA_INADDR_ANY) &&
				    (ntohl(sin->sin_addr.s_addr) != TPA_INADDR_ANY ||
				     ntohl(t->inp_laddr.s_addr) != TPA_INADDR_ANY ||
				     (t->inp_socket->so_options & TPA_SO_REUSEPORT) == 0))
					return -1;
			}
			t = tpa_in_pcblookup_local(pcbinfo, sin->sin_addr,
			    lport, wild);
			if (t && (t->inp_flags & TPA_INP_TIMEWAIT)) {
				/*
				 * XXXRW: If an incpb has had its timewait
				 * state recycled, we treat the address as
				 * being in use (for now).  This is better
				 * than a panic, but not desirable.
				 */
				tw = tpa_intotw(inp);
				if (tw == NULL ||
				    (reuseport & tw->tw_so_options) == 0)
					return -1;
			} else if (t &&
			    (reuseport & t->inp_socket->so_options) == 0) {
				if (ntohl(sin->sin_addr.s_addr) !=
				    TPA_INADDR_ANY ||
				    ntohl(t->inp_laddr.s_addr) !=
				    TPA_INADDR_ANY ||
				    TPA_INP_SOCKAF(so) ==
				    TPA_INP_SOCKAF(t->inp_socket))
					return -1;
			}
		}
	}
	if (*lportp != 0)
		lport = *lportp;
	if (lport == 0) {
		u16 first, last, aux;
		int count;

		first = tpa_ipport_first;	/* sysctl */
		last  = tpa_ipport_last;
		lastport = &pcbinfo->ipi_lastport;

		/*
		 * Instead of having two loops further down counting up or down
		 * make sure that first is always <= last and go with only one
		 * code path implementing all logic.
		 */
		if (first > last) {
			aux = first;
			first = last;
			last = aux;
		}

		*lastport = first + (net_random() % (last - first + 1));
		count = last - first + 1;

		do {
			if (count-- < 0){	/* completely used? */
				return -1;
			}
			++*lastport;
			if (*lastport < first || *lastport > last){
				*lastport = first;
			}
			lport = htons(*lastport);
		} while (tpa_in_pcblookup_local(pcbinfo, laddr,
		    lport, wild));
	}
	
	*laddrp = laddr.s_addr;
	*lportp = lport;
	return (0);
}

/*
 * Insert PCB onto various hash lists.
 */
int
tpa_in_pcbinshash(tpa_inpcb *inp)
{
	tpa_inpcbhead *pcbhash;
	tpa_inpcbporthead *pcbporthash;
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;
	tpa_inpcbport *phd;
	u32 hashkey_faddr;

	if (inp->inp_vflag & TPA_INP_IPV6){
		hashkey_faddr = inp->in6p_faddr.i6_addr32[3] /* XXX */;
	}else{
		hashkey_faddr = inp->inp_faddr.s_addr;
	}

	pcbhash = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(hashkey_faddr,
		 inp->inp_lport, inp->inp_fport, pcbinfo->ipi_hashmask)];

	pcbporthash = &pcbinfo->ipi_porthashbase[
	    TPA_INP_PCBPORTHASH(inp->inp_lport, pcbinfo->ipi_porthashmask)];

	/*
	 * Go through port list and look for a head for this lport.
	 */
	TPA_LIST_FOREACH(phd, pcbporthash, phd_hash) {
		if (phd->phd_port == inp->inp_lport)
			break;
	}
	/*
	 * If none exists, malloc one and tack it on.
	 */
	if (phd == NULL) {
		TPA_INP_WUNLOCK_BH(inp);
		TPA_INP_INFO_WUNLOCK_BH(pcbinfo);

		phd = kmalloc(sizeof(tpa_inpcbport), GFP_KERNEL);

		TPA_INP_INFO_WLOCK_BH(pcbinfo);
		TPA_INP_WLOCK_BH(inp);

		if (phd == NULL) {
			return -1;
		}
		phd->phd_port = inp->inp_lport;
		TPA_LIST_INIT(&phd->phd_pcblist);
		TPA_LIST_INSERT_HEAD(pcbporthash, phd, phd_hash);
	}
	inp->inp_phd = phd;
	TPA_LIST_INSERT_HEAD(&phd->phd_pcblist, inp, inp_portlist);
	TPA_LIST_INSERT_HEAD(pcbhash, inp, inp_hash);
	inp->inp_flags |= TPA_INP_INHASHLIST;
	
	return (0);
}


int
tpa_in_pcbbind(tpa_inpcb *inp, tpa_sockaddr *nam)
{
	int anonport, error;

	TPA_DEBUG("=======Enter=======\n");

	if (inp->inp_lport != 0 || inp->inp_laddr.s_addr != TPA_INADDR_ANY){
		TPA_DEBUG("Error!inp_lport = %u,inp_laddr = %u\n",inp->inp_lport,inp->inp_laddr.s_addr);
		return -1;
	}

	anonport = inp->inp_lport == 0 && (nam == NULL ||
	    ((tpa_sockaddr_in *)nam)->sin_port == 0);
	error = tpa_in_pcbbind_setup(inp, nam, &inp->inp_laddr.s_addr,
	    &inp->inp_lport);
	if (error){
		TPA_DEBUG("Bind setup failed!\n");
		return (error);
	}

	if (tpa_in_pcbinshash(inp) != 0) {
		inp->inp_laddr.s_addr = TPA_INADDR_ANY;
		inp->inp_lport = 0;
		TPA_DEBUG("In hash failed!\n");
		return -1;
	}
	if (anonport){
		inp->inp_flags |= TPA_INP_ANONPORT;
	}
	
	return (0);
}

/*
 * Do proper source address selection on an unbound socket in case
 * of connect. Take jails into account as well.
 */
static int
tpa_in_pcbladdr(tpa_inpcb *inp, tpa_in_addr *faddr, tpa_in_addr *laddr)
{
	return 0;
}
	
/*
 * Lookup PCB in hash list.
 */
tpa_inpcb *
tpa_in_pcblookup_hash(tpa_inpcbinfo *pcbinfo, tpa_in_addr faddr,
    u32 fport_arg, tpa_in_addr laddr, u32 lport_arg, int find_listen)
{
	tpa_inpcbhead *head;
	tpa_inpcb *inp;
	u16 fport = fport_arg;
	u16 lport = lport_arg;

	/*
	 * First look for an exact match.
	 */
	head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(faddr.s_addr, lport, fport,
	    pcbinfo->ipi_hashmask)];
	TPA_LIST_FOREACH(inp, head, inp_hash) {
		/* XXX inp locking */
		if ((inp->inp_vflag & TPA_INP_IPV4) == 0){
			continue;
		}
		if (inp->inp_faddr.s_addr == faddr.s_addr &&
		    inp->inp_laddr.s_addr == laddr.s_addr &&
		    inp->inp_fport == fport &&
		    inp->inp_lport == lport) {
			return (inp);
		}
	}

	if (find_listen){
		head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(TPA_INADDR_ANY, lport,
		    0, pcbinfo->ipi_hashmask)];
		TPA_LIST_FOREACH(inp, head, inp_hash) {
			/* XXX inp locking */
			if ((inp->inp_vflag & TPA_INP_IPV4) == 0){
				continue;
			}
			if (inp->inp_faddr.s_addr != TPA_INADDR_ANY ||
			    inp->inp_lport != lport){
				continue;
			}

			if (inp->inp_laddr.s_addr == laddr.s_addr) {
				return (inp);
			}
		} /* LIST_FOREACH */
	}

	return (NULL);
}

/*
 * Set up for a connect from a socket to the specified address.
 * On entry, *laddrp and *lportp should contain the current local
 * address and port for the PCB; these are updated to the values
 * that should be placed in inp_laddr and inp_lport to complete
 * the connect.
 *
 * On success, *faddrp and *fportp will be set to the remote address
 * and port. These are not updated in the error case.
 *
 * If the operation fails because the connection already exists,
 * *oinpp will be set to the PCB of that connection so that the
 * caller can decide to override it. In all other cases, *oinpp
 * is set to NULL.
 */
int
tpa_in_pcbconnect_setup(tpa_inpcb *inp, tpa_sockaddr *nam,
    tpa_in_addr_t *laddrp, u16 *lportp, tpa_in_addr_t *faddrp, u16 *fportp,
    tpa_inpcb **oinpp)
{
	tpa_sockaddr_in *sin = (tpa_sockaddr_in *)nam;
	tpa_inpcb *oinp;
	tpa_in_addr laddr;
	tpa_in_addr faddr;
	u16 lport;
	u16 fport;
	int error;

	if (oinpp != NULL){
		*oinpp = NULL;
	}
	if (nam->sa_len != sizeof (*sin)){
		return -1;
	}
	if (sin->sin_family != TPA_INET4){
		return -1;
	}
	if (sin->sin_port == 0){
		return -1;
	}
	laddr.s_addr = *laddrp;
	lport = *lportp;
	faddr = sin->sin_addr;
	fport = sin->sin_port;

	if (laddr.s_addr == TPA_INADDR_ANY) {
		error = tpa_in_pcbladdr(inp, &faddr, &laddr);
		if (error){
			return (error);
		}
	}

	oinp = tpa_in_pcblookup_hash(inp->inp_pcbinfo, faddr, fport, laddr, lport, 0);
	if (oinp != NULL) {
		if (oinpp != NULL){
			*oinpp = oinp;
		}
		return -1;
	}
	if (lport == 0) {
		error = tpa_in_pcbbind_setup(inp, NULL, &laddr.s_addr, &lport);
		if (error){
			return (error);
		}
	}
	*laddrp = laddr.s_addr;
	*lportp = lport;
	*faddrp = faddr.s_addr;
	*fportp = fport;
	return (0);
}

/*
 * Move PCB to the proper hash bucket when { faddr, fport } have  been
 * changed. NOTE: This does not handle the case of the lport changing (the
 * hashed port list would have to be updated as well), so the lport must
 * not change after in_pcbinshash() has been called.
 */
void
tpa_in_pcbrehash(tpa_inpcb *inp)
{
	tpa_inpcbinfo *pcbinfo = inp->inp_pcbinfo;
	tpa_inpcbhead *head;
	u32 hashkey_faddr;


	if (inp->inp_vflag & TPA_INP_IPV6){
		hashkey_faddr = inp->in6p_faddr.i6_addr32[3] /* XXX */;
	}else{
		hashkey_faddr = inp->inp_faddr.s_addr;
	}

	head = &pcbinfo->ipi_hashbase[TPA_INP_PCBHASH(hashkey_faddr,
		inp->inp_lport, inp->inp_fport, pcbinfo->ipi_hashmask)];

	TPA_LIST_REMOVE(inp, inp_hash);
	TPA_LIST_INSERT_HEAD(head, inp, inp_hash);
}



