#ifndef __TPA_PROTOSW_H__
#define __TPA_PROTOSW_H__

#include <linux/types.h>
#include <linux/fs.h>
#include <linux/poll.h>
#include <linux/skbuff.h>

/* Forward declare these structures referenced from prototypes below. */
struct sk_buff;
struct _tpa_sockaddr;
struct _tpa_socket;
struct _tpa_sockopt;

/*
 * If the ordering here looks odd, that's because it's alphabetical.  These
 * should eventually be merged back into struct protosw.
 *
 * Some fields initialized to defaults if they are NULL.
 * See uipc_domain.c:net_init_domain()
 */
struct uio;
typedef struct _tpa_pr_usrreqs {
	void	(*pru_abort)(struct _tpa_socket *so);
	int	(*pru_accept)(struct _tpa_socket *so, struct _tpa_sockaddr **nam);
	int	(*pru_attach)(struct _tpa_socket *so, int proto);
	int	(*pru_bind)(struct _tpa_socket *so, struct _tpa_sockaddr *nam);
	int	(*pru_connect)(struct _tpa_socket *so, struct _tpa_sockaddr *nam);
	int	(*pru_control)(struct _tpa_socket *so, ulong cmd, caddr_t data);
	void	(*pru_detach)(struct _tpa_socket *so);
	int	(*pru_disconnect)(struct _tpa_socket *so);
	int	(*pru_listen)(struct _tpa_socket *so, int backlog);
	int	(*pru_peeraddr)(struct _tpa_socket *so, struct _tpa_sockaddr **nam);
	int	(*pru_rcvd)(struct _tpa_socket *so, int flags);
	int	(*pru_rcvoob)(struct _tpa_socket *so, struct sk_buff *m, int flags);
	int	(*pru_send)(struct _tpa_socket *so, int flags, struct sk_buff *m, 
		    struct _tpa_sockaddr *addr, struct sk_buff *control);
	int	(*pru_sosend)(struct _tpa_socket *so, struct _tpa_sockaddr *addr,
		    struct uio *uio, struct sk_buff *top, struct sk_buff *control,
		    int flags);
	int	(*pru_soreceive)(struct _tpa_socket *so, struct _tpa_sockaddr **paddr,
		    struct uio *uio, struct sk_buff **mp0, struct sk_buff **controlp,
		    int *flagsp);
	u32	(*pru_sopoll)(struct file *file, struct _tpa_socket *so, poll_table *wait);
	void	(*pru_close)(struct _tpa_socket *so);
}tpa_pr_usrreqs;


/*#ifdef _KERNEL*/
/*
 * Protocol switch table.
 *
 * Each protocol has a handle initializing one of these structures,
 * which is used for protocol-protocol and system-protocol communication.
 *
 * A protocol is called through the pr_init entry before any other.
 * Thereafter it is called every 200ms through the pr_fasttimo entry and
 * every 500ms through the pr_slowtimo for timer based actions.
 * The system will call the pr_drain entry if it is low on space and
 * this should throw away any non-critical data.
 *
 * Protocols pass data between themselves as chains of mbufs using
 * the pr_input and pr_output hooks.  Pr_input passes data up (towards
 * the users) and pr_output passes it down (towards the interfaces); control
 * information passes up and down on pr_ctlinput and pr_ctloutput.
 * The protocol is responsible for the space occupied by any the
 * arguments to these entries and must dispose it.
 *
 * In retrospect, it would be a lot nicer to use an interface
 * similar to the vnode VOP interface.
 */
/* USE THESE FOR YOUR PROTOTYPES ! */
typedef int	pr_input_t (struct sk_buff *, int);
typedef int	pr_input6_t (struct sk_buff **, int*, int);  /* XXX FIX THIS */
typedef int	pr_output_t (struct sk_buff *, struct _tpa_socket *);
typedef void	pr_ctlinput_t (int, struct _tpa_sockaddr *, void *);
typedef int	pr_ctloutput_t (struct _tpa_socket *, struct _tpa_sockopt *);
typedef	int	pr_init_t (void);
typedef	void	pr_destroy_t (void);
typedef	void	pr_drain_t (void);

struct _tpa_domain;

typedef struct _tpa_protosw {
	short	pr_type;		/* socket type used for */
	short	pr_protocol;		/* protocol number */
	short	pr_flags;		/* see below */
	struct _tpa_domain *pr_domain;
/* protocol-protocol hooks */
	pr_input_t *pr_input;		/* input to protocol (from below) */
	pr_output_t *pr_output;		/* output to protocol (from above) */
	pr_ctlinput_t *pr_ctlinput;	/* control input (from below) */
	pr_ctloutput_t *pr_ctloutput;	/* control output (from above) */
/* utility hooks */
	pr_init_t *pr_init;
	pr_destroy_t *pr_destroy;
	pr_drain_t *pr_drain;		/* flush any excess space possible */
	tpa_pr_usrreqs *pr_usrreqs;	/* user-protocol hook */
}tpa_protosw;
/*#endif*/

#define	TPA_PR_SLOWHZ	2		/* 2 slow timeouts per second */
#define	TPA_PR_FASTHZ	5		/* 5 fast timeouts per second */

/*
 * This number should be defined again within each protocol family to avoid
 * confusion.
 */
#define	TPA_PROTO_SPACER	32767		/* spacer for loadable protocols */

/*
 * Values for pr_flags.
 * TPA_PR_ADDR requires TPA_PR_ATOMIC;
 * TPA_PR_ADDR and TPA_PR_CONNREQUIRED are mutually exclusive.
 * TPA_PR_IMPLOPCL means that the protocol allows sendto without prior connect,
 *	and the protocol understands the MSG_EOF flag.  The first property is
 *	is only relevant if TPA_PR_CONNREQUIRED is set (otherwise sendto is allowed
 *	anyhow).
 */
#define	TPA_PR_ATOMIC	0x01		/* exchange atomic messages only */
#define	TPA_PR_ADDR		0x02		/* addresses given with messages */
#define	TPA_PR_CONNREQUIRED	0x04		/* connection required by protocol */
#define	TPA_PR_WANTRCVD	0x08		/* want TPA_PRU_RCVD calls */
#define	TPA_PR_RIGHTS	0x10		/* passes capabilities */
#define TPA_PR_IMPLOPCL	0x20		/* implied open/close */
#define	TPA_PR_LASTHDR	0x40		/* enforce ipsec policy; last header */

/*
 * In earlier BSD network stacks, a single pr_usrreq() function pointer was
 * invoked with an operation number indicating what operation was desired.
 * We now provide individual function pointers which protocols can implement,
 * which offers a number of benefits (such as type checking for arguments).
 * These older constants are still present in order to support TCP debugging.
 */
#define	TPA_PRU_ATTACH		0	/* attach protocol to up */
#define	TPA_PRU_DETACH		1	/* detach protocol from up */
#define	TPA_PRU_BIND		2	/* bind socket to address */
#define	TPA_PRU_LISTEN		3	/* listen for connection */
#define	TPA_PRU_CONNECT		4	/* establish connection to peer */
#define	TPA_PRU_ACCEPT		5	/* accept connection from peer */
#define	TPA_PRU_DISCONNECT		6	/* disconnect from peer */
#define	TPA_PRU_SHUTDOWN		7	/* won't send any more data */
#define	TPA_PRU_RCVD		8	/* have taken data; more room now */
#define	TPA_PRU_SEND		9	/* send this data */
#define	TPA_PRU_ABORT		10	/* abort (fast DISCONNECT, DETATCH) */
#define	TPA_PRU_CONTROL		11	/* control operations on protocol */
#define	TPA_PRU_SENSE		12	/* return status into m */
#define	TPA_PRU_RCVOOB		13	/* retrieve out of band data */
#define	TPA_PRU_SENDOOB		14	/* send out of band data */
#define	TPA_PRU_SOCKADDR		15	/* fetch socket's address */
#define	TPA_PRU_PEERADDR		16	/* fetch peer's address */
/* begin for protocols internal use */
#define	TPA_PRU_PROTORCV		20	/* receive from below */
#define	TPA_PRU_PROTOSEND		21	/* send to below */
/* end for protocol's internal use */
#define TPA_PRU_SEND_EOF		22	/* send and close */
#define	TPA_PRU_CLOSE		24	/* socket close */
#define	TPA_PRU_NREQ		25

#define	TPA_PR_SLOWHZ	2		/* 2 slow timeouts per second */
#define	TPA_PR_FASTHZ	5		/* 5 fast timeouts per second */

extern tpa_protosw *tpa_pffindproto(int family, int protocol, int type);

#endif
