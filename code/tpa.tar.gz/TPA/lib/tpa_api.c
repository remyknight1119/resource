/**
 * ===========================================================================
 * FILENAME:   	tpa_api.c 
 * VERSION:     2.0
 * AUTHOR:      liu_yt
 * DATE:        2009-09-11
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "tpa_priv.h"
#include "../include/tpa_api.h"

int tpa_socket(int domain, int type, int protocol)
{
	unsigned long a[3] = {domain, type, protocol};

	return tpa_syscall(TPA_SYS_SOCKET, a);
}

int tpa_bind(int sockfd, const tpa_sockaddr *myaddr, tpa_socklen_t addrlen)
{
	unsigned long a[3] = {sockfd, (unsigned long)myaddr, (unsigned long)addrlen};

	return tpa_syscall(TPA_SYS_BIND, a);
}

int tpa_listen(int sockfd, int backlog)
{
	unsigned long a[2] = {sockfd, backlog};

	return tpa_syscall(TPA_SYS_LISTEN, a);
}

int tpa_accept(int sockfd, const tpa_sockaddr *myaddr, tpa_socklen_t *addrlen)
{
	unsigned long a[3] = {sockfd, (unsigned long)myaddr, (unsigned long)addrlen};

	return tpa_syscall(TPA_SYS_ACCEPT, a);
}

int tpa_connect(int sockfd, const tpa_sockaddr *addr, tpa_socklen_t addrlen)
{
	unsigned long a[3] = {sockfd, (unsigned long)addr, (unsigned long)addrlen};

	return tpa_syscall(TPA_SYS_CONNECT, a);
}

int tpa_getsockopt(int sockfd, int level, int optname,
		                      void *optval, tpa_socklen_t *optlen)
{
	unsigned long a[5] = {sockfd, level, optname, (unsigned long)optval, (unsigned long)optlen};

	return tpa_syscall(TPA_SYS_GETSOCKOPT, a);
}

int tpa_setsockopt(int sockfd, int level,int  optname,
			                  const void *optval, tpa_socklen_t optlen)
{
	unsigned long a[5] = {sockfd, level, optname, (unsigned long)optval, (unsigned long)optlen};

	return tpa_syscall(TPA_SYS_SETSOCKOPT, a);
}

ssize_t tpa_recv(int sockfd, void *buf, size_t len, int flags)
{
	unsigned long a[4] = {sockfd, (unsigned long)buf, (unsigned long)len, flags};

	return tpa_syscall(TPA_SYS_RECV, a);
}

ssize_t tpa_recvmsg(int sockfd, tpa_msghdr *msg, int flags)
{
	unsigned long a[3] = {sockfd, (unsigned long)msg, flags};

	return tpa_syscall(TPA_SYS_RECVMSG, a);
}

ssize_t tpa_send(int sockfd, const void *buf, size_t len, int flags)
{
	unsigned long a[4] = {sockfd, (unsigned long)buf, (unsigned long)len, flags};

	return tpa_syscall(TPA_SYS_SEND, a);
}

ssize_t tpa_sendmsg(unsigned int sockfd, const tpa_msghdr *msg, unsigned int flags)
{
	unsigned long a[3] = {sockfd, (unsigned long)msg, flags};

	return tpa_syscall(TPA_SYS_SENDMSG, a);
}

int tpa_shuntdown(unsigned int sockfd, unsigned int how)
{
	unsigned long a[2] = {sockfd, how};

	return tpa_syscall(TPA_SYS_SHUTDOWN, a);
}

int tpa_close(int sockfd)
{
	return close(sockfd);
}

