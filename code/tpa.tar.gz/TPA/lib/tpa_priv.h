#ifndef __TPA_PRIV_H__
#define __TPA_PRIV_H__

#include <sys/ioctl.h>

#include "../include/tpa_comm.h"
#include "../include/tpa_types.h"

extern int tpa_cdev_fd;

extern int tpa_syscall(unsigned int cmd, void *arg);

#endif
