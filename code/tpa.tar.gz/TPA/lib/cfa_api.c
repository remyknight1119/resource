/**
 * ===========================================================================
 * FILENAME:   	cfa_api.c 
 * VERSION:     2.0
 * AUTHOR:      liu_yt
 * DATE:        2009-09-11
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#include "cfa_priv.h"

ne_int32_t cfa_api_init(void)
{
	cfa_cdev_fd = open("/dev/cfa_cdev", O_RDWR);
	if(cfa_cdev_fd < 0){
		printf("CFA api init failed!fd=%d\n",cfa_cdev_fd);
		return cfa_cdev_fd;
	}

	return 0;
}

ne_int32_t cfa_api_exit(void)
{
	return close(cfa_cdev_fd);
}

ne_int32_t cfa_socket(ne_int32_t domain, ne_int32_t type, ne_int32_t protocol)
{
	ne_ulong_t a[3] = {domain, type, protocol};

	return cfa_syscall(CFA_SYS_SOCKET, a);
}

ne_int32_t cfa_bind(ne_int32_t sockfd, const cfa_sockaddr *myaddr, socklen_t addrlen)
{
	ne_ulong_t a[3] = {sockfd, (ne_ulong_t)myaddr, (ne_ulong)addrlen};

	return cfa_syscall(CFA_SYS_BIND, a);
}

ne_int32_t cfa_listen(ne_int32_t sockfd, ne_int32_t backlog)
{
	ne_ulong_t a[2] = {sockfd, backlog};

	return cfa_syscall(CFA_SYS_LISTEN, a);
}

ne_int32_t cfa_accept(ne_int32_t sockfd, const cfa_sockaddr *myaddr, socklen_t *addrlen)
{
	ne_ulong_t a[3] = {sockfd, (ne_ulong_t)myaddr, (ne_ulong)addrlen};

	return cfa_syscall(CFA_SYS_ACCEPT, a);
}

ne_int32_t cfa_connect(ne_int32_t sockfd, const cfa_sockaddr *addr, socklen_t addrlen)
{
	ne_ulong_t a[3] = {sockfd, (ne_ulong_t)addr, (ne_ulong)addrlen};

	return cfa_syscall(CFA_SYS_CONNECT, a);
}

ne_int32_t cfa_getsockopt(ne_int32_t sockfd, ne_int32_t level, ne_int32_t optname,
		                      void *optval, socklen_t *optlen)
{
	ne_ulong_t a[5] = {sockfd, level, optname, (ne_ulong_t)optval, (ne_ulong)optlen};

	return cfa_syscall(CFA_SYS_GETSOCKOPT, a);
}

ne_int32_t cfa_setsockopt(ne_int32_t sockfd, ne_int32_t level,ne_int32_t  optname,
			                  const void *optval, socklen_t optlen)
{
	ne_ulong_t a[5] = {sockfd, level, optname, (ne_ulong_t)optval, (ne_ulong)optlen};

	return cfa_syscall(CFA_SYS_SETSOCKOPT, a);
}

ssize_t cfa_recv(ne_int32_t sockfd, void *buf, size_t len, ne_int32_t flags)
{
	ne_ulong_t a[4] = {sockfd, (ne_ulong_t)buf, (ne_ulong_t)len, flags};

	return cfa_syscall(CFA_SYS_RECV, a);
}

ssize_t cfa_recvfrom(ne_int32_t sockfd, void *buf, size_t len, ne_int32_t flags,
						cfa_sockaddr *src_addr, socklen_t *addrlen)
{
	ne_ulong_t a[6] = {sockfd, (ne_ulong_t)buf, (ne_ulong_t)len, flags,
						(ne_ulong_t)src_addr, (ne_ulong_t)addrlen};

	return cfa_syscall(CFA_SYS_RECVFROM, a);
}

ssize_t cfa_recvmsg(ne_int32_t sockfd, cfa_msghdr *msg, ne_int32_t flags)
{
	ne_ulong_t a[3] = {sockfd, (ne_ulong_t)msg, flags};

	return cfa_syscall(CFA_SYS_RECVMSG, a);
}

ssize_t cfa_send(ne_int32_t sockfd, const void *buf, size_t len, ne_int32_t flags)
{
	ne_ulong_t a[4] = {sockfd, (ne_ulong_t)buf, (ne_ulong_t)len, flags};

	return cfa_syscall(CFA_SYS_SEND, a);
}

ssize_t cfa_sendto(ne_int32_t sockfd, const void *buf, size_t len, ne_int32_t flags,
						const cfa_sockaddr *dest_addr, socklen_t addrlen)
{
	ne_ulong_t a[6] = {sockfd, (ne_ulong_t)buf, (ne_ulong_t)len, flags,
						(ne_ulong_t)dest_addr, (ne_ulong_t)addrlen};

	return cfa_syscall(CFA_SYS_SENDTO, a);
}

ssize_t cfa_sendmsg(ne_uint32_t sockfd, const cfa_msghdr *msg, ne_uint32_t flags)
{
	ne_ulong_t a[3] = {sockfd, (ne_ulong_t)msg, flags};

	return cfa_syscall(CFA_SYS_SENDMSG, a);
}

ne_int32_t cfa_shuntdown(ne_uint32_t sockfd, ne_uint32_t how)
{
	ne_ulong_t a[2] = {sockfd, how};

	return cfa_syscall(CFA_SYS_SHUTDOWN, a);
}

ne_int32_t cfa_close(ne_int32_t sockfd)
{
	return close(sockfd);
}

