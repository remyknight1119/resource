/**
 * ===========================================================================
 * FILENAME:   	cfa_syscall.c 
 * VERSION:     3.0
 * AUTHOR:      liu_yt
 * DATE:        2010-06-3
 * DESCRIPTION:
 *
 * CHANGE HISTORY:
 * DATE     REV     WHO     DESCRIPTION
 * ---------------------------------------------------------------------------
 *
 * ===========================================================================
 **/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>

#ifndef __NR_tpa_syscall
#define __NR_tpa_syscall			299
#endif
int tpa_syscall(unsigned int cmd, void *arg)
{
	return syscall(__NR_tpa_syscall, cmd, arg);
}

